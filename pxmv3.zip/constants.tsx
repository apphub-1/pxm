import React from 'react';
import {
  Info, Link2, ShieldCheck, FileCheck, Database, Settings, LogIn, AlertTriangle, Shield,
  Server, Network, Lock, Users, Key, Link, KeyRound, Cloud, RefreshCw, FileText
} from 'lucide-react';

export const DEFAULT_HEADERS = [
  "ICTO", 
  "Name", 
  "Objektstatus", 
  "Stereotyp", 
  "tAV", 
  "Kritikalität", 
  "Anmerkung zur Variante", 
  "Anbindungsvariante", 
  "PAM-Relevanz",
  "Protokollierung privilegierter Rechte auf Anwendungsebene",
  "Protokollierung privilegierter Rechte für DB auf Server",
  "Protokollierung privilegierter Rechte für Betriebssystem auf Server",
  "KommentarPAM",
  "Workorder Abnahme", 
  "Entzug privilegierte Berechtigungen",
  "AbnahmePAMOnboarding",
  "AbnahmeSecretsOnboarding",
  "KommentarSecretsManagement",
  "StatusPAMOnboarding",
  "StartdatumPAMOnboarding",
  "StatusSecretsOnboarding",
  "StartdatumSecretsOnboarding",
  "GrundNichtanbindungPAM",
  "DienstleisterPAM",
  "GrundNichtanbindungSecrets",
  "DienstleisterSecrets",
  "GruendeNichtWeiterVerfolgtPAM",
  "GruendeNichtWeiterVerfolgtSecrets"
];

export const SELECT_OPTIONS: Record<string, string[]> = {
  "Objektstatus": ["Plan", "Aktiv", "Stillgelegt"],
  "Stereotyp": ["ExternalSystem_ASPSAAS", "InternalSystem", "CloudService"],
  "Kritikalität": ["1-niedrig", "2-mittel", "3-hoch", "4-kritisch"],
  "Anbindungsvariante": ["Variante 1", "Variante 2", "Variante 3", "Sonderlösung"],
  "PAM-Relevanz": ["Ja", "Nein"],
  "Protokollierung privilegierter Rechte auf Anwendungsebene": [
    "Keine PAM-Anbindung - keine privilegierten Rechte",
    "Keine PAM-Anbindung - Ausnahme gemäß Ausnahmeprozess",
    "keine PAM-Anbindung - Externe Anwendung",
    "Protokollierung privilegierter Rechte über CyberArk"
  ],
  "Protokollierung privilegierter Rechte für DB auf Server": [
    "keine PAM-Anbindung für den eingesetzten Datenbanktyp",
    "Keine PAM-Anbindung - keine privilegierten Rechte",
    "Protokollierung privilegierter Rechte über CyberArk",
    "keine PAM-Anbindung - Externe Anwendung"
  ],
  "Protokollierung privilegierter Rechte für Betriebssystem auf Server": [
    "keine PAM-Anbindung für den eingesetzten Betriebssystemtyp",
    "Keine PAM-Anbindung - keine privilegierten Rechte",
    "Protokollierung privilegierter Rechte über CyberArk",
    "keine PAM-Anbindung - Externe Anwendung"
  ],
  "Entzug privilegierte Berechtigungen": ["erfolgt", "in Arbeit", "offen"]
};

export const FIELD_GROUPS = [
  {
    title: "Stammdaten",
    icon: <Info className="w-5 h-5 text-blue-500" />,
    fields: ["ICTO", "Name", "Kurzname", "Objektstatus", "Stereotyp", "Kritikalität", "tAV", "Stellvertreter tAV", "fAV", "Betriebsverantwortlicher", "Objektpflege"]
  },
  {
    title: "Anbindung & Relevanz",
    icon: <Link2 className="w-5 h-5 text-indigo-500" />,
    fields: ["Anbindungsvariante", "PAM-Relevanz", "Anmerkung zur Variante"]
  },
  {
    title: "Protokollierung (Compliance)",
    icon: <ShieldCheck className="w-5 h-5 text-emerald-500" />,
    fields: [
      "Protokollierung privilegierter Rechte auf Anwendungsebene",
      "Protokollierung privilegierter Rechte für DB auf Server",
      "Protokollierung privilegierter Rechte für Betriebssystem auf Server"
    ]
  },
  {
    title: "Dokumentation & Abschluss",
    icon: <FileCheck className="w-5 h-5 text-amber-500" />,
    fields: ["Workorder Abnahme", "Entzug privilegierte Berechtigungen", "KommentarPAM"]
  }
];

export const ONBOARDING_SECTIONS = [
  { id: 'architecture', title: '1. Architektur', icon: <Database className="w-5 h-5" /> },
  { id: 'technology', title: '2. Anwendungstechnologie', icon: <Settings className="w-5 h-5" /> },
  { id: 'login', title: '3. Anmeldeverfahren', icon: <LogIn className="w-5 h-5" /> },
  { id: 'password', title: '4. Passwortwechsel', icon: <ShieldCheck className="w-5 h-5" /> },
  { id: 'test', title: '5. Testuser und Testumgebung', icon: <FileCheck className="w-5 h-5" /> },
  { id: 'emergency', title: '6. Notfallprozess', icon: <AlertTriangle className="w-5 h-5" /> },
  { id: 'matrix', title: '7. Vereinbarte Anbindungsvariante', icon: <Link2 className="w-5 h-5" /> },
  { id: 'bypass', title: '8. PAM-Bypass Regeln', icon: <Shield className="w-5 h-5" /> },
];

export const TECHNICAL_SECTIONS = [
  { id: 'servers', title: '1. Server / Betriebssysteme', icon: <Server className="w-5 h-5" /> },
  { id: 'databases', title: '2. Datenbanken / Server', icon: <Database className="w-5 h-5" /> },
  { id: 'ports', title: '3. Portfreischaltungen', icon: <Network className="w-5 h-5" /> },
  { id: 'safes', title: '4. Safe-Struktur (CyberArk)', icon: <Lock className="w-5 h-5" /> },
  { id: 'safeMembers', title: '5. Mitglieder der Safes', icon: <Users className="w-5 h-5" /> },
  { id: 'sharedAccounts', title: '6. Shared Accounts', icon: <Key className="w-5 h-5" /> },
  { id: 'permissions', title: '7. Berechtigungszuordnungen', icon: <Shield className="w-5 h-5" /> },
  { id: 'mapping', title: '8. Shared Accounts zu Safe', icon: <Link className="w-5 h-5" /> },
];

export const SECRETS_SECTIONS = [
  { id: 'inventory', title: '1. Secret Inventory', icon: <KeyRound className="w-5 h-5" /> },
  { id: 'safes', title: '2. Safe- / Pfad-Struktur', icon: <Lock className="w-5 h-5" /> },
  { id: 'members', title: '3. Mitglieder der Safes', icon: <Users className="w-5 h-5" /> },
  { id: 'mapping', title: '4. Secrets zu Safe', icon: <Link className="w-5 h-5" /> },
];

export const SECRETS_ONBOARDING_SECTIONS = [
  { id: 'infrastructure', title: '1. Infrastruktur', icon: <Server className="w-5 h-5" /> },
  { id: 'tools', title: '2. Tool-Nutzung', icon: <Settings className="w-5 h-5" /> },
  { id: 'container_standalone', title: '3. Container – Standalone', icon: <Database className="w-5 h-5" /> },
  { id: 'container_k8s', title: '4. Container – Kubernetes / OpenShift', icon: <Cloud className="w-5 h-5" /> },
  { id: 'cloud', title: '5. Cloud Computing', icon: <Cloud className="w-5 h-5" /> },
  { id: 'server', title: '6. Konfig & Codecontrolle', icon: <Server className="w-5 h-5" /> },
  { id: 'properties', title: '7. Eigenschaften der Secrets', icon: <Key className="w-5 h-5" /> },
  { id: 'rotation_status', title: '8. Rotation – Ist-Status', icon: <RefreshCw className="w-5 h-5" /> },
  { id: 'target_image', title: '9. Anbindungsvariante (Zielbild)', icon: <Link2 className="w-5 h-5" /> },
];
