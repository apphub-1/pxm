import React, { useState, useEffect } from 'react';

export const PaginatedHistoryList = ({ history, cardClassName = "bg-white dark:bg-slate-800 p-5 rounded-lg border border-slate-100 dark:border-slate-700 shadow-sm" }: { history: any[], cardClassName?: string }) => {
  const [page, setPage] = useState(1);
  const pageSize = 10;
  
  useEffect(() => {
      setPage(1);
  }, [history]);

  const totalPages = Math.ceil(history.length / pageSize);
  const paginatedHistory = history.slice((page - 1) * pageSize, page * pageSize);

  if (history.length === 0) {
      return <p className="text-slate-400 pl-10">Keine Änderungen protokolliert.</p>;
  }

  return (
    <div>
        <div className="space-y-4 relative before:absolute before:left-[19px] before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-100 dark:before:bg-slate-700">
            {paginatedHistory.map((entry: any) => (
                <div key={entry.id} className="relative pl-10">
                    <div className="absolute left-0 top-1.5 w-[40px] h-[40px] bg-white dark:bg-slate-800 border-4 border-slate-50 dark:border-slate-900 rounded-full flex items-center justify-center z-10">
                        <div className={`w-3 h-3 rounded-full ${entry.action === 'ERSTELLT' ? 'bg-emerald-400' : 'bg-indigo-400'}`}></div>
                    </div>
                    <div className={cardClassName}>
                        <div className="flex justify-between items-start mb-2">
                            <div>
                                <span className="block font-bold text-slate-800 dark:text-slate-200">{entry.username}</span>
                                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{entry.action}</span>
                            </div>
                            <span className="text-xs font-mono text-slate-400 bg-slate-50 dark:bg-slate-900 px-2 py-1 rounded-md border border-slate-100 dark:border-slate-700">
                                {new Date(entry.timestamp).toLocaleString()}
                            </span>
                        </div>
                        {(() => {
                            try {
                                const details = JSON.parse(entry.details);
                                if (Array.isArray(details)) {
                                    return (
                                        <div className="mt-3 space-y-1 border-t border-slate-100 dark:border-slate-700 pt-3">
                                            {details.map((change: any, i: number) => (
                                                <div key={i} className="text-xs flex flex-wrap items-center gap-x-2 gap-y-1 text-slate-600 dark:text-slate-400">
                                                    <span className="font-bold bg-slate-50 dark:bg-slate-900 px-1.5 py-0.5 rounded-sm border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300">{change.field}</span>
                                                    <span className="line-through opacity-50 decoration-rose-400/50">{change.old || <span className="italic text-[10px]">leer</span>}</span>
                                                    <span className="text-slate-300">➜</span>
                                                    <span className="font-bold text-indigo-600 dark:text-indigo-400">{change.new || <span className="italic text-[10px]">leer</span>}</span>
                                                </div>
                                            ))}
                                        </div>
                                    );
                                }
                            } catch (e) {}
                            return null;
                        })()}
                    </div>
                </div>
            ))}
        </div>
        {totalPages > 1 && (
            <div className="flex justify-center items-center gap-4 mt-8 pl-10">
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-xs disabled:opacity-50 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                    Neuere
                </button>
                <span className="text-xs font-bold text-slate-400">Seite {page} von {totalPages}</span>
                <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-xs disabled:opacity-50 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                    Ältere
                </button>
            </div>
        )}
    </div>
  );
};
