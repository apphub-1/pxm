import React, { useState, useEffect, useRef, useMemo } from 'react';
import { ChevronDown, CheckSquare, Square } from 'lucide-react';

export const MultiSelectPicker = ({ value, onChange, options, readOnly }: any) => {
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  const selectedValues = useMemo(() => {
      return value ? value.split(';').map((s: string) => s.trim()).filter(Boolean) : [];
  }, [value]);

  useEffect(() => {
    const handleClickOutside = (event: any) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [wrapperRef]);

  const toggleValue = (val: string) => {
      let newValues;
      if (selectedValues.includes(val)) {
          newValues = selectedValues.filter((v: string) => v !== val);
      } else {
          newValues = [...selectedValues, val];
      }
      onChange(newValues.join('; '));
  };

  return (
    <div className="relative w-full" ref={wrapperRef}>
      <div 
        className={`w-full p-2 bg-white dark:bg-slate-800 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 min-h-[38px] flex flex-wrap gap-1 items-center cursor-pointer transition-all duration-200 ease-in-out ${readOnly ? 'opacity-60 cursor-not-allowed' : ''} border-slate-200 dark:border-slate-700`}
        onClick={() => !readOnly && setIsOpen(!isOpen)}
      >
        {selectedValues.length === 0 && <span className="text-slate-400 text-sm">Wählen...</span>}
        {selectedValues.map((v: string) => (
            <span key={v} className="bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 px-1.5 py-0.5 rounded text-xs font-bold border border-indigo-100 dark:border-indigo-800">{v}</span>
        ))}
        <div className="ml-auto"><ChevronDown className="w-3 h-3 text-slate-400" /></div>
      </div>
      
      {isOpen && (
          <div className="mt-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-sm max-h-60 overflow-y-auto custom-scrollbar z-50 absolute w-full">
              {options.map((opt: string) => (
                  <div 
                    key={opt} 
                    className={`p-2 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 cursor-pointer border-b border-slate-50 dark:border-slate-700 last:border-0 text-sm flex items-center gap-2 ${selectedValues.includes(opt) ? 'bg-indigo-50/50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300 font-bold' : 'text-slate-700 dark:text-slate-300'}`}
                    onClick={() => toggleValue(opt)}
                  >
                      {selectedValues.includes(opt) ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4 text-slate-300" />}
                      {opt}
                  </div>
              ))}
          </div>
      )}
    </div>
  );
};
