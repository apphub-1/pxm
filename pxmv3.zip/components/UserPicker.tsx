import React, { useState, useEffect, useRef } from 'react';
import { HelpCircle, RefreshCw, User } from 'lucide-react';
import { getAccessToken } from '../auth';
import { API_BASE_URL } from '../config';

export const UserPicker = ({ label, value, onChange, tooltip, className, readOnly }: any) => {
  const [query, setQuery] = useState(value || '');
  const [results, setResults] = useState<any[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const searchTimeout = useRef<any>(null);
  const abortController = useRef<AbortController | null>(null);

  useEffect(() => {
    setQuery(value || '');
  }, [value]);

  useEffect(() => {
    const handleClickOutside = (event: any) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [wrapperRef]);

  const handleSearch = (val: string) => {
    setQuery(val);
    onChange(val); 
    
    if (searchTimeout.current) clearTimeout(searchTimeout.current);
    if (abortController.current) abortController.current.abort(); // Alte Anfrage abbrechen

    if (val.length < 3) {
        setResults([]);
        setIsOpen(false);
        setLoading(false);
        return;
    }

    searchTimeout.current = setTimeout(async () => {
      setLoading(true);
      const controller = new AbortController();
      abortController.current = controller;

      try {
          const token = getAccessToken();
          const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
          const res = await fetch(`${API_BASE_URL}/directory/search?q=${encodeURIComponent(val)}`, { headers, signal: controller.signal });
          if (res.ok) {
              const data = await res.json();
              setResults(data);
              setIsOpen(true);
          }
      } catch (e) {
          if ((e as Error).name !== 'AbortError') console.error("Search failed:", e);
      } finally {
          if (abortController.current === controller) setLoading(false);
      }
    }, 300);
  };

  const selectUser = (u: any) => {
      const display = `${u.displayName} (${u.username})`;
      setQuery(display);
      onChange(display);
      setIsOpen(false);
  };

  return (
    <div className={`relative ${className || 'mb-4'}`} ref={wrapperRef}>
      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 flex items-center gap-2">
        {label}
        {tooltip && <div className="group relative"><HelpCircle className="w-3 h-3 text-slate-400 cursor-help" /><div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 bg-slate-800 text-white text-xs rounded hidden group-hover:block z-50">{tooltip}</div></div>}
      </label>
      <div className="relative">
        <input 
            type="text" 
            className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md focus:ring-2 focus:ring-indigo-500 outline-none text-sm font-medium pr-10 dark:text-slate-200"
            value={query}
            onChange={e => handleSearch(e.target.value)}
            onFocus={() => query.length >= 3 && setIsOpen(true)}
            placeholder="Name oder Kennung suchen..."
            disabled={readOnly}
            maxLength={500}
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <User className="w-4 h-4" />}
        </div>
      </div>
      
      {isOpen && results.length > 0 && (
          <div className="absolute z-50 left-0 right-0 mt-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xl max-h-60 overflow-y-auto custom-scrollbar">
              {results.map((u: any) => (
                  <div 
                    key={u.username} 
                    className="p-3 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 cursor-pointer border-b border-slate-50 dark:border-slate-700 last:border-0"
                    onClick={() => selectUser(u)}
                  >
                      <div className="font-bold text-sm text-slate-800 dark:text-slate-200">{u.displayName}</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 flex gap-2">
                          <span>{u.username}</span>
                          {u.email && <span>• {u.email}</span>}
                      </div>
                  </div>
              ))}
          </div>
      )}
    </div>
  );
};
