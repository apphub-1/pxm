import React, { useState } from 'react';
import { Database, Settings, LogIn, ShieldCheck, FileCheck, AlertTriangle, Link2, Shield, ChevronRight, HelpCircle, CheckSquare, Square, CheckCircle, FileText } from 'lucide-react';
import { ONBOARDING_SECTIONS } from '../constants';
import { UserPicker } from '../components/UserPicker';

interface OnboardingTabProps {
  data: any;
  setData: (data: any) => void; // Simplified setter
  openSections: Record<string, boolean>;
  toggleSection: (id: string) => void;
  readOnly: boolean;
  governanceRow: any;
}

export const OnboardingTab: React.FC<OnboardingTabProps> = ({
  data,
  setData,
  openSections,
  toggleSection,
  readOnly,
  governanceRow
}) => {
  const [visibleNotes, setVisibleNotes] = useState<Record<string, boolean>>({});

  const updateField = (field: string, value: any) => {
    setData((prev: any) => ({ ...prev, [field]: value }));
  };

  const renderInput = (label: string, field: string, type = 'text', tooltip?: string, options?: string[]) => (
    <div className="mb-4">
      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 flex items-center gap-2">
        {label}
        {tooltip && <div className="group relative"><HelpCircle className="w-3 h-3 text-slate-400 cursor-help" /><div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 bg-slate-800 text-white text-xs rounded hidden group-hover:block z-50">{tooltip}</div></div>}
      </label>
      {options ? (
        <select 
            className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm font-medium dark:text-slate-200"
            value={data[field] || ''}
            onChange={e => updateField(field, e.target.value)}
            disabled={readOnly}
        >
            <option value="">Bitte wählen...</option>
            {options.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      ) : (
        <input 
            type={type} 
            className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm font-medium dark:text-slate-200"
            value={data[field] || ''}
            onChange={e => updateField(field, e.target.value)}
            disabled={readOnly}
            maxLength={500}
        />
      )}
    </div>
  );

  const renderCheckbox = (label: string, field: string) => (
      <div className={`mb-4 flex items-center gap-3 ${readOnly ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'}`} onClick={() => !readOnly && updateField(field, !data[field])}>
          {data[field] ? <CheckSquare className="w-5 h-5 text-indigo-600" /> : <Square className="w-5 h-5 text-slate-300" />}
          <span className="text-sm font-medium text-slate-700 dark:text-slate-300">{label}</span>
      </div>
  );

  const renderMatrix = () => {
      const variants = ['Anbindungsvariante 1', 'Anbindungsvariante 2', 'Anbindungsvariante 3'];
      const criticalities = ['1-niedrig', '2-mittel', '3-hoch', '4-kritisch'];
      const currentCriticality = governanceRow['Kritikalität'];
      
      return (
          <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm">
                  <thead>
                      <tr>
                          <th className="p-3 border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-left dark:text-slate-300">Kritikalität</th>
                          {variants.map(v => <th key={v} className={`p-3 border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-slate-300 ${v.includes('3') ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300' : ''}`}>{v}</th>)}
                      </tr>
                  </thead>
                  <tbody>
                      {criticalities.map(crit => (
                          <tr key={crit}>
                              <td className="p-3 border border-slate-200 dark:border-slate-700 font-bold text-slate-600 dark:text-slate-300">{crit}</td>
                              {variants.map(v => {
                                  const isSelected = data.selectedVariant === v && currentCriticality === crit;
                                  return (
                                      <td 
                                        key={v} 
                                        className={`p-3 border border-slate-200 dark:border-slate-700 text-center transition-colors ${isSelected ? 'bg-emerald-50 dark:bg-emerald-900/20 ring-2 ring-inset ring-emerald-500' : (currentCriticality === crit ? 'bg-slate-50 dark:bg-slate-800' : '')} ${readOnly ? 'pointer-events-none' : ''}`}
                                      >
                                          {isSelected && <CheckCircle className="w-5 h-5 text-emerald-500 mx-auto" />}
                                      </td>
                                  );
                              })}
                          </tr>
                      ))}
                  </tbody>
              </table>
              <div className="mt-4 p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl border border-indigo-100 dark:border-indigo-800">
                  <p className="text-sm font-bold text-indigo-900 dark:text-indigo-300">Ausgewählte Konfiguration:</p>
                  <p className="text-indigo-700 dark:text-indigo-400">
                    {currentCriticality ? `Kritikalität: ${currentCriticality}` : 'Keine Kritikalität gewählt'} 
                    {' ➜ '} 
                    {data.selectedVariant || 'Bitte Konfiguration wählen'}
                  </p>
              </div>
          </div>
      );
  };

  const toggleNote = (sectionId: string) => {
      setVisibleNotes(prev => ({ ...prev, [sectionId]: !prev[sectionId] }));
  };

  const renderSectionNote = (sectionId: string) => {
      const fieldName = `note_${sectionId}`;
      const noteValue = data[fieldName] || '';
      const isVisible = visibleNotes[sectionId] || !!noteValue;

      return (
          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-700">
              {!isVisible ? (
                  <button onClick={() => toggleNote(sectionId)} className="flex items-center gap-2 text-xs font-bold text-indigo-600 hover:text-indigo-700 transition-colors mb-2">
                      <FileText className="w-4 h-4" />
                      Anmerkung hinzufügen
                  </button>
              ) : (
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-wider mb-2"><FileText className="w-4 h-4" /> Anmerkung</div>
              )}
              {isVisible && (
                  <div className="animate-in fade-in slide-in-from-top-1 duration-200">
                      <textarea className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm font-medium dark:text-slate-200" value={noteValue} onChange={e => updateField(fieldName, e.target.value)} disabled={readOnly} rows={3} placeholder="Anmerkung zu diesem Bereich..." />
                  </div>
              )}
          </div>
      );
  };

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
        
        {/* Section 1: Architecture */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('architecture')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Database className="w-5 h-5 text-indigo-500" /> 1. Architektur</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['architecture'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['architecture'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                    <div className="mb-4">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Architektur des Zielsystems</label>
                        <textarea className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md h-24 text-sm dark:text-slate-200" value={data.archDesc || ''} onChange={e => updateField('archDesc', e.target.value)} disabled={readOnly} maxLength={500}></textarea>
                    </div>
                    {renderInput("Betriebssysteme", "osList")}
                    {renderInput("Datenbanken", "dbList")}
                    {renderCheckbox("Ist geplant, die Server auszutauschen?", "serverReplace")}
                    {data.serverReplace && renderInput("Geplantes Austauschdatum", "serverReplaceDate", "date")}
                    {renderCheckbox("Load Balancer / Reverse Proxy vorhanden?", "hasLoadBalancer")}
                    {renderSectionNote('architecture')}
                </div>
            )}
        </div>

        {/* Section 2: Technology */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('technology')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Settings className="w-5 h-5 text-slate-500" /> 2. Anwendungstechnologie</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['technology'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['technology'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 grid grid-cols-1 md:grid-cols-2 gap-6">
                    {renderInput("Technologie", "techType", "text", undefined, ["Fat Client", "Webbasiert", "Java", "Mischform", "Cloud-Service"])}
                    {renderCheckbox("Werden Zertifikate benötigt?", "needsCerts")}
                    {renderCheckbox("Aktives 4-Augen-Prinzip?", "fourEyes")}
                    {renderInput("Lizenzart", "licenseType", "text", undefined, ["Accountgebunden", "Identitätsgebunden", "Serverbasiert"])}
                    {renderInput("URL Produktion", "urlProd")}
                    {renderInput("URL Test", "urlTest")}
                    {renderSectionNote('technology')}
                </div>
            )}
        </div>

        {/* Section 3: Login */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('login')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><LogIn className="w-5 h-5 text-emerald-500" /> 3. Anmeldeverfahren</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['login'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['login'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                    {renderInput("Anmeldeverfahren", "loginMethod", "text", undefined, ["Single Sign-On", "Anmeldemaske", "Multifaktor-Authentifizierung", "anderes"])}
                    {renderInput("Account-Typ", "accountType", "text", "Wichtig für Passwort-Prozess", ["Lokale Accounts", "Domain Accounts"])}
                    {renderCheckbox("Kann User mehrere Sessions öffnen?", "multiSession")}
                    {renderInput("Username Nomenklatur", "usernameNaming")}
                    {renderSectionNote('login')}
                </div>
            )}
        </div>

        {/* Section 4: Password (Conditional) */}
        {data.accountType !== 'Domain Accounts' && (
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('password')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><ShieldCheck className="w-5 h-5 text-rose-500" /> 4. Passwortwechsel</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['password'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['password'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                    <div className="mb-4">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Wie werden Passwörter geändert?</label>
                        <textarea className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md h-20 text-sm dark:text-slate-200" value={data.pwChangeDesc || ''} onChange={e => updateField('pwChangeDesc', e.target.value)} disabled={readOnly} maxLength={500}></textarea>
                    </div>
                    {renderCheckbox("Kann Rotation automatisiert werden?", "autoRotation")}
                    {renderInput("Wer ändert Passwörter?", "whoChangesPw")}
                    {renderInput("Wechselintervall", "pwInterval")}
                    {renderSectionNote('password')}
                </div>
            )}
        </div>
        )}

        {/* Section 5: Test */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('test')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><FileCheck className="w-5 h-5 text-amber-500" /> 5. Testuser & Umgebung</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['test'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['test'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                    {renderCheckbox("Testuser vorhanden?", "hasTestUsers")}
                    {data.hasTestUsers && renderInput("Testuser Accounts", "testUsersList")}
                    {renderCheckbox("Rechte über Omada?", "omadaRights")}
                    {renderSectionNote('test')}
                </div>
            )}
        </div>

        {/* Section 6: Emergency */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('emergency')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><AlertTriangle className="w-5 h-5 text-rose-500" /> 6. Notfallprozess</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['emergency'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['emergency'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                    {renderCheckbox("Existieren Notfallaccounts?", "hasEmergencyAccounts")}
                    {data.hasEmergencyAccounts && renderInput("Notfall Accounts", "emergencyAccountsList")}
                    {renderSectionNote('emergency')}
                </div>
            )}
        </div>

        {/* Section 7: Matrix */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('matrix')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Link2 className="w-5 h-5 text-indigo-600" /> 7. Vereinbarte Anbindungsvariante</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['matrix'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['matrix'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                        {renderInput("Anmeldung", "matrixLogin", "text", undefined, ["Automatisch", "Manuell"])}
                        {renderInput("Passwortwechsel", "matrixPwChange", "text", undefined, ["Automatisch", "Manuell"])}
                    </div>
                    {renderMatrix()}
                    {renderSectionNote('matrix')}
                </div>
            )}
        </div>

        {/* Section 8: Bypass */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('bypass')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Shield className="w-5 h-5 text-rose-500" /> 8. PAM-Bypass Regeln</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['bypass'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['bypass'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                    {renderInput("S-Base Pro Auftrag", "sBaseProOrder")}
                    {renderSectionNote('bypass')}
                </div>
            )}
        </div>

    </div>
  );
};
