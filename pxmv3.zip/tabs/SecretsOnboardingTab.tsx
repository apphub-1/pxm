import React, { useState } from 'react';
import { Server, Settings, Database, Cloud, Key, RefreshCw, Link2, ChevronRight, HelpCircle, CheckSquare, Square, FileDown, FileSpreadsheet, Trash2, Plus, AlertTriangle, Layers, ChevronDown, FileText, X } from 'lucide-react';
import { SECRETS_ONBOARDING_SECTIONS } from '../constants';
import { MultiSelectPicker } from '../components/MultiSelectPicker';
import { getAccessToken } from '../auth';
import { API_BASE_URL } from '../config';
import { downloadInfrastructureTemplate, importInfrastructure } from '../utils/excelExport';

interface SecretsOnboardingTabProps {
  data: any;
  setData: (data: any) => void;
  openSections: Record<string, boolean>;
  toggleSection: (id: string) => void;
  readOnly: boolean;
  governanceRow: any;
}

export const SecretsOnboardingTab: React.FC<SecretsOnboardingTabProps> = ({
  data,
  setData,
  openSections,
  toggleSection,
  readOnly,
  governanceRow
}) => {
  const [activeComponentIndex, setActiveComponentIndex] = useState<number | null>(null);
  const [isAddComponentModalOpen, setIsAddComponentModalOpen] = useState(false);
  const [newComponentName, setNewComponentName] = useState('');
  const [selectedContainerType, setSelectedContainerType] = useState('Kubernetes');
  const [visibleNotes, setVisibleNotes] = useState<Record<string, boolean>>({});

  // Derived Options
  const serverRegistryOptions = (data.serverRegistry || []).map((s: any) => s.hostname).filter(Boolean);
  const containerRegistryOptions = (data.containerRegistry || []).map((c: any) => c.name).filter(Boolean);
  const serverClusterOptions = (data.serverClusters || []).map((c: any) => c.name).filter(Boolean);
  const componentOptions = (data.components || []).map((c: any) => c.name).filter(Boolean);

  const CONTAINER_DEFINITIONS: Record<string, { label: string, headers: string[], fields: { key: string, placeholder: string }[] }> = {
      'Kubernetes': { 
          label: 'Kubernetes', 
          headers: ['Cluster ID', 'Namespace', 'Systemkomponente'],
          fields: [
              { key: 'name', placeholder: 'Cluster ID' },
              { key: 'namespace', placeholder: 'Namespace' },
              { key: 'component', placeholder: '' }
          ]
      },
      'Docker': { 
          label: 'Docker', 
          headers: ['Container Name / ID', 'Host / IP', 'Systemkomponente'],
          fields: [
              { key: 'name', placeholder: 'Container Name / ID' },
              { key: 'apiUrl', placeholder: 'Host / IP' },
              { key: 'component', placeholder: '' }
          ]
      },
      'Podman': { 
          label: 'Podman', 
          headers: ['Pod / Container Name', 'Host / IP', 'Systemkomponente'],
          fields: [
              { key: 'name', placeholder: 'Pod / Container Name' },
              { key: 'apiUrl', placeholder: 'Host / IP' },
              { key: 'component', placeholder: '' }
          ]
      },
      'Azure Keyvault': { 
          label: 'Azure Keyvault', 
          headers: ['Keyvault Name', 'Resource Group', 'Systemkomponente'],
          fields: [
              { key: 'name', placeholder: 'Keyvault Name' },
              { key: 'namespace', placeholder: 'Resource Group' },
              { key: 'component', placeholder: '' }
          ]
      }
  };

  const updateField = (field: string, value: any) => {
    setData((prev: any) => ({ ...prev, [field]: value }));
  };

  const addComponent = () => {
      setNewComponentName('');
      setIsAddComponentModalOpen(true);
  };

  const confirmAddComponent = (e: React.FormEvent) => {
      e.preventDefault();
      if (newComponentName.trim()) {
          setData((prev: any) => {
              const components = [...(prev.components || []), { name: newComponentName.trim() }];
              return { ...prev, components };
          });
          setActiveComponentIndex((data.components?.length || 0));
          setIsAddComponentModalOpen(false);
      }
  };

  const deleteComponent = (index: number, e: React.MouseEvent) => {
      e.stopPropagation();
      if(confirm("Komponente wirklich löschen?")) {
          setData((prev: any) => {
              const components = [...(prev.components || [])];
              components.splice(index, 1);
              return { ...prev, components };
          });
          if (activeComponentIndex === index) setActiveComponentIndex(null);
          else if (activeComponentIndex !== null && activeComponentIndex > index) setActiveComponentIndex(activeComponentIndex - 1);
      }
  };

  // --- Infrastructure Helpers ---
  const updateServerRegistry = (index: number, field: string, value: any) => {
      setData((prev: any) => {
          const list = [...(prev.serverRegistry || [])];
          list[index] = { ...list[index], [field]: value };
          return { ...prev, serverRegistry: list };
      });
  };

  const addServerRegistryRow = () => {
      setData((prev: any) => ({
          ...prev,
          serverRegistry: [...(prev.serverRegistry || []), { segment: 'Produktion' }]
      }));
  };

  const removeServerRegistryRow = (index: number) => {
      setData((prev: any) => {
          const list = [...(prev.serverRegistry || [])];
          list.splice(index, 1);
          return { ...prev, serverRegistry: list };
      });
  };

  const resolveHostname = async (index: number, hostname: string) => {
      if (!hostname) return;
      try {
          const token = getAccessToken();
          const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
          const res = await fetch(`${API_BASE_URL}/dns/resolve?hostname=${encodeURIComponent(hostname)}`, { headers });
          if (res.ok) {
              const { address } = await res.json();
              if (address) {
                  updateServerRegistry(index, 'ip', address);
              }
          }
      } catch (e) {
          console.error(e);
      }
  };

  const updateServerCluster = (index: number, field: string, value: any) => {
      setData((prev: any) => {
          const list = [...(prev.serverClusters || [])];
          list[index] = { ...list[index], [field]: value };
          return { ...prev, serverClusters: list };
      });
  };

  const addServerCluster = () => {
      setData((prev: any) => ({
          ...prev,
          serverClusters: [...(prev.serverClusters || []), {}]
      }));
  };

  const removeServerCluster = (index: number) => {
      setData((prev: any) => {
          const list = [...(prev.serverClusters || [])];
          list.splice(index, 1);
          return { ...prev, serverClusters: list };
      });
  };

  const updateContainerRegistry = (index: number, field: string, value: any) => {
      setData((prev: any) => {
          const list = [...(prev.containerRegistry || [])];
          list[index] = { ...list[index], [field]: value };
          return { ...prev, containerRegistry: list };
      });
  };

  const addContainerRegistryRow = (type: string) => {
      setData((prev: any) => ({
          ...prev,
          containerRegistry: [...(prev.containerRegistry || []), { type }]
      }));
  };

  const removeContainerRegistryRow = (index: number) => {
      setData((prev: any) => {
          const list = [...(prev.containerRegistry || [])];
          list.splice(index, 1);
          return { ...prev, containerRegistry: list };
      });
  };

  const updateDatabaseRegistry = (index: number, field: string, value: any) => {
      setData((prev: any) => {
          const list = [...(prev.databaseRegistry || [])];
          list[index] = { ...list[index], [field]: value };
          return { ...prev, databaseRegistry: list };
      });
  };

  const addDatabaseRegistryRow = () => {
      setData((prev: any) => ({
          ...prev,
          databaseRegistry: [...(prev.databaseRegistry || []), { dbType: 'MSSQL' }]
      }));
  };

  const removeDatabaseRegistryRow = (index: number) => {
      setData((prev: any) => {
          const list = [...(prev.databaseRegistry || [])];
          list.splice(index, 1);
          return { ...prev, databaseRegistry: list };
      });
  };

  // --- Render Helpers ---
  const renderInput = (label: string, field: string, type = 'text', tooltip?: string, options?: string[], isComponent = false) => {
    const value = isComponent 
        ? (data.components?.[activeComponentIndex!]?.[field] || '') 
        : (data[field] || '');

    const handleChange = (val: any) => {
        if (isComponent) {
            if (activeComponentIndex === null) return;
            setData((prev: any) => {
                const components = [...(prev.components || [])];
                if (!components[activeComponentIndex]) components[activeComponentIndex] = {};
                components[activeComponentIndex] = { ...components[activeComponentIndex], [field]: val };
                return { ...prev, components };
            });
        } else {
            updateField(field, val);
        }
    };

    return (
    <div className="mb-4">
      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 flex items-center gap-2">
        {label}
        {tooltip && <div className="group relative"><HelpCircle className="w-3 h-3 text-slate-400 cursor-help" /><div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 bg-slate-800 text-white text-xs rounded hidden group-hover:block z-50">{tooltip}</div></div>}
      </label>
      {options ? (
        <select 
            className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm font-medium dark:text-slate-200"
            value={value}
            onChange={e => handleChange(e.target.value)}
            disabled={readOnly}
        >
            <option value="">Bitte wählen...</option>
            {options.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      ) : (
        <input 
            type={type} 
            className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm font-medium dark:text-slate-200"
            value={value}
            onChange={e => handleChange(e.target.value)}
            disabled={readOnly}
            maxLength={500}
        />
      )}
    </div>
    );
  };

  const renderMultiSelect = (label: string, field: string, options: string[], isComponent = false) => {
      const currentValues = isComponent
        ? ((data.components?.[activeComponentIndex!]?.[field] as string[]) || [])
        : ((data[field] as string[]) || []);

      const toggleValue = (val: string) => {
          const newValues = currentValues.includes(val)
              ? currentValues.filter(v => v !== val)
              : [...currentValues, val];
          
          if (isComponent) {
            if (activeComponentIndex === null) return;
            setData((prev: any) => {
                const components = [...(prev.components || [])];
                if (!components[activeComponentIndex]) components[activeComponentIndex] = {};
                components[activeComponentIndex] = { ...components[activeComponentIndex], [field]: newValues };
                return { ...prev, components };
            });
          } else {
            updateField(field, newValues);
          }
      };

      return (
          <div className="mb-4">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{label}</label>
              <div className="space-y-2">
                  {options.map(opt => (
                      <div key={opt} className={`flex items-center gap-2 p-1 rounded ${readOnly ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800'}`} onClick={() => !readOnly && toggleValue(opt)}>
                          {currentValues.includes(opt) ? <CheckSquare className="w-4 h-4 text-indigo-600" /> : <Square className="w-4 h-4 text-slate-300" />}
                          <span className="text-sm text-slate-700 dark:text-slate-300">{opt}</span>
                      </div>
                  ))}
              </div>
          </div>
      );
  };

  const toggleNote = (sectionId: string) => {
      setVisibleNotes(prev => ({ ...prev, [sectionId]: !prev[sectionId] }));
  };

  const renderSectionNote = (sectionId: string) => {
      const fieldName = `note_${sectionId}`;
      const component = data.components?.[activeComponentIndex!];
      const noteValue = component?.[fieldName] || '';
      const isVisible = visibleNotes[sectionId] || !!noteValue;

      const handleNoteChange = (val: string) => {
          if (activeComponentIndex === null) return;
          setData((prev: any) => {
              const components = [...(prev.components || [])];
              if (!components[activeComponentIndex]) components[activeComponentIndex] = {};
              components[activeComponentIndex] = { ...components[activeComponentIndex], [fieldName]: val };
              return { ...prev, components };
          });
      };

      return (
          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-700">
              {!isVisible ? (
                  <button onClick={() => toggleNote(sectionId)} className="flex items-center gap-2 text-xs font-bold text-indigo-600 hover:text-indigo-700 transition-colors mb-2">
                      <FileText className="w-4 h-4" />
                      Anmerkung hinzufügen
                  </button>
              ) : (
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-wider mb-2"><FileText className="w-4 h-4" /> Anmerkung</div>
              )}
              {isVisible && (
                  <div className="animate-in fade-in slide-in-from-top-1 duration-200">
                      <textarea className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm font-medium dark:text-slate-200" value={noteValue} onChange={e => handleNoteChange(e.target.value)} disabled={readOnly} rows={3} placeholder="Anmerkung zu diesem Bereich..." />
                  </div>
              )}
          </div>
      );
  };

  const renderComponentSelector = (currentValue: string, onChange: (val: string) => void, options: string[]) => {
      const selected = currentValue ? currentValue.split(';').map(s => s.trim()).filter(Boolean) : [];
      
      const handleAdd = (val: string) => {
          if (!val) return;
          if (!selected.includes(val)) {
              const newValue = [...selected, val].join(';');
              onChange(newValue);
          }
      };

      const handleRemove = (val: string) => {
          const newValue = selected.filter(s => s !== val).join(';');
          onChange(newValue);
      };

      return (
          <div className="flex flex-col gap-1.5 min-w-[180px]">
              {selected.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-1">
                      {selected.map(s => (
                          <span key={s} className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-800">
                              {s}
                              {!readOnly && (
                                  <button onClick={(e) => { e.preventDefault(); handleRemove(s); }} className="hover:text-indigo-900 dark:hover:text-indigo-100 p-0.5 rounded-full hover:bg-indigo-100 dark:hover:bg-indigo-800 transition-colors">
                                      <X className="w-3 h-3" />
                                  </button>
                              )}
                          </span>
                      ))}
                  </div>
              )}
              {!readOnly && (
                  <select 
                      className="w-full p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs"
                      value=""
                      onChange={e => handleAdd(e.target.value)}
                  >
                      <option value="">+ Komponente</option>
                      {options.filter(o => !selected.includes(o)).map(o => (
                          <option key={o} value={o}>{o}</option>
                      ))}
                  </select>
              )}
              {readOnly && selected.length === 0 && <span className="text-slate-400 italic text-xs">-</span>}
          </div>
      );
  };

  // --- Excel Import/Export ---
  const handleInfrastructureTemplateDownload = async () => {
      downloadInfrastructureTemplate(governanceRow, componentOptions, serverRegistryOptions);
  };

  const handleInfrastructureImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      try {
          const { data: importedData, count } = await importInfrastructure(file);
          
          if (count > 0) {
              setData((prev: any) => {
                  const merged = { ...prev };
                  Object.keys(importedData).forEach(key => {
                      if (Array.isArray(importedData[key])) {
                          merged[key] = [...(prev[key] || []), ...importedData[key]];
                      } else {
                          merged[key] = importedData[key]; // boolean flags
                      }
                  });
                  return merged;
              });
              alert(`${count} Einträge erfolgreich importiert.`);
          } else {
              alert("Keine Daten gefunden oder Arbeitsblätter falsch benannt.");
          }
      } catch (err) {
          console.error(err);
          alert("Fehler beim Importieren.");
      } finally {
          e.target.value = '';
      }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
        {/* 1. Infrastruktur */}
        {data.components && data.components.length > 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('infrastructure')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Server className="w-5 h-5 text-indigo-500" /> 1. Infrastruktur</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['infrastructure'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['infrastructure'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                    
                    <div className="flex flex-wrap gap-3 mb-6 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-100 dark:border-slate-800">
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center w-full mb-2">Zusätzliche Register:</span>
                        
                        <button 
                            type="button"
                            onClick={() => updateField('showServerClusters', !data.showServerClusters)}
                            className={`px-3 py-2 rounded-md text-xs font-bold border transition-all flex items-center gap-2 ${data.showServerClusters ? 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300' : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
                        >
                            {data.showServerClusters ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                            Server Cluster
                        </button>

                        <button 
                            type="button"
                            onClick={() => updateField('showContainerRegistry', !data.showContainerRegistry)}
                            className={`px-3 py-2 rounded-md text-xs font-bold border transition-all flex items-center gap-2 ${data.showContainerRegistry ? 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300' : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
                        >
                            {data.showContainerRegistry ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                            Container- / Cluster-Register
                        </button>

                        <button 
                            type="button"
                            onClick={() => updateField('showDatabaseRegistry', !data.showDatabaseRegistry)}
                            className={`px-3 py-2 rounded-md text-xs font-bold border transition-all flex items-center gap-2 ${data.showDatabaseRegistry ? 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300' : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
                        >
                            {data.showDatabaseRegistry ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                            Datenbankregister
                        </button>
                    </div>

                    {!readOnly && (
                        <div className="flex gap-2 mb-6 pb-6 border-b border-slate-100 dark:border-slate-700">
                            <button onClick={handleInfrastructureTemplateDownload} className="flex items-center gap-2 text-sm font-bold text-slate-600 hover:text-slate-700 px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800 dark:text-slate-300 rounded-lg transition-colors border border-slate-200 dark:border-slate-700" title="Excel-Vorlage für gesamte Infrastruktur herunterladen"><FileDown className="w-4 h-4" /> Infrastruktur-Vorlage</button>
                            <label className="flex items-center gap-2 text-sm font-bold text-emerald-600 hover:text-emerald-700 px-3 py-2 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition-colors cursor-pointer border border-emerald-200 dark:border-emerald-800" title="Infrastruktur Excel importieren"><FileSpreadsheet className="w-4 h-4" /> Infrastruktur Import<input type="file" accept=".xlsx, .xls, .csv" className="hidden" onChange={handleInfrastructureImport} /></label>
                        </div>
                    )}

                    <div className="mt-6 border-t border-slate-100 dark:border-slate-700 pt-4">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Serverregister</label>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm border-collapse">
                                <thead>
                                    <tr className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
                                        <th className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 w-[20%]">Hostname</th>
                                        <th className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 w-[15%]">IP-Adresse</th>
                                        <th className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 w-[15%]">OS</th>
                                        <th className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 w-[15%]">Segment</th>
                                        <th className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 w-[25%]">Systemkomponente</th>
                                        <th className="p-3 w-10"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {(data.serverRegistry || []).map((row: any, idx: number) => (
                                        <tr key={idx} className="border-b border-slate-100 hover:bg-slate-50/50">
                                            <td className="p-2">
                                                <input 
                                                    type="text" 
                                                    className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200"
                                                    value={row.hostname || ''}
                                                    onChange={e => updateServerRegistry(idx, 'hostname', e.target.value)}
                                                    onBlur={e => resolveHostname(idx, e.target.value)}
                                                    placeholder="Hostname"
                                                    disabled={readOnly}
                                                />
                                            </td>
                                            <td className="p-2">
                                                <input 
                                                    type="text" 
                                                    className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200"
                                                    value={row.ip || ''}
                                                    onChange={e => updateServerRegistry(idx, 'ip', e.target.value)}
                                                    placeholder="IP-Adresse"
                                                    disabled={readOnly}
                                                />
                                            </td>
                                            <td className="p-2">
                                                <select 
                                                    className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200"
                                                    value={row.os || ''}
                                                    onChange={e => updateServerRegistry(idx, 'os', e.target.value)}
                                                    disabled={readOnly}
                                                >
                                                    <option value="">-</option>
                                                    <option value="Windows Server">Windows Server</option>
                                                    <option value="RHEL Server">RHEL Server</option>
                                                </select>
                                            </td>
                                            <td className="p-2">
                                                <select 
                                                    className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200"
                                                    value={row.segment || 'Produktion'}
                                                    onChange={e => updateServerRegistry(idx, 'segment', e.target.value)}
                                                    disabled={readOnly}
                                                >
                                                    <option value="Produktion">Produktion</option>
                                                    <option value="Test">Test</option>
                                                    <option value="Entwicklung">Entwicklung</option>
                                                </select>
                                            </td>
                                            <td className="p-2">
                                                {renderComponentSelector(
                                                    row.component || '',
                                                    (val) => updateServerRegistry(idx, 'component', val),
                                                    componentOptions
                                                )}
                                            </td>
                                            <td className="p-2 text-center">
                                                {!readOnly && (
                                                    <button onClick={() => removeServerRegistryRow(idx)} className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-colors">
                                                        <Trash2 className="w-4 h-4" />
                                                    </button>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                    {(data.serverRegistry || []).length === 0 && (
                                        <tr>
                                            <td colSpan={5} className="p-4 text-center text-slate-400 italic">Keine Server eingetragen.</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                            {!readOnly && (
                                <div className="flex gap-2 mt-3">
                                    <button onClick={addServerRegistryRow} className="flex items-center gap-2 text-sm font-bold text-indigo-600 hover:text-indigo-700 px-3 py-2 hover:bg-indigo-50 rounded-lg transition-colors">
                                        <Plus className="w-4 h-4" /> Server hinzufügen
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>

                        {data.showServerClusters && (
                            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-700 animate-in fade-in slide-in-from-top-2 duration-200">
                                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Server Cluster</label>
                                <div className="overflow-x-auto">
                                    <table className="w-full text-sm border-collapse">
                                        <thead>
                                            <tr className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
                                                <th className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 w-1/3">Cluster Name</th>
                                                <th className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 w-1/3">Server Nodes</th>
                                                <th className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 w-1/3">Systemkomponente</th>
                                                <th className="p-3 w-10"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {(data.serverClusters || []).map((row: any, idx: number) => (
                                                <tr key={idx} className="border-b border-slate-100 hover:bg-slate-50/50 dark:hover:bg-slate-800/50">
                                                    <td className="p-2">
                                                        <input type="text" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200" value={row.name || ''} onChange={e => updateServerCluster(idx, 'name', e.target.value)} placeholder="Cluster Name" disabled={readOnly} />
                                                    </td>
                                                    <td className="p-2">
                                                        <MultiSelectPicker value={row.nodes || ''} onChange={(val: string) => updateServerCluster(idx, 'nodes', val)} options={serverRegistryOptions} readOnly={readOnly} />
                                                    </td>
                                                    <td className="p-2">
                                                        {renderComponentSelector(
                                                            row.component || '',
                                                            (val) => updateServerCluster(idx, 'component', val),
                                                            componentOptions
                                                        )}
                                                    </td>
                                                    <td className="p-2 text-center">
                                                        {!readOnly && <button onClick={() => removeServerCluster(idx)} className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"><Trash2 className="w-4 h-4" /></button>}
                                                    </td>
                                                </tr>
                                            ))}
                                            {(data.serverClusters || []).length === 0 && (
                                                <tr><td colSpan={4} className="p-4 text-center text-slate-400 italic">Keine Cluster definiert.</td></tr>
                                            )}
                                        </tbody>
                                    </table>
                                    {!readOnly && (
                                        <div className="flex gap-2 mt-3">
                                            <button onClick={addServerCluster} className="flex items-center gap-2 text-sm font-bold text-indigo-600 hover:text-indigo-700 px-3 py-2 hover:bg-indigo-50 rounded-lg transition-colors"><Plus className="w-4 h-4" /> Cluster hinzufügen</button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                    {data.showContainerRegistry && (
                    <div className="mt-6 border-t border-slate-100 dark:border-slate-700 pt-4 animate-in fade-in slide-in-from-top-2 duration-200">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Container- / Cluster-Register</label>
                        
                        {/* Grouped Tables by Type */}
                        {Object.entries(CONTAINER_DEFINITIONS).map(([typeKey, def]) => {
                            const items = (data.containerRegistry || [])
                                .map((item: any, index: number) => ({ ...item, originalIndex: index }))
                                .filter((item: any) => item.type === typeKey);

                            if (items.length === 0) return null;

                            return (
                                <div key={typeKey} className="mb-6 last:mb-0">
                                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 pl-1">{def.label}</h4>
                                    <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-700">
                                        <table className="w-full text-sm border-collapse">
                                            <thead>
                                                <tr className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
                                                    {def.headers.map(h => (
                                                        <th key={h} className="p-3 text-left font-bold text-slate-600 dark:text-slate-300">{h}</th>
                                                    ))}
                                                    <th className="p-3 w-10"></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {items.map((row: any) => (
                                                    <tr key={row.originalIndex} className="border-b border-slate-100 hover:bg-slate-50/50 dark:hover:bg-slate-800/50 last:border-0">
                                                        {def.fields.map(f => (
                                                            <td key={f.key} className="p-2">
                                                                {f.key === 'component' ? (
                                                                    renderComponentSelector(
                                                                        row.component || '',
                                                                        (val) => updateContainerRegistry(row.originalIndex, 'component', val),
                                                                        componentOptions
                                                                    )
                                                                ) : (
                                                                    <input 
                                                                        type="text" 
                                                                        className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200"
                                                                        value={row[f.key] || ''}
                                                                        onChange={e => updateContainerRegistry(row.originalIndex, f.key, e.target.value)}
                                                                        placeholder={f.placeholder}
                                                                        disabled={readOnly}
                                                                    />
                                                                )}
                                                            </td>
                                                        ))}
                                                        <td className="p-2 text-center">
                                                            {!readOnly && (
                                                                <button onClick={() => removeContainerRegistryRow(row.originalIndex)} className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-colors">
                                                                    <Trash2 className="w-4 h-4" />
                                                                </button>
                                                            )}
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            );
                        })}

                        {(!data.containerRegistry || data.containerRegistry.length === 0) && (
                            <div className="p-8 text-center border border-dashed border-slate-300 dark:border-slate-700 rounded-lg mb-4">
                                <p className="text-slate-400 italic text-sm">Noch keine Container-Umgebungen eingetragen.</p>
                            </div>
                        )}

                        {!readOnly && (
                            <div className="flex gap-2 mt-4 items-center bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
                                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-2">Neuen Eintrag hinzufügen:</span>
                                <div className="relative">
                                    <select 
                                        className="appearance-none bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 py-2 pl-3 pr-8 rounded-lg text-sm font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                                        value={selectedContainerType}
                                        onChange={(e) => setSelectedContainerType(e.target.value)}
                                    >
                                        {Object.keys(CONTAINER_DEFINITIONS).map(t => <option key={t} value={t}>{t}</option>)}
                                    </select>
                                    <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                                </div>
                                <button 
                                    onClick={() => addContainerRegistryRow(selectedContainerType)} 
                                    className="flex items-center gap-2 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 px-4 py-2 rounded-lg transition-colors shadow-sm active:scale-95"
                                >
                                    <Plus className="w-4 h-4" /> Hinzufügen
                                </button>
                            </div>
                        )}
                    </div>
                    )}

                    {data.showDatabaseRegistry && (
                    <div className="mt-6 border-t border-slate-100 dark:border-slate-700 pt-4 animate-in fade-in slide-in-from-top-2 duration-200">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Datenbankregister</label>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm border-collapse">
                                <thead>
                                    <tr className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
                                        <th className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 w-[20%]">Server</th>
                                        <th className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 w-[15%]">Typ</th>
                                        <th className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 w-[20%]">Systemkomponente</th>
                                        <th className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 w-[40%]">Details</th>
                                        <th className="p-3 w-10"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {(data.databaseRegistry || []).map((row: any, idx: number) => (
                                        <tr key={idx} className="border-b border-slate-100 hover:bg-slate-50/50 dark:hover:bg-slate-800/50">
                                            <td className="p-2 align-top">
                                                <select 
                                                    className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200"
                                                    value={row.server || ''}
                                                    onChange={e => updateDatabaseRegistry(idx, 'server', e.target.value)}
                                                    disabled={readOnly}
                                                >
                                                    <option value="">Wählen...</option>
                                                    {serverRegistryOptions.length > 0 && (
                                                        <optgroup label="Server" className="text-blue-600 dark:text-blue-400 font-bold">
                                                            {serverRegistryOptions.map(s => <option key={s} value={s} className="text-slate-900 dark:text-slate-200 font-normal">{s}</option>)}
                                                        </optgroup>
                                                    )}
                                                    {serverClusterOptions.length > 0 && (
                                                        <optgroup label="Server Cluster" className="text-purple-600 dark:text-purple-400 font-bold">
                                                            {serverClusterOptions.map(s => <option key={s} value={s} className="text-slate-900 dark:text-slate-200 font-normal">{s}</option>)}
                                                        </optgroup>
                                                    )}
                                                    {containerRegistryOptions.length > 0 && (
                                                        <optgroup label="Container / Cloud" className="text-emerald-600 dark:text-emerald-400 font-bold">
                                                            {containerRegistryOptions.map(s => <option key={s} value={s} className="text-slate-900 dark:text-slate-200 font-normal">{s}</option>)}
                                                        </optgroup>
                                                    )}
                                                </select>
                                            </td>
                                            <td className="p-2 align-top">
                                                <select 
                                                    className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200"
                                                    value={row.dbType || 'MSSQL'}
                                                    onChange={e => updateDatabaseRegistry(idx, 'dbType', e.target.value)}
                                                    disabled={readOnly}
                                                >
                                                    <option value="MSSQL">MSSQL</option>
                                                    <option value="MySQL">MySQL</option>
                                                    <option value="Postgres">Postgres</option>
                                                    <option value="Oracle">Oracle</option>
                                                    <option value="DB2">DB2</option>
                                                </select>
                                            </td>
                                            <td className="p-2 align-top">
                                                {renderComponentSelector(
                                                    row.component || '',
                                                    (val) => updateDatabaseRegistry(idx, 'component', val),
                                                    componentOptions
                                                )}
                                            </td>
                                            <td className="p-2">
                                                <div className="space-y-2">
                                                    {row.dbType === 'MSSQL' && (
                                                        <>
                                                            <input type="text" placeholder="Instanzname" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.instance || ''} onChange={e => updateDatabaseRegistry(idx, 'instance', e.target.value)} disabled={readOnly} />
                                                            <input type="text" placeholder="Port (1433)" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.port || ''} onChange={e => updateDatabaseRegistry(idx, 'port', e.target.value)} disabled={readOnly} />
                                                            <select className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.authType || ''} onChange={e => updateDatabaseRegistry(idx, 'authType', e.target.value)} disabled={readOnly}>
                                                                <option value="">Auth-Typ wählen...</option>
                                                                <option value="Windows">Windows Auth</option>
                                                                <option value="SQL">SQL Auth</option>
                                                            </select>
                                                        </>
                                                    )}
                                                    {row.dbType === 'MySQL' && (
                                                        <>
                                                            <input type="text" placeholder="Port (3306)" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.port || ''} onChange={e => updateDatabaseRegistry(idx, 'port', e.target.value)} disabled={readOnly} />
                                                            <input type="text" placeholder="Version" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.version || ''} onChange={e => updateDatabaseRegistry(idx, 'version', e.target.value)} disabled={readOnly} />
                                                        </>
                                                    )}
                                                    {row.dbType === 'Postgres' && (
                                                        <>
                                                            <input type="text" placeholder="Port (5432)" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.port || ''} onChange={e => updateDatabaseRegistry(idx, 'port', e.target.value)} disabled={readOnly} />
                                                            <input type="text" placeholder="Datenbankname" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.dbName || ''} onChange={e => updateDatabaseRegistry(idx, 'dbName', e.target.value)} disabled={readOnly} />
                                                        </>
                                                    )}
                                                    {row.dbType === 'Oracle' && (
                                                        <>
                                                            <input type="text" placeholder="SID / Service Name" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.sid || ''} onChange={e => updateDatabaseRegistry(idx, 'sid', e.target.value)} disabled={readOnly} />
                                                            <input type="text" placeholder="Port (1521)" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.port || ''} onChange={e => updateDatabaseRegistry(idx, 'port', e.target.value)} disabled={readOnly} />
                                                            <input type="text" placeholder="Oracle Home (optional)" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.oracleHome || ''} onChange={e => updateDatabaseRegistry(idx, 'oracleHome', e.target.value)} disabled={readOnly} />
                                                        </>
                                                    )}
                                                    {row.dbType === 'DB2' && (
                                                        <>
                                                            <input type="text" placeholder="Instanz" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.instance || ''} onChange={e => updateDatabaseRegistry(idx, 'instance', e.target.value)} disabled={readOnly} />
                                                            <input type="text" placeholder="Port (50000)" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.port || ''} onChange={e => updateDatabaseRegistry(idx, 'port', e.target.value)} disabled={readOnly} />
                                                            <input type="text" placeholder="Datenbankname" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs" value={row.dbName || ''} onChange={e => updateDatabaseRegistry(idx, 'dbName', e.target.value)} disabled={readOnly} />
                                                        </>
                                                    )}
                                                </div>
                                            </td>
                                            <td className="p-2 text-center align-top">
                                                {!readOnly && (
                                                    <button onClick={() => removeDatabaseRegistryRow(idx)} className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-colors">
                                                        <Trash2 className="w-4 h-4" />
                                                    </button>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                    {(data.databaseRegistry || []).length === 0 && (
                                        <tr>
                                            <td colSpan={5} className="p-4 text-center text-slate-400 italic">Keine Datenbanken eingetragen.</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                            {!readOnly && (
                                <div className="flex gap-2 mt-3">
                                    <button onClick={addDatabaseRegistryRow} className="flex items-center gap-2 text-sm font-bold text-indigo-600 hover:text-indigo-700 px-3 py-2 hover:bg-indigo-50 rounded-lg transition-colors"><Plus className="w-4 h-4" /> Datenbank hinzufügen</button>
                                </div>
                            )}
                        </div>
                    </div>
                    )}
                </div>
            )}
        </div>
        )}

        {/* Component Management */}
        <div className="mt-8 mb-8 border-t border-slate-100 dark:border-slate-800 pt-8">
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-200 mb-4 flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-500" /> Systemkomponenten
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(data.components || []).map((comp: any, idx: number) => (
                    <div 
                        key={idx} 
                        onClick={() => setActiveComponentIndex(idx)}
                        className={`p-4 rounded-lg border cursor-pointer transition-all ${activeComponentIndex === idx ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 ring-2 ring-indigo-200 dark:ring-indigo-800' : 'border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-500 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
                    >
                        <div className="flex justify-between items-center">
                            <span className="font-bold text-slate-700 dark:text-slate-200">{comp.name}</span>
                            {!readOnly && (
                                <button onClick={(e) => deleteComponent(idx, e)} className="text-slate-400 hover:text-rose-500 transition-colors p-1">
                                    <Trash2 className="w-4 h-4" />
                                </button>
                            )}
                        </div>
                    </div>
                ))}
                {!readOnly && (
                    <button onClick={addComponent} className="p-4 rounded-lg border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/10 text-slate-400 hover:text-indigo-600 font-bold flex items-center justify-center gap-2 transition-all">
                        <Plus className="w-5 h-5" /> Komponente hinzufügen
                    </button>
                )}
            </div>
        </div>

        {activeComponentIndex !== null && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300 border-l-4 border-indigo-500 pl-6">
        {/* 2. Tool-Nutzung */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('tools')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Settings className="w-5 h-5 text-indigo-500" /> 2. Tool-Nutzung</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['tools'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['tools'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                    {renderInput("Art der Anwendung", "softwareType", "text", undefined, ["Kaufsoftware", "Eigenentwicklung", "Open Source", "SaaS / Cloud Service"], true)}
                    {renderInput("Betriebsmodell", "operatingModel", "text", undefined, ["On-Prem", "Cloud", "Hybrid"], true)}
                    {renderInput("Läuft die Anwendung auf:", "appType", "text", undefined, ["Statischer Server", "Container"], true)}
                    {renderInput("Betriebssystem", "os", "text", undefined, undefined, true)}
                    {renderInput("Wie wird die Anwendung bereitgestellt?", "deployment", "text", undefined, undefined, true)}
                    {renderInput("Wie werden Anmeldeinformationen initial bereitgestellt?", "initialAuth", "text", undefined, undefined, true)}
                    {renderSectionNote('tools')}
                </div>
            )}
        </div>

        {/* 3. Container - Standalone */}
        {data.components?.[activeComponentIndex]?.appType === 'Container' && (
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('container_standalone')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Database className="w-5 h-5 text-indigo-500" /> 3. Container – Standalone</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['container_standalone'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['container_standalone'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                                {renderInput("Wurde der Container / die Anwendung selbst erstellt?", "containerSelfBuilt", "text", undefined, ["Ja", "Nein", "N/A"], true)}
                                {renderSectionNote('container_standalone')}
                </div>
            )}
        </div>
        )}

        {/* 4. Container - K8s */}
        {data.components?.[activeComponentIndex]?.appType === 'Container' && (
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('container_k8s')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Cloud className="w-5 h-5 text-indigo-500" /> 4. Container – Kubernetes / OpenShift</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['container_k8s'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['container_k8s'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                                {renderInput("Verwendet die Anwendung Kubernetes Secrets?", "k8sSecrets", "text", undefined, ["Ja", "Nein", "N/A"], true)}
                                {renderInput("Besteht Kontrolle über den Anwendungscode?", "codeControl", "text", undefined, ["Ja", "Nein", "N/A"], true)}
                    <div className="p-3 bg-amber-50 text-amber-800 text-sm rounded-lg border border-amber-100 flex gap-2">
                        <AlertTriangle className="w-5 h-5 shrink-0" />
                        <span><strong>Hinweis:</strong> Kubernetes Secrets sind standardmäßig nur base64-kodiert und nicht verschlüsselt. Dies stellt ein Sicherheitsrisiko dar.</span>
                    </div>
                    {renderSectionNote('container_k8s')}
                </div>
            )}
        </div>
        )}

        {/* 5. Cloud Computing */}
        {(data.components?.[activeComponentIndex]?.operatingModel === 'Cloud' || data.components?.[activeComponentIndex]?.operatingModel === 'Hybrid') && (
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('cloud')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Cloud className="w-5 h-5 text-indigo-500" /> 5. Cloud Computing</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['cloud'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['cloud'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                                {renderInput("Cloud in", "cloudIn", "text", undefined, ["FCN", "FCPI", "SAAS"], true)}
                                {renderInput("Nutzung von Serverless Functions?", "serverless", "text", undefined, ["Ja", "Nein", "N/A"], true)}
                                {renderInput("Nutzung von VMs in der Cloud (Hyperscaler)?", "cloudVMs", "text", undefined, ["Ja", "Nein", "N/A"], true)}
                                {renderSectionNote('cloud')}
                </div>
            )}
        </div>
        )}

        {/* 6. Server */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('server')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Server className="w-5 h-5 text-indigo-500" /> 6. Konfig & Codecontrolle</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['server'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['server'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                    {data.components?.[activeComponentIndex]?.operatingModel === 'On-Prem' && (
                        <div className="p-3 bg-blue-50 text-blue-800 text-sm rounded-lg border border-blue-100 mb-4">
                            <strong>Hinweis:</strong> Bitte beantworten Sie die folgenden Fragen spezifisch für Ihre On-Prem Server-Umgebung.
                        </div>
                    )}
                    {renderInput("Besteht Kontrolle über Code?", "codeControlServer", "text", undefined, ["Ja", "Nein"], true)}
                    {renderInput("Besteht Kontrolle über Konfigurationsdateien?", "configControlServer", "text", undefined, ["Ja", "Nein"], true)}
                    {renderInput("Sind Konfigurationsdateien zentral zugänglich?", "centralConfig", "text", undefined, ["Ja", "Nein"], true)}
                    {renderInput("Läuft die Anwendung auf einem Java-Webserver?", "javaWebserver", "text", undefined, ["Ja", "Nein", "Teilweise"], true)}
                    {(data.components?.[activeComponentIndex]?.javaWebserver === 'Ja' || data.components?.[activeComponentIndex]?.javaWebserver === 'Teilweise') && (
                        <div className="pl-4 border-l-2 border-indigo-100 mt-2 space-y-4">
                            {renderInput("Nutzt die Anwendung DataSources?", "dataSources", "text", undefined, ["Ja", "Nein"], true)}
                            {renderInput("Zweck der DataSources", "dataSourcesPurpose", "text", undefined, undefined, true)}
                            <div className="text-xs text-slate-500 italic">Relevant für Secrets-Injection in Java-Umgebungen.</div>
                        </div>
                    )}
                    {renderSectionNote('server')}
                </div>
            )}
        </div>

        {/* 7. Eigenschaften der Secrets */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('properties')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Key className="w-5 h-5 text-indigo-500" /> 7. Eigenschaften der Secrets</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['properties'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['properties'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                                {renderMultiSelect("Welche Arten von Secrets werden genutzt?", "secretTypes", ["Passwörter", "API-Keys", "Zertifikate", "SSH-Keys"], true)}
                                {renderMultiSelect("Wie werden Secrets aktuell gespeichert?", "secretStorage", ["Config-Files", "ENV-Variablen", "Kubernetes Secrets", "Hard-coded", "Hardware-HSM"], true)}
                    {((data.components?.[activeComponentIndex]?.secretStorage as string[]) || []).includes('Hard-coded') && (
                        <div className="p-3 bg-rose-50 text-rose-800 text-sm rounded-lg border border-rose-100 flex gap-2">
                            <AlertTriangle className="w-5 h-5 shrink-0" />
                            <span><strong>Risiko:</strong> Hard-coded Secrets stellen ein hohes Sicherheitsrisiko dar und müssen priorisiert migriert werden.</span>
                        </div>
                    )}
                                {renderInput("Werden Secrets auch für manuelle Prozesse genutzt?", "manualProcesses", "text", undefined, ["Ja", "Nein"], true)}
                                {renderSectionNote('properties')}
                </div>
            )}
        </div>

        {/* 8. Rotation - Ist-Status */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('rotation_status')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><RefreshCw className="w-5 h-5 text-indigo-500" /> 8. Rotation – Ist-Status</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['rotation_status'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['rotation_status'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                                {renderInput("Gibt es Secrets, deren Rotation in der Verantwortung der Deka liegt?", "rotationResponsibility", "text", undefined, ["Ja", "Nein"], true)}
                                {renderMultiSelect("Gilt dies für:", "rotationLevel", ["Datenbankebene", "Anwendungsebene"], true)}
                                {renderInput("Wie erfolgt die bisherige Rotation?", "currentRotation", "text", undefined, ["Manuell", "Teilautomatisiert", "Vollautomatisiert", "Bereits über CyberArk"], true)}
                                {renderSectionNote('rotation_status')}
                </div>
            )}
        </div>

        {/* 9. Anbindungsvariante (Zielbild) */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('target_image')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Link2 className="w-5 h-5 text-indigo-500" /> 9. Anbindungsvariante (Zielbild)</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['target_image'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['target_image'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-4">
                                {renderInput("Eingesetztes Secrets-Management-Tool", "targetTool", "text", undefined, ["CyberArk CP", "CyberArk CCP", "HashiCorp Vault"], true)}
                                {renderInput("Anbindungsvariante", "targetVariant", "text", undefined, ["Vollautomatisiert zur Laufzeit", "Hybrid", "Manuelle Inventarisierung"], true)}
                                {renderInput("Rotationsmechanismus", "targetRotationMech", "text", undefined, ["Automatisch", "Teilautomatisiert", "Manuell"], true)}
                                {renderInput("Zeitfenster der Rotation", "targetTimeWindow", "text", undefined, ["Untertägig", "Definiertes Zeitfenster", "Manuell"], true)}
                                {renderInput("Häufigkeit der Rotation", "targetFrequency", "text", undefined, ["Täglich", "Wöchentlich", "Individueller Zyklus", "1x pro Jahr"], true)}
                                {renderSectionNote('target_image')}
                </div>
            )}
        </div>
        </div>
        )}

      {isAddComponentModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 sm:p-10">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"></div>
          <div className="relative bg-white dark:bg-slate-900 w-full max-w-md rounded-xl shadow-2xl p-8 animate-in zoom-in-95 duration-200 border border-slate-100 dark:border-slate-800">
            <h3 className="text-xl font-black text-slate-900 dark:text-white mb-6">Neue Komponente</h3>
            <form onSubmit={confirmAddComponent}>
                <div className="mb-6">
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Name der Komponente</label>
                    <input 
                        autoFocus
                        type="text" 
                        className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 font-medium"
                        value={newComponentName}
                        onChange={e => setNewComponentName(e.target.value)}
                        placeholder="z.B. Backend Service"
                    />
                </div>
                <div className="flex justify-end gap-3">
                    <button 
                        type="button"
                        onClick={() => setIsAddComponentModalOpen(false)}
                        className="px-4 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg font-bold transition-colors"
                    >
                        Abbrechen
                    </button>
                    <button 
                        type="submit"
                        disabled={!newComponentName.trim()}
                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold shadow-lg shadow-indigo-200 transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Hinzufügen
                    </button>
                </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
