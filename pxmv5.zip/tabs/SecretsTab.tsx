import React, { useState, useMemo, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { KeyRound, Lock, Users, Link, Plus, FileDown, FileSpreadsheet, Edit2, Trash2, CheckSquare, Square, Info, Server, Layers, Cloud, Database, ChevronRight, Search, Loader2, X, Network, Maximize2, Eye, EyeOff, ZoomIn, ZoomOut } from 'lucide-react';
import ExcelJS from 'exceljs';
import { SECRETS_SECTIONS } from '../constants';
import { getAccessToken } from '../auth';
import { API_BASE_URL } from '../config';
import { MultiSelectPicker } from '../components/MultiSelectPicker';

interface SecretsTabProps {
  data: any;
  setData: (data: any) => void;
  secretsOnboardingData: any; // Benötigt für Infrastruktur-Infos
  openSections: Record<string, boolean>;
  toggleSection: (id: string) => void;
  readOnly: boolean;
  governanceRow: any;
}

const DirectoryPicker = ({ value, onChange, onSelect, readOnly, placeholder, type }: any) => {
    const [query, setQuery] = useState(value || '');
    const [results, setResults] = useState<any[]>([]);
    const [isOpen, setIsOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const wrapperRef = useRef<HTMLDivElement>(null);
    const dropdownRef = useRef<HTMLDivElement>(null);
    const [dropdownStyle, setDropdownStyle] = useState<React.CSSProperties>({});

    useEffect(() => { setQuery(value || ''); }, [value]);

    useEffect(() => {
        if (isOpen && wrapperRef.current) {
            const updatePosition = () => {
                if (wrapperRef.current) {
                    const rect = wrapperRef.current.getBoundingClientRect();
                    setDropdownStyle({
                        position: 'fixed',
                        top: `${rect.bottom + 4}px`,
                        left: `${rect.left}px`,
                        width: `${rect.width}px`,
                        zIndex: 9999
                    });
                }
            };
            updatePosition();
            window.addEventListener('scroll', updatePosition, true);
            window.addEventListener('resize', updatePosition);
            return () => {
                window.removeEventListener('scroll', updatePosition, true);
                window.removeEventListener('resize', updatePosition);
            };
        }
    }, [isOpen]);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (
                wrapperRef.current && 
                !wrapperRef.current.contains(event.target as Node) &&
                (!dropdownRef.current || !dropdownRef.current.contains(event.target as Node))
            ) {
                setIsOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [wrapperRef]);

    const handleSearch = async (q: string) => {
        setQuery(q);
        onChange(q);
        if (q.length < 3) { setResults([]); setIsOpen(false); return; }
        setLoading(true);
        try {
            const token = getAccessToken();
            const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
            const res = await fetch(`${API_BASE_URL}/directory/search?q=${encodeURIComponent(q)}&type=${type || ''}`, { headers });
            if (res.ok) {
                const data = await res.json();
                setResults(data);
                setIsOpen(true);
            }
        } catch (e) { console.error(e); } finally { setLoading(false); }
    };

    return (
        <div ref={wrapperRef} className="relative w-full min-w-[200px]">
            <div className="relative">
                <input type="text" className={`w-full p-2 pr-8 bg-white dark:bg-slate-800 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 ${!value ? 'border-slate-200 dark:border-slate-700' : 'border-slate-200 dark:border-slate-700'}`}
                    value={query} onChange={e => !readOnly && handleSearch(e.target.value)} placeholder={placeholder} disabled={readOnly} />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400">
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                </div>
            </div>
            {isOpen && results.length > 0 && !readOnly && createPortal(
                <div 
                    ref={dropdownRef}
                    style={dropdownStyle}
                    className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xl max-h-60 overflow-y-auto"
                >
                    {results.map((item: any, idx: number) => (
                        <div key={idx} className="p-2 hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer border-b border-slate-50 dark:border-slate-700 last:border-0" onClick={() => { onChange(item.username); if (onSelect) onSelect(item); setQuery(item.username); setIsOpen(false); }}>
                            <div className="font-bold text-slate-700 dark:text-slate-200 text-xs">{item.displayName}</div>
                            <div className="text-xs text-slate-500 font-mono">{item.username}</div>
                        </div>
                    ))}
                </div>,
                document.body
            )}
        </div>
    );
};

const DependencyPicker = ({ value, onChange, readOnly }: any) => {
    const [query, setQuery] = useState('');
    const [results, setResults] = useState<any[]>([]);
    const [components, setComponents] = useState<any[]>([]);
    const [selectedApp, setSelectedApp] = useState<any>(null);
    const [isOpen, setIsOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const wrapperRef = useRef<HTMLDivElement>(null);
    const dropdownRef = useRef<HTMLDivElement>(null);
    const [dropdownStyle, setDropdownStyle] = useState<React.CSSProperties>({});

    const dependencies = useMemo(() => {
        try { return value ? JSON.parse(value) : []; } catch { return []; }
    }, [value]);

    useEffect(() => {
        if (isOpen && wrapperRef.current) {
            const updatePosition = () => {
                if (wrapperRef.current) {
                    const rect = wrapperRef.current.getBoundingClientRect();
                    setDropdownStyle({
                        position: 'fixed',
                        top: `${rect.bottom + 4}px`,
                        left: `${rect.left}px`,
                        width: `${rect.width}px`,
                        zIndex: 9999
                    });
                }
            };
            updatePosition();
            window.addEventListener('scroll', updatePosition, true);
            window.addEventListener('resize', updatePosition);
            return () => {
                window.removeEventListener('scroll', updatePosition, true);
                window.removeEventListener('resize', updatePosition);
            };
        }
    }, [isOpen]);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node) && (!dropdownRef.current || !dropdownRef.current.contains(event.target as Node))) {
                setIsOpen(false);
                setSelectedApp(null);
                setComponents([]);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [wrapperRef]);

    const handleSearch = async (q: string) => {
        setQuery(q);
        if (q.length < 3) { setResults([]); setIsOpen(false); return; }
        setLoading(true);
        try {
            const token = getAccessToken();
            const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
            const res = await fetch(`${API_BASE_URL}/governance/search?q=${encodeURIComponent(q)}`, { headers });
            if (res.ok) {
                const data = await res.json();
                setResults(data);
                setIsOpen(true);
            }
        } catch (e) { console.error(e); } finally { setLoading(false); }
    };

    const handleSelectApp = async (app: any) => {
        setSelectedApp(app);
        setLoading(true);
        try {
            const token = getAccessToken();
            const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
            const res = await fetch(`${API_BASE_URL}/secrets-onboarding/${app.id}`, { headers });
            if (res.ok) {
                const json = await res.json();
                const data = json.data ? JSON.parse(json.data) : {};
                setComponents(data.components || []);
            }
        } catch (e) { console.error(e); } finally { setLoading(false); }
    };

    const handleSelectComponent = (compName: string) => {
        const newDep = { ...selectedApp, component: compName };
        const newDeps = [...dependencies, newDep];
        onChange(JSON.stringify(newDeps));
        setIsOpen(false);
        setQuery('');
        setSelectedApp(null);
        setComponents([]);
    };

    const removeDependency = (idx: number) => {
        const newDeps = [...dependencies];
        newDeps.splice(idx, 1);
        onChange(JSON.stringify(newDeps));
    };

    return (
        <div ref={wrapperRef} className="relative w-full min-w-[200px]">
            <div className="flex flex-col gap-1 mb-2">
                {dependencies.map((dep: any, idx: number) => (
                    <div key={idx} className="flex items-center justify-between bg-indigo-50 dark:bg-indigo-900/30 p-1.5 rounded border border-indigo-100 dark:border-indigo-800 text-xs">
                        <div className="flex flex-col">
                            <span className="font-bold text-indigo-700 dark:text-indigo-300">{dep.Name}</span>
                            <span className="text-[10px] text-slate-500 dark:text-slate-400">{dep.component}</span>
                        </div>
                        {!readOnly && <button onClick={() => removeDependency(idx)} className="text-slate-400 hover:text-rose-500"><X className="w-3 h-3" /></button>}
                    </div>
                ))}
            </div>
            {!readOnly && (
                <div className="relative">
                    <input type="text" className="w-full p-2 pr-8 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs"
                        value={query} onChange={e => handleSearch(e.target.value)} placeholder="Abhängigkeit hinzufügen (ICTO/Name)..." />
                    <div className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400">{loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Search className="w-3 h-3" />}</div>
                </div>
            )}
            {isOpen && !readOnly && createPortal(
                <div ref={dropdownRef} style={dropdownStyle} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xl max-h-60 overflow-y-auto flex flex-col">
                    {!selectedApp ? (
                        results.length > 0 ? results.map((app: any) => (
                            <div key={app.id} className="p-2 hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer border-b border-slate-50 dark:border-slate-700 last:border-0" onClick={() => handleSelectApp(app)}>
                                <div className="font-bold text-slate-700 dark:text-slate-200 text-xs">{app.Name}</div>
                                <div className="text-[10px] text-slate-500 font-mono">{app.ICTO}</div>
                            </div>
                        )) : <div className="p-2 text-xs text-slate-400 text-center">Keine Ergebnisse</div>
                    ) : (
                        <>
                            <div className="p-2 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 font-bold text-xs text-indigo-600 flex justify-between items-center">
                                <span>{selectedApp.Name}</span>
                                <button onClick={() => setSelectedApp(null)} className="text-[10px] underline">Zurück</button>
                            </div>
                            {components.length > 0 ? components.map((comp: any, idx: number) => (
                                <div key={idx} className="p-2 hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer border-b border-slate-50 dark:border-slate-700 last:border-0 text-xs" onClick={() => handleSelectComponent(comp.name)}>
                                    <div className="font-medium text-slate-700 dark:text-slate-200">{comp.name}</div>
                                </div>
                            )) : <div className="p-2 text-xs text-slate-400 text-center">Keine Komponenten gefunden</div>}
                        </>
                    )}
                </div>, document.body
            )}
        </div>
    );
};

export const SecretsTab: React.FC<SecretsTabProps> = ({
  data,
  setData,
  secretsOnboardingData,
  openSections,
  toggleSection,
  readOnly,
  governanceRow
}) => {
  const [selectedSecretIndices, setSelectedSecretIndices] = useState<number[]>([]);
  const [selectedMappingIndices, setSelectedMappingIndices] = useState<number[]>([]);
  const [isMassUpdateModalOpen, setIsMassUpdateModalOpen] = useState(false);
  const [massUpdateSection, setMassUpdateSection] = useState<string>('inventory');
  const [massUpdateData, setMassUpdateData] = useState<any>({});
  const [isInventoryModalOpen, setIsInventoryModalOpen] = useState(false);
  const [filters, setFilters] = useState<Record<string, Record<string, string>>>({});
  const [showInventoryDetails, setShowInventoryDetails] = useState(true);
  const [zoomLevel, setZoomLevel] = useState(1);

  // Derived Options
  const secretInventoryOptions = (data.inventory || []).map((s: any) => s.objektId || s.name).filter(Boolean);
  const secretSafeOptions = (data.safes || []).map((s: any) => s.safeName).filter(Boolean);

  // Infrastructure Options & Groups
  const serverRegistryOptions = (secretsOnboardingData.serverRegistry || []).map((s: any) => s.hostname).filter(Boolean);
  const containerRegistryOptions = (secretsOnboardingData.containerRegistry || []).map((c: any) => c.name).filter(Boolean);
  const serverClusterOptions = (secretsOnboardingData.serverClusters || []).map((c: any) => c.name).filter(Boolean);
  
  const databaseRegistryOptions = (secretsOnboardingData.databaseRegistry || []).map((d: any) => {
      const info = d.instance || d.dbName || d.sid || '';
      return `${d.dbType}${info ? ` ${info}` : ''} (${d.server})`;
  }).filter(Boolean);

  const infraGroups = [
      { label: 'Server', options: serverRegistryOptions, className: 'text-blue-600 dark:text-blue-400 font-bold' },
      { label: 'Server Cluster', options: serverClusterOptions, className: 'text-purple-600 dark:text-purple-400 font-bold' },
      { label: 'Container / Cluster', options: containerRegistryOptions, className: 'text-emerald-600 dark:text-emerald-400 font-bold' },
      { label: 'Datenbanken', options: databaseRegistryOptions, className: 'text-amber-600 dark:text-amber-400 font-bold' }
  ].filter(g => g.options.length > 0);

  const allInfraOptions = infraGroups.flatMap(g => g.options);

  const PER_INFRA_FIELDS = [
      'info', 
      'complexity', 'autoRotation', 'rotationMech', 'frequency', 'timeWindow'
  ];

  const getSingleInfraInfo = (infraName: string) => {
      if (!infraName) return null;
      
      // 1. Server
      const server = secretsOnboardingData.serverRegistry?.find((s: any) => s.hostname === infraName);
      if (server) return { type: 'Server', data: server };

      // 2. Cluster
      const cluster = secretsOnboardingData.serverClusters?.find((c: any) => c.name === infraName);
      if (cluster) return { type: 'Cluster', data: cluster };

      // 3. Container
      const container = secretsOnboardingData.containerRegistry?.find((c: any) => c.name === infraName);
      if (container) return { type: 'Container', data: container };

      // 4. Database
      const db = secretsOnboardingData.databaseRegistry?.find((d: any) => {
           const info = d.instance || d.dbName || d.sid || '';
           const formatted = `${d.dbType}${info ? ` ${info}` : ''} (${d.server})`;
           return formatted === infraName;
      });
      if (db) return { type: 'Database', data: db };

      return null;
  };

  const getInfrastructureInfo = (infraNames: string) => {
      if (!infraNames) return [];
      return infraNames.split(';').map(s => s.trim()).filter(Boolean).map(name => getSingleInfraInfo(name)).filter(Boolean);
  };

  const getComponentsForInfra = (infraName: string) => {
      const info = getSingleInfraInfo(infraName);
      if (info && info.data && info.data.component) {
          return info.data.component.split(';').map((c: string) => c.trim()).filter(Boolean);
      }
      return [];
  };

  const formatDependencyInfo = (val: string) => {
      try {
          const deps = JSON.parse(val);
          if (!Array.isArray(deps) || deps.length === 0) return '';
          return deps.map((d: any) => 
              `System: ${d.Name} (${d.ICTO})\nKomponente: ${d.component}\nKritikalität: ${d.Kritikalität || '-'}\nVerantwortlich: ${d.Betriebsverantwortlicher || '-'}`
          ).join('\n\n');
      } catch { return ''; }
  };

  const inventoryColumns = [
      { key: 'name', label: 'Name / ID', required: true, width: '250px', stickyLeft: '50px' },
      ...(showInventoryDetails ? [
          { key: 'objektId', label: 'ObjektID', readOnly: true, width: '180px' },
          { key: 'category', label: 'Kategorie', type: 'select', options: ['Passwort', 'SSH-Key', 'API-Key', 'Zertifikat'], required: true, width: '150px' },
          { key: 'owner', label: 'Secret Owner', width: '180px' },
          { key: 'holder', label: 'Secret Holder', width: '180px' },
          { key: 'layer', label: 'Layer', type: 'select', options: ['Anwendung', 'Betriebssystem', 'Datenbank'], width: '140px' },
          { key: 'localOrAd', label: 'Lokal/AD', type: 'select', options: ['Lokal', 'AD'], width: '100px' },
          { key: 'dependency', label: 'Abhängigkeit', type: 'dependency', width: '250px' },
          { key: 'dependencyInfo', label: 'Info zur Abhängigkeit', type: 'textarea', readOnly: true, width: '250px', getValue: (row: any) => formatDependencyInfo(row.dependency) },
      ] : []),
      { key: 'infrastructure', label: 'Infrastruktur', type: 'infra-multiselect', width: '250px' },
      { key: 'info', label: 'Info', type: 'info', width: '250px', readOnly: true, getValue: (row: any) => {
          if (!row.infrastructure) return '';
          return row.infrastructure.split(';').map((s: string) => s.trim()).filter(Boolean).map((infra: string) => {
              const info = getSingleInfraInfo(infra);
              return info && info.data ? Object.values(info.data).join(' ') : '';
          }).join(' ');
      }},
      { key: 'complexity', label: 'Komplexität', width: '200px' },
      { key: 'autoRotation', label: 'Auto Rot.', type: 'select', options: ['Ja', 'Nein'], width: '100px' },
      { key: 'rotationMech', label: 'Rot. Mech.', width: '180px' },
      { key: 'frequency', label: 'Häufigkeit', type: 'select', options: ['Täglich', 'Wöchentlich', 'Monatlich', 'Jährlich', 'bei Bedarf'], width: '140px' },
      { key: 'timeWindow', label: 'Zeitfenster', width: '180px' }
  ];

  const renderInfraSelector = (currentValue: string, onChange: (val: string) => void, readOnly: boolean) => {
      const selected = currentValue ? currentValue.split(';').map(s => s.trim()).filter(Boolean) : [];
      
      const handleAdd = (val: string) => {
          if (!val) return;
          if (!selected.includes(val)) {
              const newValue = [...selected, val].join('; ');
              onChange(newValue);
          }
      };

      const handleRemove = (val: string) => {
          const newValue = selected.filter(s => s !== val).join('; ');
          onChange(newValue);
      };

      return (
          <div className="flex flex-col gap-1.5 min-w-[180px]">
              {selected.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-1">
                      {selected.map(s => (
                          <span key={s} className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-800">
                              {s}
                              {!readOnly && (
                                  <button onClick={(e) => { e.preventDefault(); handleRemove(s); }} className="hover:text-indigo-900 dark:hover:text-indigo-100 p-0.5 rounded-full hover:bg-indigo-100 dark:hover:bg-indigo-800 transition-colors">
                                      <X className="w-3 h-3" />
                                  </button>
                              )}
                          </span>
                      ))}
                  </div>
              )}
              {!readOnly && (
                  <select 
                      className="w-full p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs"
                      value=""
                      onChange={e => handleAdd(e.target.value)}
                  >
                      <option value="">+ Infrastruktur</option>
                      {infraGroups.map((g, i) => (
                          <optgroup key={i} label={g.label} className={g.className}>
                              {g.options.filter(o => !selected.includes(o)).map(o => (
                                  <option key={o} value={o} className="text-slate-900 dark:text-slate-200 font-normal">{o}</option>
                              ))}
                          </optgroup>
                      ))}
                  </select>
              )}
              {readOnly && selected.length === 0 && <span className="text-slate-400 italic text-xs">-</span>}
          </div>
      );
  };

  const renderMassUpdateInfraSelector = () => {
      const selected = massUpdateData.infrastructure ? massUpdateData.infrastructure.split(';').map((s: any) => s.trim()).filter(Boolean) : [];
      
      const handleAdd = (val: string) => {
          if (!val) return;
          if (!selected.includes(val)) {
              const newValue = [...selected, val].join('; ');
              setMassUpdateData({ ...massUpdateData, infrastructure: newValue });
          }
      };

      const handleRemove = (val: string) => {
          const newValue = selected.filter((s: any) => s !== val).join('; ');
          const newDetails = { ...(massUpdateData.infraDetails || {}) };
          delete newDetails[val];
          setMassUpdateData({ ...massUpdateData, infrastructure: newValue, infraDetails: newDetails });
      };

      return (
          <div className="flex flex-col gap-1.5 w-full">
              {selected.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-1">
                      {selected.map((s: any) => (
                          <span key={s} className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-800">
                              {s}
                              <button onClick={(e) => { e.preventDefault(); handleRemove(s); }} className="hover:text-indigo-900 dark:hover:text-indigo-100 p-0.5 rounded-full hover:bg-indigo-100 dark:hover:bg-indigo-800 transition-colors">
                                  <X className="w-3 h-3" />
                              </button>
                          </span>
                      ))}
                  </div>
              )}
              <select className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-sm" value="" onChange={e => handleAdd(e.target.value)}>
                  <option value="">+ Infrastruktur hinzufügen</option>
                  {infraGroups.map((g, i) => (
                      <optgroup key={i} label={g.label} className={g.className}>
                          {g.options.filter(o => !selected.includes(o)).map(o => (
                              <option key={o} value={o} className="text-slate-900 dark:text-slate-200 font-normal">{o}</option>
                          ))}
                      </optgroup>
                  ))}
              </select>
          </div>
      );
  };

  const updateMassInfraDetail = (infra: string, field: string, value: any) => {
      setMassUpdateData((prev: any) => {
          const details = prev.infraDetails || {};
          if (!details[infra]) details[infra] = {};
          details[infra][field] = value;
          return { ...prev, infraDetails: details };
      });
  };

  const updateSecretsRow = (section: string, index: number, field: string, value: any, infraName?: string) => {
    setData((prev: any) => {
      const newList = [...(prev[section] || [])];
      const row = { ...newList[index] };

      if (section === 'inventory' && field === 'name') {
          let suffix = '';
          if (row.objektId && row.objektId.includes('_')) {
              const parts = row.objektId.split('_');
              suffix = parts[parts.length - 1];
          }
          if (!suffix || suffix.length < 4) {
               suffix = Math.random().toString(36).substring(2, 7).toUpperCase();
          }
          row.objektId = value ? `${value}_${suffix}` : '';
      }

      if (section === 'inventory' && infraName && PER_INFRA_FIELDS.includes(field)) {
          const details = row.infraDetails ? JSON.parse(row.infraDetails) : {};
          if (!details[infraName]) details[infraName] = {};
          details[infraName][field] = value;
          row.infraDetails = JSON.stringify(details);
      } else {
          row[field] = value;
          if (section === 'mapping' && field === 'safeName') {
              const safe = prev.safes?.find((s: any) => s.safeName === value);
              row.techSafe = safe ? safe.techSafeName : '';
          }
      }

      newList[index] = row;
      return { ...prev, [section]: newList };
    });
  };

  const addSecretsRow = (section: string) => {
    setData((prev: any) => ({ ...prev, [section]: [...(prev[section] || []), {}] }));
  };

  const removeSecretsRow = (section: string, index: number) => {
    setData((prev: any) => {
      const newList = [...(prev[section] || [])];
      newList.splice(index, 1);
      return { ...prev, [section]: newList };
    });
  };

  const toggleSelectAllSecrets = (sectionId: string) => {
      const rows = data[sectionId] || [];
      const isInventory = sectionId === 'inventory';
      const selectedIndices = isInventory ? selectedSecretIndices : selectedMappingIndices;
      const setIndices = isInventory ? setSelectedSecretIndices : setSelectedMappingIndices;

      if (selectedIndices.length === rows.length) {
          setIndices([]);
      } else {
          setIndices(rows.map((_: any, i: number) => i));
      }
  };

  const toggleSelectSecretRow = (sectionId: string, index: number) => {
      const isInventory = sectionId === 'inventory';
      const setIndices = isInventory ? setSelectedSecretIndices : setSelectedMappingIndices;
      setIndices(prev => 
          prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]
      );
  };

  const applyMassUpdate = () => {
      const section = massUpdateSection;
      const isInventory = section === 'inventory';
      const selectedIndices = isInventory ? selectedSecretIndices : selectedMappingIndices;
      const setIndices = isInventory ? setSelectedSecretIndices : setSelectedMappingIndices;

      setData((prev: any) => {
          const newList = [...(prev[section] || [])];
          selectedIndices.forEach(index => {
              const currentRow = newList[index];
              const updatedRow = { ...currentRow };
              
              // 1. Global Fields
              Object.keys(massUpdateData).forEach(key => {
                  if (key !== 'infrastructure' && key !== 'infraDetails' && massUpdateData[key] !== undefined && massUpdateData[key] !== "") {
                       updatedRow[key] = massUpdateData[key];
                       if (section === 'mapping' && key === 'safeName') {
                          const safe = prev.safes?.find((s: any) => s.safeName === massUpdateData[key]);
                          updatedRow.techSafe = safe ? safe.techSafeName : '';
                      }
                  }
              });
              
              // 2. Infrastructure Assignment & Details
              if (isInventory) {
                  // Add new infrastructures
                  if (massUpdateData.infrastructure) {
                      const newInfras = massUpdateData.infrastructure.split(';').map((s: string) => s.trim()).filter(Boolean);
                      const currentInfras = updatedRow.infrastructure ? updatedRow.infrastructure.split(';').map((s: string) => s.trim()).filter(Boolean) : [];
                      
                      newInfras.forEach((inf: string) => {
                          if (!currentInfras.includes(inf)) currentInfras.push(inf);
                      });
                      updatedRow.infrastructure = currentInfras.join('; ');
                  }

                  // Update Details
                  if (massUpdateData.infraDetails) {
                      const rowDetails = updatedRow.infraDetails ? JSON.parse(updatedRow.infraDetails) : {};
                      
                      Object.keys(massUpdateData.infraDetails).forEach(infra => {
                          if (!rowDetails[infra]) rowDetails[infra] = {};
                          const updates = massUpdateData.infraDetails[infra];
                          
                          Object.keys(updates).forEach(field => {
                              if (updates[field] !== undefined && updates[field] !== "") {
                                  rowDetails[infra][field] = updates[field];
                              }
                          });
                      });
                      updatedRow.infraDetails = JSON.stringify(rowDetails);
                  }
              }

              newList[index] = updatedRow;
          });
          return { ...prev, [section]: newList };
      });
      setIsMassUpdateModalOpen(false);
      setMassUpdateData({});
      setIndices([]);
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>, sectionId: string, columns: any[]) => {
      const file = e.target.files?.[0];
      if (!file) return;

      try {
          const buffer = await file.arrayBuffer();
          const workbook = new ExcelJS.Workbook();
          await workbook.xlsx.load(buffer);
          
          const worksheet = workbook.worksheets[0];
          if (!worksheet) throw new Error("Kein Arbeitsblatt gefunden");

          const jsonData: any[] = [];
          const headers: string[] = [];

          worksheet.getRow(1).eachCell({ includeEmpty: true }, (cell, colNumber) => {
              headers[colNumber] = cell.text ? cell.text.toString().trim() : '';
          });

          worksheet.eachRow((row, rowNumber) => {
              if (rowNumber === 1) return;
              const rowData: any = {};
              let hasData = false;
              row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
                  const header = headers[colNumber];
                  if (header) {
                      const val = cell.text ? cell.text.toString().trim() : '';
                      if (val) {
                          rowData[header] = val;
                          hasData = true;
                      }
                  }
              });
              if (hasData) jsonData.push(rowData);
          });

          const mappedData = jsonData.map((row: any) => {
              const newRow: any = {};
              columns.forEach(col => {
                  let val = row[col.label];
                  if (val === undefined) val = row[col.key];
                  if (val === undefined) {
                      const keyMatch = Object.keys(row).find(k => k.toLowerCase() === col.label.toLowerCase() || k.toLowerCase() === col.key.toLowerCase());
                      if (keyMatch) val = row[keyMatch];
                  }
                  if (val !== undefined) newRow[col.key] = String(val);
              });
              return newRow;
          });

          if (mappedData.length > 0) {
            let dataToImport = [...mappedData];

            if (sectionId === 'inventory') {
                dataToImport.forEach((row: any) => {
                    if (row.name && !row.objektId) {
                        const suffix = Math.random().toString(36).substring(2, 7).toUpperCase();
                        row.objektId = `${row.name}_${suffix}`;
                    }
                });
            }

            if (sectionId === 'mapping') {
                dataToImport = dataToImport.filter((r: any) => r.bizSecret && r.safeName);
                
                dataToImport.forEach((row: any) => {
                    const safe = data.safes?.find((s: any) => s.safeName === row.safeName);
                    row.techSafe = safe ? safe.techSafeName : '';
                });

                const existingMappings = data.mapping || [];
                const uniqueData = dataToImport.filter((newRow: any) => {
                    return !existingMappings.some((existing: any) => 
                        existing.bizSecret === newRow.bizSecret && existing.safeName === newRow.safeName
                    );
                });

                if (uniqueData.length < dataToImport.length) {
                    alert(`${dataToImport.length - uniqueData.length} Duplikate wurden übersprungen.`);
                }
                dataToImport = uniqueData;
            }

            if (dataToImport.length > 0) {
                setData((prev: any) => ({
                    ...prev,
                    [sectionId]: [...(prev[sectionId] || []), ...dataToImport]
                }));
                alert(`${dataToImport.length} Einträge erfolgreich importiert.`);
            }
          }
      } catch (err) {
          console.error(err);
          alert("Fehler beim Importieren der Datei.");
      } finally {
          e.target.value = '';
      }
  };

  const handleDownloadTemplate = async (sectionId: string, columns: any[]) => {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Template');

      const templateColumns = sectionId === 'mapping' ? columns.filter(c => c.key !== 'techSafe') : columns;

      worksheet.columns = templateColumns.map(c => ({
          header: c.label,
          key: c.key,
          width: c.width ? parseInt(c.width) / 7 : 25
      }));

      const headerRow = worksheet.getRow(1);
      headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4F46E5' } };
      headerRow.alignment = { vertical: 'middle', horizontal: 'center' };
      headerRow.height = 24;

      if (sectionId === 'mapping') {
          (data.inventory || []).forEach((s: any) => {
              const val = s.objektId || s.name;
              if (val) {
                  worksheet.addRow({ bizSecret: val });
              }
          });
      }

      templateColumns.forEach((col, index) => {
          if (col.options && col.options.length > 0) {
              const letter = worksheet.getColumn(index + 1).letter;
              for (let i = 2; i <= 1000; i++) {
                  worksheet.getCell(`${letter}${i}`).dataValidation = {
                      type: 'list',
                      allowBlank: true,
                      formulae: [`"${col.options.join(',')}"`]
                  };
              }
          }
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Secret_Inventory_Vorlage_${governanceRow.Name}_${governanceRow.ICTO}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);
  };

  const renderInfoBlock = (info: any) => {
      if (!info) return <div className="p-2 text-slate-400 italic text-xs">Keine Zuordnung</div>;
      
      const { type, data } = info;
      let colorClass = "bg-slate-50 border-slate-200 text-slate-600";
      let icon = <Info className="w-3 h-3" />;

      if (type === 'Server') {
          colorClass = "bg-blue-50 border-blue-200 text-blue-700 dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-300";
          icon = <Server className="w-3 h-3" />;
      } else if (type === 'Cluster') {
          colorClass = "bg-purple-50 border-purple-200 text-purple-700 dark:bg-purple-900/20 dark:border-purple-800 dark:text-purple-300";
          icon = <Layers className="w-3 h-3" />;
      } else if (type === 'Container') {
          colorClass = "bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-900/20 dark:border-emerald-800 dark:text-emerald-300";
          icon = <Cloud className="w-3 h-3" />;
      } else if (type === 'Database') {
          colorClass = "bg-amber-50 border-amber-200 text-amber-700 dark:bg-amber-900/20 dark:border-amber-800 dark:text-amber-300";
          icon = <Database className="w-3 h-3" />;
      }

      return (
          <div className={`p-1.5 rounded-lg border text-xs ${colorClass} shadow-sm h-full`}>
              <div className="flex items-center gap-1.5 font-bold mb-2 border-b border-black/5 pb-1.5">
                  {icon}
                  <span>{type}</span>
                  {data.component && <span className="ml-auto text-[11px] font-medium bg-white/80 dark:bg-black/30 px-2 py-0.5 rounded shadow-sm border border-black/5 dark:border-white/5 truncate max-w-[140px]" title={data.component}>{data.component}</span>}
              </div>
              <div className="space-y-1 opacity-90">
                  {type === 'Server' && (
                      <>
                        <div className="flex justify-between"><span>Host:</span> <span className="font-mono font-bold">{data.hostname}</span></div>
                        <div className="flex justify-between"><span>IP:</span> <span className="font-mono">{data.ip || '-'}</span></div>
                        <div className="flex justify-between"><span>Segment:</span> <span>{data.segment || '-'}</span></div>
                      </>
                  )}
                  {type === 'Cluster' && (
                      <>
                        <div className="flex justify-between"><span>Name:</span> <span className="font-bold">{data.name}</span></div>
                        <div className="mt-1.5">
                            <span className="block text-[10px] uppercase tracking-wider opacity-70 mb-1">Nodes:</span>
                            <div className="flex flex-col gap-1">
                                {(data.nodes || '').split(/[;,]/).map((n: string) => {
                                    const nodeName = n.trim();
                                    if(!nodeName) return null;
                                    const node = secretsOnboardingData.serverRegistry?.find((s: any) => s.hostname === nodeName);
                                    return (
                                        <div key={nodeName} className="bg-white dark:bg-black/20 px-1.5 py-0.5 rounded text-[10px] border border-purple-200 dark:border-purple-800/50 flex justify-between items-center">
                                            <span className="font-mono font-bold">{nodeName}</span>
                                            {node && (
                                                <div className="flex flex-col items-end leading-tight">
                                                    <span className="font-mono opacity-70">{node.ip}</span>
                                                    <span className="text-[9px] opacity-50">{node.segment}</span>
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                      </>
                  )}
                  {type === 'Container' && (
                      <>
                        <div className="flex justify-between"><span>Name:</span> <span className="font-bold">{data.name}</span></div>
                        <div className="flex justify-between"><span>Typ:</span> <span>{data.type}</span></div>
                        <div className="flex justify-between"><span>NS:</span> <span className="font-mono">{data.namespace || '-'}</span></div>
                        {data.apiUrl && <div className="flex justify-between"><span>API:</span> <span className="font-mono truncate max-w-[150px]" title={data.apiUrl}>{data.apiUrl}</span></div>}
                      </>
                  )}
                  {type === 'Database' && (
                      <>
                        <div className="flex justify-between"><span>Typ:</span> <span className="font-bold">{data.dbType}</span></div>
                        <div className="flex justify-between"><span>Detail:</span> <span className="font-mono">{data.instance || data.dbName || data.sid || '-'}</span></div>
                        <div className="flex justify-between"><span>Port:</span> <span className="font-mono">{data.port || '-'}</span></div>
                        {data.server && (
                             <div className="mt-2 pt-2 border-t border-black/10">
                                <span className="text-[10px] uppercase tracking-wider opacity-70 block mb-1">Host / Cluster:</span>
                                {(() => {
                                    const hostInfo = getInfrastructureInfo(data.server);
                                    if (!hostInfo) return <span className="font-mono text-[10px] font-bold">{data.server}</span>;
                                    
                                    if (hostInfo.type === 'Server') {
                                        return (
                                            <div className="text-[10px] space-y-0.5 bg-white dark:bg-black/20 p-1.5 rounded border border-amber-200 dark:border-amber-800/50">
                                                <div className="flex justify-between"><span>Host:</span> <span className="font-bold">{hostInfo.data.hostname}</span></div>
                                                <div className="flex justify-between"><span>IP:</span> <span className="font-mono">{hostInfo.data.ip || '-'}</span></div>
                                                <div className="flex justify-between"><span>Seg:</span> <span>{hostInfo.data.segment || '-'}</span></div>
                                            </div>
                                        );
                                    } else if (hostInfo.type === 'Cluster') {
                                        return (
                                            <div className="text-[10px] space-y-0.5 bg-white dark:bg-black/20 p-1.5 rounded border border-amber-200 dark:border-amber-800/50">
                                                <div className="flex justify-between"><span>Cluster:</span> <span className="font-bold">{hostInfo.data.name}</span></div>
                                                <div className="mt-1">
                                                    <span className="opacity-70 text-[9px]">Nodes:</span>
                                                    <div className="flex flex-col gap-0.5 mt-0.5">
                                                        {(hostInfo.data.nodes || '').split(/[;,]/).map((n: string) => {
                                                            const nodeName = n.trim();
                                                            if(!nodeName) return null;
                                                            const node = secretsOnboardingData.serverRegistry?.find((s: any) => s.hostname === nodeName);
                                                            return (
                                                                <div key={nodeName} className="flex justify-between">
                                                                    <span className="font-mono">{nodeName}</span>
                                                                    {node && <span className="font-mono opacity-70">{node.ip}</span>}
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    } else if (hostInfo.type === 'Container') {
                                        return (
                                            <div className="text-[10px] space-y-0.5 bg-white dark:bg-black/20 p-1.5 rounded border border-amber-200 dark:border-amber-800/50">
                                                <div className="flex justify-between"><span>Cont:</span> <span className="font-bold">{hostInfo.data.name}</span></div>
                                                <div className="flex justify-between"><span>Typ:</span> <span>{hostInfo.data.type}</span></div>
                                                <div className="flex justify-between"><span>NS:</span> <span className="font-mono">{hostInfo.data.namespace || '-'}</span></div>
                                            </div>
                                        );
                                    }
                                    return <span className="font-mono text-[10px] font-bold">{data.server}</span>;
                                })()}
                             </div>
                        )}
                      </>
                  )}
              </div>
          </div>
      );
  };

  const handleFilterChange = (sectionId: string, key: string, value: string) => {
      setFilters(prev => ({
          ...prev,
          [sectionId]: {
              ...prev[sectionId],
              [key]: value
          }
      }));
  };

  const renderSecretsTable = (sectionId: string, columns: { key: string, label: string, type?: string, options?: string[], getOptions?: (row: any) => string[], groups?: { label: string, options: string[], className?: string }[], width?: string, stickyLeft?: string, required?: boolean, readOnly?: boolean | ((row: any) => boolean), getValue?: (row: any) => any }[], enableImport = false, containerClass = "max-h-[60vh]") => {
    const allRows = data[sectionId] || [];
    const isInventory = sectionId === 'inventory';
    const isSelectable = sectionId === 'inventory' || sectionId === 'mapping';
    const selectedIndices = sectionId === 'inventory' ? selectedSecretIndices : selectedMappingIndices;
    const setIndices = sectionId === 'inventory' ? setSelectedSecretIndices : setSelectedMappingIndices;
    const currentFilters = filters[sectionId] || {};

    const rows = allRows.map((r: any, i: number) => ({ ...r, _originalIndex: i })).filter((row: any) => {
        return columns.every(col => {
            const filterVal = currentFilters[col.key]?.toLowerCase();
            if (!filterVal) return true;
            const val = col.getValue ? String(col.getValue(row) || '') : String(row[col.key] || '');
            return val.toLowerCase().includes(filterVal);
        });
    });

    return (
      <>
      <div className={`overflow-auto ${containerClass} custom-scrollbar relative border border-slate-200 dark:border-slate-700 rounded-lg`}>
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
              {isSelectable && (
                  <th className="sticky top-0 left-0 z-30 bg-slate-50 dark:bg-slate-800 p-2 w-[50px] min-w-[50px] text-center shadow-[0_1px_0_#e2e8f0] dark:shadow-[0_1px_0_#334155] border-r border-slate-200 dark:border-slate-700 align-top">
                      <div className="flex justify-center cursor-pointer mt-1" onClick={() => {
                          const visibleIndices = rows.map((r: any) => r._originalIndex);
                          const allVisibleSelected = visibleIndices.length > 0 && visibleIndices.every((i: number) => selectedIndices.includes(i));
                          if (allVisibleSelected) {
                              setIndices(prev => prev.filter(i => !visibleIndices.includes(i)));
                          } else {
                              setIndices(prev => [...new Set([...prev, ...visibleIndices])]);
                          }
                      }}>
                          {rows.length > 0 && rows.every((r: any) => selectedIndices.includes(r._originalIndex)) ? <CheckSquare className="w-5 h-5 text-indigo-600" /> : <Square className="w-5 h-5 text-slate-300" />}
                      </div>
                  </th>
              )}
              {columns.map(col => {
                const isVariableCol = isInventory && (col.key === 'infrastructure' || PER_INFRA_FIELDS.includes(col.key));
                const bgClass = isVariableCol ? 'bg-indigo-50 dark:bg-indigo-900/40' : 'bg-slate-50 dark:bg-slate-800';
                return (
                <th key={col.key} className={`sticky top-0 ${bgClass} p-2 text-left font-bold text-slate-600 dark:text-slate-300 whitespace-nowrap shadow-[0_1px_0_#e2e8f0] dark:shadow-[0_1px_0_#334155] align-top ${col.stickyLeft ? 'z-30 border-r border-slate-200 dark:border-slate-700' : 'z-10'}`}
                    style={col.stickyLeft ? { left: col.stickyLeft } : {}}>
                  <div className="flex flex-col gap-2">
                      <div className="flex items-center gap-1">
                        {col.label} {col.required && <span className="text-rose-500">*</span>}
                      </div>
                      <input 
                          type="text" 
                          className={`w-full p-1 text-[10px] font-normal border border-slate-200 dark:border-slate-600 rounded ${isVariableCol ? 'bg-white dark:bg-slate-800' : 'bg-white dark:bg-slate-700'} text-slate-600 dark:text-slate-200 focus:ring-1 focus:ring-indigo-500 outline-none placeholder:text-slate-400`}
                          placeholder="Suche..."
                          value={currentFilters[col.key] || ''}
                          onChange={(e) => handleFilterChange(sectionId, col.key, e.target.value)}
                          onClick={(e) => e.stopPropagation()}
                      />
                  </div>
                </th>
              )})}
              <th className="sticky top-0 z-10 bg-slate-50 dark:bg-slate-800 p-3 w-10 shadow-[0_1px_0_#e2e8f0] dark:shadow-[0_1px_0_#334155]"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row: any) => {
              const originalIndex = row._originalIndex;
              let infras = isInventory && row.infrastructure ? row.infrastructure.split(';').map((s: string) => s.trim()).filter(Boolean) : [];
              
              if (isInventory && infras.length > 0) {
                  const typeOrder: Record<string, number> = { 'Server': 1, 'Cluster': 2, 'Container': 3, 'Database': 4 };
                  infras.sort((a: string, b: string) => {
                      const infoA = getSingleInfraInfo(a);
                      const infoB = getSingleInfraInfo(b);
                      const typeA = infoA?.type || 'Unknown';
                      const typeB = infoB?.type || 'Unknown';
                      
                      if ((typeOrder[typeA] || 99) !== (typeOrder[typeB] || 99)) return (typeOrder[typeA] || 99) - (typeOrder[typeB] || 99);
                      return a.localeCompare(b);
                  });
              }

              const rowSpan = Math.max(1, infras.length);
              const infraDetails = row.infraDetails ? JSON.parse(row.infraDetails) : {};

              const renderCell = (col: any, infraName?: string) => {
                  let value = '';
                  if (infraName && PER_INFRA_FIELDS.includes(col.key)) {
                      value = infraDetails[infraName]?.[col.key] || '';
                      if (col.key === 'info') value = getSingleInfraInfo(infraName);
                      if (col.key === 'dependencyInfo') value = formatDependencyInfo(infraDetails[infraName]?.['dependency']);
                  } else {
                      value = col.getValue ? col.getValue(row) : (row[col.key] || '');
                  }

                  const options = (col.getOptions && infraName) ? getComponentsForInfra(infraName) : col.options;

              return (
                  <>
                    {col.type === 'select' ? (
                      <select 
                        className={`w-full p-1.5 bg-white dark:bg-slate-800 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs ${col.required && !value ? 'border-rose-300' : 'border-slate-200 dark:border-slate-700'}`}
                        value={value}
                        onChange={e => updateSecretsRow(sectionId, originalIndex, col.key, e.target.value, infraName)}
                        disabled={readOnly || (typeof col.readOnly === 'function' ? col.readOnly(row) : col.readOnly)}
                      >
                        <option value="">-</option>
                        {col.groups ? (
                            col.groups.map((g, i) => (
                                <optgroup key={i} label={g.label} className={g.className}>
                                    {g.options.map(o => <option key={o} value={o} className="text-slate-900 dark:text-slate-200 font-normal">{o}</option>)}
                                </optgroup>
                            ))
                        ) : (
                            options?.map(o => <option key={o} value={o}>{o}</option>)
                        )}
                      </select>
                    ) : col.type === 'infra-multiselect' ? (
                        renderInfraSelector(
                            value,
                            (val) => updateSecretsRow(sectionId, originalIndex, col.key, val, infraName),
                            readOnly || (typeof col.readOnly === 'function' ? col.readOnly(row) : col.readOnly)
                        )
                    ) : col.type === 'multiselect' ? (
                        <MultiSelectPicker 
                            value={value} 
                            onChange={(val: string) => updateSecretsRow(sectionId, originalIndex, col.key, val, infraName)}
                            options={options || []}
                            readOnly={readOnly || (typeof col.readOnly === 'function' ? col.readOnly(row) : col.readOnly)}
                        />
                    ) : col.type === 'checkbox' ? (
                      <div className="flex justify-center">
                        <input 
                          type="checkbox" 
                          className="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                          checked={!!value}
                          onChange={e => updateSecretsRow(sectionId, originalIndex, col.key, e.target.checked, infraName)}
                          disabled={readOnly || (typeof col.readOnly === 'function' ? col.readOnly(row) : col.readOnly)}
                        />
                      </div>
                    ) : col.type === 'info' ? (
                        renderInfoBlock(value)
                    ) : col.type === 'textarea' ? (
                      <textarea 
                        className={`w-full p-1.5 bg-white dark:bg-slate-800 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs ${col.required && !value ? 'border-rose-300' : 'border-slate-200 dark:border-slate-700'} ${col.readOnly || col.getValue ? 'bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-400' : ''}`}
                        value={value}
                        onChange={e => !col.readOnly && !col.getValue && updateSecretsRow(sectionId, originalIndex, col.key, e.target.value, infraName)}
                        placeholder={col.label}
                        disabled={readOnly || col.readOnly || !!col.getValue}
                        rows={3}
                        style={{ resize: 'vertical', minHeight: '36px', fontSize: '11px', fontFamily: 'monospace' }}
                      />
                    ) : col.type === 'ad-search' ? (
                        <DirectoryPicker 
                            value={value} 
                            type={(col as any).searchType}
                            onChange={(val: string) => updateSecretsRow(sectionId, originalIndex, col.key, val, infraName)} 
                            onSelect={(item: any) => {
                                if ((col as any).onSelect) {
                                    const updates = (col as any).onSelect(item);
                                    if (updates) Object.entries(updates).forEach(([k, v]) => updateSecretsRow(sectionId, originalIndex, k, v));
                                }
                            }}
                            readOnly={readOnly || (typeof col.readOnly === 'function' ? col.readOnly(row) : col.readOnly)} 
                            placeholder={col.label} 
                        />
                    ) : col.type === 'dependency' ? (
                        <DependencyPicker 
                            value={value} 
                            onChange={(val: string) => updateSecretsRow(sectionId, originalIndex, col.key, val, infraName)} 
                            readOnly={readOnly || (typeof col.readOnly === 'function' ? col.readOnly(row) : col.readOnly)}
                        />
                    ) : (
                      <input 
                        type={col.type || 'text'}
                        className={`w-full p-1.5 bg-white dark:bg-slate-800 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-xs ${col.required && !value ? 'border-rose-300' : 'border-slate-200 dark:border-slate-700'} ${col.readOnly ? 'bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-400' : ''}`}
                        value={value}
                        onChange={e => !col.readOnly && updateSecretsRow(sectionId, originalIndex, col.key, e.target.value, infraName)}
                        placeholder={col.label}
                        disabled={readOnly || (typeof col.readOnly === 'function' ? col.readOnly(row) : col.readOnly)}
                        maxLength={500}
                      />
                    )}
                  </>
              );
              };

              const renderedRows = [];
              
              // First Row
              renderedRows.push(
                  <tr key={`${originalIndex}-0`} className="border-b border-slate-100 dark:border-slate-700 hover:bg-slate-50/50 dark:hover:bg-slate-800/50 align-top group">
                      {isSelectable && (
                          <td rowSpan={rowSpan} className="p-1 text-center sticky left-0 z-20 bg-white dark:bg-slate-900 group-hover:bg-slate-50/50 dark:group-hover:bg-slate-800/50 border-r border-slate-100 dark:border-slate-700 align-middle">
                              <div className="flex justify-center cursor-pointer" onClick={() => toggleSelectSecretRow(sectionId, originalIndex)}>
                                  {selectedIndices.includes(originalIndex) ? <CheckSquare className="w-5 h-5 text-indigo-600" /> : <Square className="w-5 h-5 text-slate-300" />}
                              </div>
                          </td>
                      )}
                      {columns.map(col => {
                          const isPerInfra = isInventory && PER_INFRA_FIELDS.includes(col.key);
                          const isInfraCol = col.key === 'infrastructure';
                          
                          if (isPerInfra) {
                              return <td key={col.key} className="p-1" style={{ minWidth: col.width }}>{infras.length > 0 ? renderCell(col, infras[0]) : <div className="text-slate-300 text-xs italic p-1">Wähle Infrastruktur</div>}</td>;
                          } else if (isInfraCol) {
                              return <td key={col.key} rowSpan={rowSpan} className="p-1 align-top" style={{ minWidth: col.width }}>{renderCell(col)}</td>;
                          } else {
                              return <td key={col.key} rowSpan={rowSpan} className={`p-1 align-top ${col.stickyLeft ? 'sticky z-20 bg-white dark:bg-slate-900 group-hover:bg-slate-50/50 dark:group-hover:bg-slate-800/50 border-r border-slate-100 dark:border-slate-700' : ''}`} style={{ minWidth: col.width, ...(col.stickyLeft ? { left: col.stickyLeft } : {}) }}>{renderCell(col)}</td>;
                          }
                      })}
                      <td rowSpan={rowSpan} className="p-1 text-center align-middle">
                          {!readOnly && <button onClick={() => removeSecretsRow(sectionId, originalIndex)} className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"><Trash2 className="w-4 h-4" /></button>}
                      </td>
                  </tr>
              );

              // Additional Rows
              for (let i = 1; i < infras.length; i++) {
                  renderedRows.push(
                      <tr key={`${originalIndex}-${i}`} className="border-b border-slate-100 dark:border-slate-700 hover:bg-slate-50/50 dark:hover:bg-slate-800/50 align-top">
                          {columns.map(col => {
                              if (isInventory && PER_INFRA_FIELDS.includes(col.key)) {
                                  return <td key={col.key} className="p-1" style={{ minWidth: col.width }}>{renderCell(col, infras[i])}</td>;
                              }
                              return null;
                          })}
                      </tr>
                  );
              }

              return renderedRows;
            })}
            {rows.length === 0 && (
              <tr>
                <td colSpan={columns.length + 1} className="p-4 text-center text-slate-400 italic">Keine Einträge vorhanden.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {!readOnly && (
        <div className="flex gap-2 mt-3">
            <button onClick={() => addSecretsRow(sectionId)} className="flex items-center gap-2 text-sm font-bold text-indigo-600 hover:text-indigo-700 px-3 py-2 hover:bg-indigo-50 rounded-lg transition-colors">
            <Plus className="w-4 h-4" /> Zeile hinzufügen
            </button>
            {enableImport && (
                <>
                    <button onClick={() => handleDownloadTemplate(sectionId, columns)} className="flex items-center gap-2 text-sm font-bold text-slate-600 hover:text-slate-700 px-3 py-2 hover:bg-slate-50 rounded-lg transition-colors" title="Excel-Vorlage herunterladen">
                        <FileDown className="w-4 h-4" /> Vorlage
                    </button>
                    <label className="flex items-center gap-2 text-sm font-bold text-emerald-600 hover:text-emerald-700 px-3 py-2 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer" title="Excel-Datei importieren">
                        <FileSpreadsheet className="w-4 h-4" /> Import Excel
                        <input type="file" accept=".xlsx, .xls, .csv" className="hidden" onChange={(e) => handleImport(e, sectionId, columns)} />
                    </label>
                    {isSelectable && selectedIndices.length > 0 && (
                        <button onClick={() => { setMassUpdateSection(sectionId); setIsMassUpdateModalOpen(true); }} className="flex items-center gap-2 text-sm font-bold text-amber-600 hover:text-amber-700 px-3 py-2 hover:bg-amber-50 rounded-lg transition-colors ml-auto">
                            <Edit2 className="w-4 h-4" /> Massenbearbeitung ({selectedIndices.length})
                        </button>
                    )}
                </>
            )}
        </div>
      )}
      </>
    );
  };

  return (
    <div className="space-y-6 w-full">
        
        {/* 1. Secret Inventory */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('inventory')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><KeyRound className="w-5 h-5 text-indigo-500" /> 1. Secret Inventory</div>
                <div className="flex items-center gap-2">
                    <button onClick={(e) => { e.stopPropagation(); setShowInventoryDetails(!showInventoryDetails); }} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors" title={showInventoryDetails ? "Details ausblenden" : "Details einblenden"}>
                        {showInventoryDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); setIsInventoryModalOpen(true); }} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors" title="In Vollbild öffnen">
                        <Maximize2 className="w-4 h-4" />
                    </button>
                    <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['inventory'] ? 'rotate-90' : ''}`} />
                </div>
            </button>
            {(openSections['inventory'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    {renderSecretsTable('inventory', inventoryColumns, true)}
                </div>
            )}
        </div>

        {/* 2. Safe Structure */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('safes')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Lock className="w-5 h-5 text-amber-500" /> 2. Safe- / Pfad-Struktur</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['safes'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['safes'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    <div className="mb-4 p-4 bg-blue-50 text-blue-800 rounded-lg text-sm flex items-start gap-3">
                      <Info className="w-5 h-5 shrink-0 mt-0.5" />
                      <div>
                        <strong>Info:</strong> Die Safe- und Pfad-Struktur stellt eine logische Bündelung von Secrets und Shared Accounts dar. Safes werden in CyberArk verwendet, um Berechtigungen strukturiert zu vergeben.
                      </div>
                    </div>
                    {renderSecretsTable('safes', [
                      { key: 'userGroup', label: 'Nutzergruppe' },
                      { key: 'safeName', label: 'Safe Name / Pfad (fachlich)', required: true },
                      { key: 'safeDesc', label: 'Safe / Pfad Beschreibung' },
                      { key: 'techSafeName', label: 'Technischer Safe Name / Pfad-Prefix', required: true },
                      { key: 'adGroup', label: 'AD-Gruppe', type: 'ad-search', searchType: 'group', required: true, width: '250px' },
                      { key: 'adGroupDesc', label: 'Fachliche Beschreibung AD-Gruppe' },
                      { key: 'approver', label: 'Zweitgenehmiger in Omada' },
                      { key: 'sod', label: 'SoD-Hinweis' }
                    ])}
                </div>
            )}
        </div>

        {/* 3. Members */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('members')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Users className="w-5 h-5 text-purple-500" /> 3. Mitglieder der Safes</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['members'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['members'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    <div className="mb-4 p-4 bg-blue-50 text-blue-800 rounded-lg text-sm flex items-start gap-3">
                      <Info className="w-5 h-5 shrink-0 mt-0.5" />
                      <div>
                        <strong>Hinweis:</strong> Änderungen in der Mitgliederstruktur der Safes erfolgen aufgrund laufender Pflege und Aktualisierung nicht im Rahmen dieses Dokuments. Die führende Quelle für aktuelle Safe-Mitglieder ist Omada.
                      </div>
                    </div>
                    {renderSecretsTable('members', [
                      { key: 'safeName', label: 'Safe Name', type: 'select', options: secretSafeOptions },
                      { key: 'memberName', label: 'Name Mitglied', type: 'ad-search', searchType: 'user', onSelect: (item: any) => ({ identity: `${item.displayName} (${item.username})` }) },
                      { key: 'identity', label: 'Primäre Identität', readOnly: true }
                    ])}
                </div>
            )}
        </div>

        {/* 4. Mapping */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('mapping')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Link className="w-5 h-5 text-emerald-500" /> 4. Secrets zu Safe</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['mapping'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['mapping'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    {renderSecretsTable('mapping', [
                      { key: 'bizSecret', label: 'Fachlicher Secret Name', type: 'select', options: secretInventoryOptions, required: true },
                      { key: 'safeName', label: 'Safe Name', type: 'select', options: secretSafeOptions, required: true },
                      { key: 'techSafe', label: 'Technischer Safe', readOnly: true }
                    ], true)}
                </div>
            )}
        </div>

        {/* Mass Update Modal */}
        {isMassUpdateModalOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 sm:p-10">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"></div>
          <div className="relative bg-white dark:bg-slate-900 w-full max-w-2xl rounded-xl shadow-2xl p-8 animate-in zoom-in-95 duration-200 border border-slate-100 dark:border-slate-800 max-h-[90vh] overflow-y-auto custom-scrollbar">
            <h3 className="text-xl font-black text-slate-900 dark:text-white mb-2">Massenbearbeitung</h3>
            <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">
                Änderungen werden auf <strong>{massUpdateSection === 'inventory' ? selectedSecretIndices.length : selectedMappingIndices.length}</strong> ausgewählte Einträge angewendet. Leere Felder werden ignoriert.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {massUpdateSection === 'inventory' ? (
                <>
                {[
                    { label: "Secret Owner", key: "owner" },
                    { label: "Secret Holder", key: "holder" },
                ].map(field => (
                    <div key={field.key} className="mb-2">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{field.label}</label>
                        <input 
                            type="text" 
                            className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-sm"
                            value={massUpdateData[field.key] || ''}
                            onChange={e => setMassUpdateData({...massUpdateData, [field.key]: e.target.value})}
                            placeholder="Keine Änderung"
                        />
                    </div>
                ))}

                {[
                    { label: "Layer", key: "layer", options: ['Anwendung', 'Betriebssystem', 'Datenbank'] },
                    { label: "Lokal oder AD", key: "localOrAd", options: ['Lokal', 'AD'] },
                ].map(field => (
                    <div key={field.key} className="mb-2">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{field.label}</label>
                        <select 
                            className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-sm"
                            value={massUpdateData[field.key] || ''}
                            onChange={e => setMassUpdateData({...massUpdateData, [field.key]: e.target.value})}
                        >
                            <option value="">Keine Änderung</option>
                            {field.options.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                    </div>
                ))}

                <div className="mb-2 col-span-1 md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Abhängigkeit</label>
                    <DependencyPicker 
                        value={massUpdateData.dependency} 
                        onChange={(val: string) => setMassUpdateData({...massUpdateData, dependency: val})} 
                    />
                </div>

                <div className="mb-2 col-span-1 md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Infrastruktur Zuordnung</label>
                    {renderMassUpdateInfraSelector()}
                    <p className="text-[10px] text-slate-400 mt-1">
                        Wählen Sie Infrastrukturen aus, um diese hinzuzufügen und deren spezifische Eigenschaften zu konfigurieren.
                    </p>
                </div>

                {(massUpdateData.infrastructure ? massUpdateData.infrastructure.split(';').map((s: any) => s.trim()).filter(Boolean) : []).map((infra: string) => (
                    <div key={infra} className="col-span-1 md:col-span-2 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-lg border border-slate-200 dark:border-slate-700 mt-2">
                        <h4 className="font-bold text-sm text-indigo-600 dark:text-indigo-400 mb-3 flex items-center gap-2">
                            <Server className="w-4 h-4" /> {infra}
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {[
                                { label: "Komplexitätsregeln", key: "complexity" },
                                { label: "Rotationsmechanismus", key: "rotationMech" },
                                { label: "Zeitfenster", key: "timeWindow" },
                            ].map(f => (
                                <div key={f.key}>
                                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">{f.label}</label>
                                    <input type="text" className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md text-xs" value={massUpdateData.infraDetails?.[infra]?.[f.key] || ''} onChange={e => updateMassInfraDetail(infra, f.key, e.target.value)} />
                                </div>
                            ))}
                            {[
                                { label: "Auto Rotation", key: "autoRotation", options: ['Ja', 'Nein'] },
                                { label: "Häufigkeit", key: "frequency", options: ['Täglich', 'Wöchentlich', 'Monatlich', 'Jährlich', 'bei Bedarf'] }
                            ].map(f => (
                                <div key={f.key}>
                                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">{f.label}</label>
                                    <select className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md text-xs" value={massUpdateData.infraDetails?.[infra]?.[f.key] || ''} onChange={e => updateMassInfraDetail(infra, f.key, e.target.value)}>
                                        <option value="">-</option>
                                        {f.options.map(o => <option key={o} value={o}>{o}</option>)}
                                    </select>
                                </div>
                            ))}
                        </div>
                    </div>
                ))}

              
                </>
                ) : (
                    <div className="mb-2 col-span-1 md:col-span-2">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Safe Name</label>
                        <select 
                            className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 text-sm"
                            value={massUpdateData.safeName || ''}
                            onChange={e => setMassUpdateData({...massUpdateData, safeName: e.target.value})}
                        >
                            <option value="">Keine Änderung</option>
                            {secretSafeOptions.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                    </div>
                )}
            </div>

            <div className="flex justify-end gap-3 mt-8 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button type="button" onClick={() => setIsMassUpdateModalOpen(false)} className="px-4 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg font-bold transition-colors">Abbrechen</button>
                <button type="button" onClick={applyMassUpdate} className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold shadow-lg shadow-amber-200 transition-all active:scale-[0.98]">Änderungen anwenden</button>
            </div>
          </div>
        </div>
      )}

      {/* Inventory Fullscreen Modal */}
      {isInventoryModalOpen && (
        <div className="fixed inset-0 z-[75] flex items-center justify-center p-4 sm:p-6">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm transition-opacity" onClick={() => setIsInventoryModalOpen(false)}></div>
          <div className="relative bg-white dark:bg-slate-900 w-full h-full rounded-xl shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200 border border-slate-200 dark:border-slate-800">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-900">
                <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                    <KeyRound className="w-5 h-5 text-indigo-500" /> Secret Inventory
                </h3>
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-1.5 shadow-sm">
                        <ZoomOut className="w-4 h-4 text-slate-400" />
                        <input 
                            type="range" 
                            min="0.5" 
                            max="1.5" 
                            step="0.1" 
                            value={zoomLevel} 
                            onChange={(e) => setZoomLevel(parseFloat(e.target.value))}
                            className="w-24 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer dark:bg-slate-700 accent-indigo-600"
                        />
                        <ZoomIn className="w-4 h-4 text-slate-400" />
                        <span className="text-xs font-mono w-9 text-right text-slate-500 dark:text-slate-400">{Math.round(zoomLevel * 100)}%</span>
                    </div>
                    <div className="h-6 w-px bg-slate-200 dark:bg-slate-700"></div>
                    <button onClick={() => setShowInventoryDetails(!showInventoryDetails)} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors text-slate-500" title={showInventoryDetails ? "Details ausblenden" : "Details einblenden"}>
                        {showInventoryDetails ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                    <button onClick={() => setIsInventoryModalOpen(false)} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors">
                        <X className="w-6 h-6 text-slate-500" />
                    </button>
                </div>
            </div>
            <div className="flex-1 p-6 overflow-hidden bg-slate-50/50 dark:bg-slate-950/50 flex flex-col">
                 <div style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'top left', width: `${100 / zoomLevel}%`, height: `${100 / zoomLevel}%` }}>
                    {renderSecretsTable('inventory', inventoryColumns, true, 'h-full')}
                 </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
