import React from 'react';
import { Server, Database, Network, Lock, Users, Key, Shield, Link, ChevronRight, Trash2, Plus, Info } from 'lucide-react';
import { TECHNICAL_SECTIONS } from '../constants';
import { MultiSelectPicker } from '../components/MultiSelectPicker';

interface TechnicalTabProps {
  data: any;
  setData: (data: any) => void;
  openSections: Record<string, boolean>;
  toggleSection: (id: string) => void;
  readOnly: boolean;
}

export const TechnicalTab: React.FC<TechnicalTabProps> = ({
  data,
  setData,
  openSections,
  toggleSection,
  readOnly
}) => {

  const updateTechnicalRow = (section: string, index: number, field: string, value: any) => {
    setData((prev: any) => {
      const newList = [...(prev[section] || [])];
      newList[index] = { ...newList[index], [field]: value };
      return { ...prev, [section]: newList };
    });
  };

  const addTechnicalRow = (section: string) => {
    setData((prev: any) => ({ ...prev, [section]: [...(prev[section] || []), {}] }));
  };

  const removeTechnicalRow = (section: string, index: number) => {
    setData((prev: any) => {
      const newList = [...(prev[section] || [])];
      newList.splice(index, 1);
      return { ...prev, [section]: newList };
    });
  };

  // Derived options
  const serverOptions = (data.servers || []).map((s: any) => s.serverName).filter(Boolean);
  const accountOptions = (data.sharedAccounts || []).map((a: any) => a.techName).filter(Boolean);
  const safeOptions = (data.safes || []).map((s: any) => s.techSafeName).filter(Boolean);

  const renderTable = (sectionId: string, columns: { key: string, label: string, type?: string, options?: string[], width?: string, required?: boolean, readOnly?: boolean }[]) => {
    const rows = data[sectionId] || [];
    return (
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
              {columns.map(col => (
                <th key={col.key} className="p-3 text-left font-bold text-slate-600 dark:text-slate-300 whitespace-nowrap" style={{ minWidth: col.width }}>
                  {col.label} {col.required && <span className="text-rose-500">*</span>}
                </th>
              ))}
              <th className="p-3 w-10"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row: any, idx: number) => (
              <tr key={idx} className="border-b border-slate-100 dark:border-slate-700 hover:bg-slate-50/50 dark:hover:bg-slate-800/50">
                {columns.map(col => (
                  <td key={col.key} className="p-2" style={{ minWidth: col.width }}>
                    {col.type === 'select' ? (
                      <select 
                        className={`w-full p-2 bg-white dark:bg-slate-800 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 ${col.required && !row[col.key] ? 'border-rose-300' : 'border-slate-200 dark:border-slate-700'}`}
                        value={row[col.key] || ''}
                        onChange={e => updateTechnicalRow(sectionId, idx, col.key, e.target.value)}
                        disabled={readOnly}
                      >
                        <option value="">-</option>
                        {col.options?.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    ) : col.type === 'multiselect' ? (
                      <MultiSelectPicker 
                        value={row[col.key]} 
                        onChange={(val: string) => updateTechnicalRow(sectionId, idx, col.key, val)}
                        options={col.options || []}
                        readOnly={readOnly}
                      />
                    ) : col.type === 'checkbox' ? (
                      <div className="flex justify-center">
                        <input 
                          type="checkbox" 
                          className="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                          checked={!!row[col.key]}
                          onChange={e => updateTechnicalRow(sectionId, idx, col.key, e.target.checked)}
                          disabled={readOnly}
                        />
                      </div>
                    ) : (
                      <input 
                        type={col.type || 'text'}
                        className={`w-full p-2 bg-white dark:bg-slate-800 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-slate-200 ${col.required && !row[col.key] ? 'border-rose-300' : 'border-slate-200 dark:border-slate-700'} ${col.readOnly ? 'bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-400' : ''}`}
                        value={row[col.key] || ''}
                        onChange={e => !col.readOnly && updateTechnicalRow(sectionId, idx, col.key, e.target.value)}
                        placeholder={col.label}
                        disabled={readOnly || col.readOnly}
                        maxLength={500}
                      />
                    )}
                  </td>
                ))}
                <td className="p-2 text-center">
                  {!readOnly && (
                  <button onClick={() => removeTechnicalRow(sectionId, idx)} className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={columns.length + 1} className="p-4 text-center text-slate-400 italic">Keine Einträge vorhanden.</td>
              </tr>
            )}
          </tbody>
        </table>
        {!readOnly && (
        <button onClick={() => addTechnicalRow(sectionId)} className="mt-3 flex items-center gap-2 text-sm font-bold text-indigo-600 hover:text-indigo-700 px-3 py-2 hover:bg-indigo-50 rounded-lg transition-colors">
          <Plus className="w-4 h-4" /> Zeile hinzufügen
        </button>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6 max-w-[85rem] mx-auto">
        
        {/* 1. Servers */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('servers')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Server className="w-5 h-5 text-blue-500" /> 1. Server / Betriebssysteme</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['servers'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['servers'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    {renderTable('servers', [
                      { key: 'serverName', label: 'Servername', required: true },
                      { key: 'ip', label: 'IP-Adresse' },
                      { key: 'fqdn', label: 'Adresse / FQDN' },
                      { key: 'stage', label: 'Stage', type: 'select', options: ['Prod', 'Test', 'Dev'], required: true },
                      { key: 'dmz', label: 'DMZ', type: 'checkbox', width: '60px' },
                      { key: 'desc', label: 'Beschreibung / Nutzung' },
                      { key: 'os', label: 'Betriebssystem' },
                      { key: 'port', label: 'Zugriff Port/Protokoll' },
                      { key: 'expiry', label: 'Ablaufdatum', type: 'date' }
                    ])}
                </div>
            )}
        </div>

        {/* 2. Databases */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('databases')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Database className="w-5 h-5 text-indigo-500" /> 2. Datenbanken / Server</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['databases'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['databases'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    {renderTable('databases', [
                      { key: 'serverName', label: 'Servername', required: true },
                      { key: 'ip', label: 'IP-Adresse' },
                      { key: 'fqdn', label: 'Adresse / FQDN' },
                      { key: 'stage', label: 'Stage', type: 'select', options: ['Prod', 'Test', 'Dev'], required: true },
                      { key: 'dbType', label: 'Datenbanktyp' },
                      { key: 'instance', label: 'Instanz / DB-Name' },
                      { key: 'product', label: 'Produktname & Version' },
                      { key: 'port', label: 'Zugriff Port/Protokoll' }
                    ])}
                </div>
            )}
        </div>

        {/* 3. Ports */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('ports')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Network className="w-5 h-5 text-emerald-500" /> 3. Portfreischaltungen</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['ports'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['ports'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    {renderTable('ports', [
                      { key: 'fromServer', label: 'Von Server', type: 'multiselect', options: ['psm1', 'psm2', 'psm3', 'psm4', 'psm5', 'psm6', 'psmp'], width: '300px' },
                      { key: 'fromStage', label: 'Von Stage', type: 'select', options: ['Prod', 'Test', 'Dev'] },
                      { key: 'toServer', label: 'Nach Server', type: 'select', options: serverOptions },
                      { key: 'toIp', label: 'Nach IP' },
                      { key: 'toStage', label: 'Nach Stage', type: 'select', options: ['Prod', 'Test', 'Dev'] },
                      { key: 'port', label: 'Port/Protokoll', required: true },
                      { key: 'provider', label: 'Dienstleister' },
                      { key: 'interfaceId', label: 'Schnittstellen-ID' },
                      { key: 'comment', label: 'Kommentar' }
                    ])}
                </div>
            )}
        </div>

        {/* 4. Safes */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('safes')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Lock className="w-5 h-5 text-amber-500" /> 4. Safe-Struktur (CyberArk)</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['safes'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['safes'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    {renderTable('safes', [
                      { key: 'userGroup', label: 'Nutzergruppe' },
                      { key: 'safeName', label: 'Safe Name (fachlich)', required: true },
                      { key: 'safeDesc', label: 'Safe Beschreibung' },
                      { key: 'techSafeName', label: 'Technischer Safe Name', required: true },
                      { key: 'adGroup', label: 'AD-Gruppe', required: true },
                      { key: 'adGroupDesc', label: 'Beschreibung AD-Gruppe' },
                      { key: 'approver', label: 'Zweitgenehmiger (Omada)' },
                      { key: 'sod', label: 'SoD-Hinweis' }
                    ])}
                </div>
            )}
        </div>

        {/* 5. Safe Members */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('safeMembers')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Users className="w-5 h-5 text-purple-500" /> 5. Mitglieder der Safes</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['safeMembers'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['safeMembers'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    <div className="mb-4 p-4 bg-blue-50 text-blue-800 rounded-lg text-sm flex items-start gap-3">
                      <Info className="w-5 h-5 shrink-0 mt-0.5" />
                      <div>
                        <strong>Hinweis:</strong> Änderungen an der Mitgliederstruktur erfolgen regelmäßig. Die führende Quelle für aktuelle Safe-Mitglieder ist Omada. Diese Tabelle dient der Dokumentation des Soll-Zustands.
                      </div>
                    </div>
                    {renderTable('safeMembers', [
                      { key: 'safeName', label: 'Safe Name', type: 'select', options: safeOptions },
                      { key: 'adGroup', label: 'AD-Gruppe des Safes' },
                      { key: 'memberName', label: 'Name Mitglied' },
                      { key: 'identity', label: 'Primäre Identität' }
                    ])}
                </div>
            )}
        </div>

        {/* 6. Shared Accounts */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('sharedAccounts')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Key className="w-5 h-5 text-rose-500" /> 6. Shared Accounts</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['sharedAccounts'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['sharedAccounts'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    {renderTable('sharedAccounts', [
                      { key: 'bizName', label: 'Fachlicher Name' },
                      { key: 'techName', label: 'Technischer Name', required: true },
                      { key: 'sam', label: 'sAMAccountName' },
                      { key: 'login', label: 'Anmeldename (Ziel)' },
                      { key: 'desc', label: 'Beschreibung' },
                      { key: 'isAd', label: 'AD Account', type: 'checkbox', width: '80px' },
                      { key: 'owner', label: 'Accountbesitzer' },
                      { key: 'ownerId', label: 'Identität Besitzer' }
                    ])}
                </div>
            )}
        </div>

        {/* 7. Permissions */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('permissions')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Shield className="w-5 h-5 text-cyan-500" /> 7. Berechtigungszuordnungen</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['permissions'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['permissions'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    {renderTable('permissions', [
                      { key: 'bizName', label: 'Fachlicher Account', type: 'select', options: accountOptions },
                      { key: 'techName', label: 'Technischer Account', type: 'select', options: accountOptions },
                      { key: 'roleId', label: 'Role ID', required: true },
                      { key: 'roleName', label: 'Role Displayname' },
                      { key: 'roleDesc', label: 'Role Description' },
                      { key: 'bizSystem', label: 'Fachliches System' },
                      { key: 'bizSystemId', label: 'Fachliche System-ID' }
                    ])}
                </div>
            )}
        </div>

        {/* 8. Mapping */}
        <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm print:border-0 print:shadow-none">
            <button onClick={() => toggleSection('mapping')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors print:hidden">
                <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200"><Link className="w-5 h-5 text-indigo-600" /> 8. Shared Accounts zu Safe</div>
                <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openSections['mapping'] ? 'rotate-90' : ''}`} />
            </button>
            {(openSections['mapping'] || typeof window !== 'undefined' && window.matchMedia('print').matches) && (
                <div className="p-6 border-t border-slate-100 dark:border-slate-700">
                    {renderTable('mapping', [
                      { key: 'techAccount', label: 'Technischer Account', type: 'select', options: accountOptions, required: true },
                      { key: 'bizAccount', label: 'Fachlicher Account', readOnly: true },
                      { key: 'techSafe', label: 'Technischer Safe', type: 'select', options: safeOptions, required: true },
                      { key: 'safeName', label: 'Fachlicher Safe', readOnly: true }
                    ])}
                </div>
            )}
        </div>

    </div>
  );
};
