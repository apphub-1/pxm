import ExcelJS from 'exceljs';
import * as XLSX from 'xlsx';
import { API_BASE_URL } from '../config';
import { getAccessToken } from '../auth';
import { DEFAULT_HEADERS } from '../constants';

export const handleFullExcelExport = async (editingRow: any) => {
    if (!editingRow?.id) return;
    try {
      const token = getAccessToken();
      const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
      const id = editingRow.id;

      // Lade alle Daten parallel
      const [onbRes, techRes, secRes, secOnbRes] = await Promise.all([
        fetch(`${API_BASE_URL}/onboarding/${id}`, { headers }),
        fetch(`${API_BASE_URL}/technical/${id}`, { headers }),
        fetch(`${API_BASE_URL}/secrets/${id}`, { headers }),
        fetch(`${API_BASE_URL}/secrets-onboarding/${id}`, { headers })
      ]);

      const onbJson = await onbRes.json();
      const techJson = await techRes.json();
      const secJson = await secRes.json();
      const secOnbJson = await secOnbRes.json();

      const onbData = onbJson.data ? JSON.parse(onbJson.data) : {};
      const techData = techJson.data ? JSON.parse(techJson.data) : {};
      const secData = secJson.data ? JSON.parse(secJson.data) : {};
      const secOnbData = secOnbJson.data ? JSON.parse(secOnbJson.data) : {};

      // Ensure arrays exist to prevent crashes
      secOnbData.serverRegistry = secOnbData.serverRegistry || [];
      secOnbData.serverClusters = secOnbData.serverClusters || [];
      secOnbData.containerRegistry = secOnbData.containerRegistry || [];
      secOnbData.databaseRegistry = secOnbData.databaseRegistry || [];
      secOnbData.components = secOnbData.components || [];

      // Helper to resolve infrastructure info for export
      const resolveInfraInfo = (infraName: string) => {
          if (!infraName) return '';
          
          // 1. Server
          const server = secOnbData.serverRegistry.find((s: any) => s && s.hostname === infraName);
          if (server) {
              return `[Server] Host: ${server.hostname}, IP: ${server.ip || '-'}, Segment: ${server.segment || '-'}, Komponente: ${server.component || '-'}`;
          }

          // 2. Cluster
          const cluster = secOnbData.serverClusters.find((c: any) => c && c.name === infraName);
          if (cluster) {
              let info = `[Cluster] Name: ${cluster.name}, Komponente: ${cluster.component || '-'}\nNodes:`;
              const nodes = (cluster.nodes || '').split(/[;,]/).map((n: string) => n.trim()).filter(Boolean);
              nodes.forEach((nodeName: string) => {
                  const node = secOnbData.serverRegistry.find((s: any) => s && s.hostname === nodeName);
                  if (node) {
                      info += `\n  - ${node.hostname} (${node.ip || '-'})`;
                  } else {
                      info += `\n  - ${nodeName}`;
                  }
              });
              return info;
          }

          // 3. Container
          const container = secOnbData.containerRegistry.find((c: any) => c && c.name === infraName);
          if (container) {
              return `[Container] Name: ${container.name}, Typ: ${container.type || '-'}, NS: ${container.namespace || '-'}, API: ${container.apiUrl || '-'}, Komponente: ${container.component || '-'}`;
          }

          // 4. Database
          const db = secOnbData.databaseRegistry.find((d: any) => {
               if (!d) return false;
               const info = d.instance || d.dbName || d.sid || '';
               const formatted = `${d.dbType}${info ? ` ${info}` : ''} (${d.server})`;
               return formatted === infraName;
          });

          if (db) {
              let info = `[Database] Typ: ${db.dbType}, Details: ${db.instance || db.dbName || db.sid || '-'}, Port: ${db.port || '-'}, Komponente: ${db.component || '-'}`;
              if (db.server) {
                  info += `\n>> Host: ${resolveInfraInfo(db.server)}`;
              }
              return info;
          }
          return '';
      };

      const resolvePerInfra = (row: any, field: string, formatter?: (val: any) => string) => {
          if (!row.infrastructure) return '';
          const infras = row.infrastructure.split(';').map((s: string) => s.trim()).filter(Boolean);
          const details = row.infraDetails ? JSON.parse(row.infraDetails) : {};
          
          if (infras.length === 0) return '';
          if (infras.length === 1) {
              const val = details[infras[0]]?.[field] || row[field] || ''; 
              return formatter ? formatter(val) : val;
          }
          
          return infras.map((infra: string) => {
              const val = details[infra]?.[field] || '';
              const formatted = formatter ? formatter(val) : val;
              return `${infra}: ${formatted}`;
          }).join('\n');
      };

      const workbook = new ExcelJS.Workbook();
      workbook.creator = 'PXM Manager';
      workbook.created = new Date();

      // --- Styles ---
      const pamHeaderFill: ExcelJS.Fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF2563EB' } }; // Blue 600
      const secMgmtHeaderFill: ExcelJS.Fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF97316' } }; // Orange 500
      const headerFont: ExcelJS.Font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 };
      const sectionFont: ExcelJS.Font = { bold: true, size: 14, color: { argb: 'FF1E293B' } }; // Slate 800
      const borderStyle: ExcelJS.Borders = {
          top: { style: 'thin', color: { argb: 'FFCBD5E1' } },
          left: { style: 'thin', color: { argb: 'FFCBD5E1' } },
          bottom: { style: 'thin', color: { argb: 'FFCBD5E1' } },
          right: { style: 'thin', color: { argb: 'FFCBD5E1' } }
      };

      // --- 1. Status & Onboarding ---
      const wsOverview = workbook.addWorksheet("PAM - Status & Onboarding");
      wsOverview.columns = [
          { header: 'Bereich', key: 'area', width: 25 },
          { header: 'Feld', key: 'field', width: 40 },
          { header: 'Wert', key: 'value', width: 60 }
      ];
      
      const ovHeader = wsOverview.getRow(1);
      ovHeader.font = headerFont;
      ovHeader.fill = pamHeaderFill;
      ovHeader.height = 24;
      ovHeader.alignment = { vertical: 'middle' };

      const ONBOARDING_LABELS: Record<string, string> = {
        archDesc: "Architektur des Zielsystems",
        osList: "Betriebssysteme",
        dbList: "Datenbanken",
        serverReplace: "Ist geplant, die Server auszutauschen?",
        serverReplaceDate: "Geplantes Austauschdatum",
        hasLoadBalancer: "Load Balancer / Reverse Proxy vorhanden?",
        techType: "Technologie",
        needsCerts: "Werden Zertifikate benötigt?",
        fourEyes: "Aktives 4-Augen-Prinzip?",
        licenseType: "Lizenzart",
        urlProd: "URL Produktion",
        urlTest: "URL Test",
        loginMethod: "Anmeldeverfahren",
        accountType: "Account-Typ",
        multiSession: "Kann User mehrere Sessions öffnen?",
        usernameNaming: "Username Nomenklatur",
        pwChangeDesc: "Wie werden Passwörter geändert?",
        autoRotation: "Kann Rotation automatisiert werden?",
        whoChangesPw: "Wer ändert Passwörter?",
        pwInterval: "Wechselintervall",
        hasTestUsers: "Testuser vorhanden?",
        testUsersList: "Testuser Accounts",
        omadaRights: "Rechte über Omada?",
        hasEmergencyAccounts: "Existieren Notfallaccounts?",
        emergencyAccountsList: "Notfall Accounts",
        matrixLogin: "Anmeldung",
        matrixPwChange: "Passwortwechsel",
        sBaseProOrder: "S-Base Pro Auftrag"
      };

      const overviewRows = [
        { area: "Stammdaten", field: "Anwendungsname", value: editingRow.Name },
        { area: "Stammdaten", field: "ICTO", value: editingRow.ICTO },
        { area: "Stammdaten", field: "Kritikalität", value: editingRow.Kritikalität },
        { area: "Stammdaten", field: "tAV", value: editingRow.tAV },
        ...Object.entries(onbData).map(([k, v]) => {
            if (k === 'selectedVariant') return null; // Skip internal field
            return { 
                area: "Onboarding", 
                field: ONBOARDING_LABELS[k] || k, 
                value: typeof v === 'boolean' ? (v ? 'Ja' : 'Nein') : v 
            };
        }).filter(Boolean)
      ];

      overviewRows.forEach(r => {
          if(r) {
            const row = wsOverview.addRow(r);
            row.getCell(1).font = { bold: true, color: { argb: 'FF475569' } };
            row.eachCell(cell => { 
                cell.border = borderStyle; 
                cell.alignment = { vertical: 'top', wrapText: true }; 
            });
          }
      });

      // --- Helper for Tables ---
      const addTableToSheet = (ws: ExcelJS.Worksheet, title: string, data: any[], columns: {key: string, label: string, transform?: (val: any, row?: any) => any}[], fillStyle: ExcelJS.Fill) => {
          // Add Title
          const titleRow = ws.addRow([title]);
          titleRow.font = sectionFont;
          titleRow.height = 30;
          titleRow.alignment = { vertical: 'bottom' };
          
          // Add Header
          const headerRow = ws.addRow(columns.map(c => c.label));
          headerRow.font = headerFont;
          headerRow.fill = fillStyle;
          headerRow.height = 24;
          headerRow.alignment = { vertical: 'middle' };
          
          // Add Data
          if (data && data.length > 0) {
              data.forEach(item => {
                  const rowValues = columns.map(col => {
                      let val = item[col.key];
                      if (col.transform) val = col.transform(val, item);
                      if (Array.isArray(val)) return val.join('; ');
                      return typeof val === 'boolean' ? (val ? 'Ja' : 'Nein') : val;
                  });
                  const row = ws.addRow(rowValues);
                  row.eachCell(cell => { 
                      cell.border = borderStyle;
                      cell.alignment = { vertical: 'top', wrapText: true };
                  });
              });
          } else {
              const row = ws.addRow(["Keine Einträge vorhanden"]);
              row.getCell(1).font = { italic: true, color: { argb: 'FF94A3B8' } };
              ws.mergeCells(row.number, 1, row.number, columns.length);
              row.getCell(1).border = borderStyle;
          }

          // Add Spacing
          ws.addRow([]);
      };

      // --- 2. Technische Struktur ---
      const wsTech = workbook.addWorksheet("PAM - Technische Struktur");
      
      addTableToSheet(wsTech, "1. Server / Betriebssysteme", techData.servers, [
          { key: 'serverName', label: 'Servername' }, { key: 'ip', label: 'IP-Adresse' }, { key: 'fqdn', label: 'Adresse / FQDN' }, 
          { key: 'stage', label: 'Stage' }, { key: 'dmz', label: 'DMZ' }, { key: 'desc', label: 'Beschreibung / Nutzung' }, 
          { key: 'os', label: 'Betriebssystem' }, { key: 'port', label: 'Zugriff Port/Protokoll' }, { key: 'expiry', label: 'Ablaufdatum' }
      ], pamHeaderFill);
      
      addTableToSheet(wsTech, "2. Datenbanken / Server", techData.databases, [
          { key: 'serverName', label: 'Servername' }, { key: 'ip', label: 'IP-Adresse' }, { key: 'fqdn', label: 'Adresse / FQDN' },
          { key: 'stage', label: 'Stage' }, { key: 'dbType', label: 'Datenbanktyp' }, { key: 'instance', label: 'Instanz / DB-Name' },
          { key: 'product', label: 'Produktname & Version' }, { key: 'port', label: 'Zugriff Port/Protokoll' }
      ], pamHeaderFill);

      addTableToSheet(wsTech, "3. Portfreischaltungen", techData.ports, [
          { key: 'fromServer', label: 'Von Server' }, { key: 'fromStage', label: 'Von Stage' }, { key: 'toServer', label: 'Nach Server' }, 
          { key: 'toIp', label: 'Nach IP' }, { key: 'toStage', label: 'Nach Stage' }, { key: 'port', label: 'Port/Protokoll' }, 
          { key: 'provider', label: 'Dienstleister' }, { key: 'interfaceId', label: 'Schnittstellen-ID' }, { key: 'comment', label: 'Kommentar' }
      ], pamHeaderFill);

      addTableToSheet(wsTech, "4. Safe-Struktur (CyberArk)", techData.safes, [
          { key: 'userGroup', label: 'Nutzergruppe' }, { key: 'safeName', label: 'Safe Name (fachlich)' }, { key: 'safeDesc', label: 'Safe Beschreibung' }, 
          { key: 'techSafeName', label: 'Technischer Safe Name' }, { key: 'adGroup', label: 'AD-Gruppe' }, { key: 'adGroupDesc', label: 'Beschreibung AD-Gruppe' }, 
          { key: 'approver', label: 'Zweitgenehmiger (Omada)' }, { key: 'sod', label: 'SoD-Hinweis' }
      ], pamHeaderFill);

      addTableToSheet(wsTech, "5. Mitglieder der Safes", techData.safeMembers, [
          { key: 'safeName', label: 'Safe Name' }, { key: 'adGroup', label: 'AD-Gruppe' }, { key: 'memberName', label: 'Name Mitglied' }, { key: 'identity', label: 'Primäre Identität' }
      ], pamHeaderFill);

      addTableToSheet(wsTech, "6. Shared Accounts", techData.sharedAccounts, [
          { key: 'bizName', label: 'Fachlicher Name' }, { key: 'techName', label: 'Technischer Name' }, { key: 'sam', label: 'sAMAccountName' }, 
          { key: 'login', label: 'Anmeldename (Ziel)' }, { key: 'desc', label: 'Beschreibung' }, { key: 'isAd', label: 'AD Account' }, 
          { key: 'owner', label: 'Accountbesitzer' }, { key: 'ownerId', label: 'Identität Besitzer' }
      ], pamHeaderFill);

      addTableToSheet(wsTech, "7. Berechtigungszuordnungen", techData.permissions, [
          { key: 'bizName', label: 'Fachlicher Account' }, { key: 'techName', label: 'Technischer Account' }, { key: 'roleId', label: 'Role ID' }, 
          { key: 'roleName', label: 'Role Displayname' }, { key: 'roleDesc', label: 'Role Description' }, { key: 'bizSystem', label: 'Fachliches System' }, 
          { key: 'bizSystemId', label: 'Fachliche System-ID' }
      ], pamHeaderFill);

      addTableToSheet(wsTech, "8. Shared Accounts zu Safe", techData.mapping, [
          { key: 'techAccount', label: 'Technischer Account' }, { key: 'bizAccount', label: 'Fachlicher Account' }, 
          { key: 'techSafe', label: 'Technischer Safe' }, { key: 'safeName', label: 'Fachlicher Safe' }
      ], pamHeaderFill);

      // Set generic width for tech sheet
      for(let i=1; i<=10; i++) wsTech.getColumn(i).width = 25;

      // --- 3. Secrets Komponenten ---
      const wsSecComp = workbook.addWorksheet("SecMgmt Komponenten");
      wsSecComp.columns = [
          { header: 'Komponente', key: 'comp', width: 30 },
          { header: 'Frage', key: 'question', width: 60 },
          { header: 'Antwort', key: 'answer', width: 60 }
      ];
      const secCompHeader = wsSecComp.getRow(1);
      secCompHeader.font = headerFont;
      secCompHeader.fill = secMgmtHeaderFill;
      secCompHeader.height = 24;
      secCompHeader.alignment = { vertical: 'middle' };

      const SECRETS_COMPONENT_LABELS: Record<string, string> = {
        softwareType: "Art der Anwendung",
        operatingModel: "Betriebsmodell",
        appType: "Läuft die Anwendung auf:",
        os: "Betriebssystem",
        deployment: "Wie wird die Anwendung bereitgestellt?",
        initialAuth: "Wie werden Anmeldeinformationen initial bereitgestellt?",
        containerSelfBuilt: "Wurde der Container / die Anwendung selbst erstellt?",
        k8sSecrets: "Verwendet die Anwendung Kubernetes Secrets?",
        codeControl: "Besteht Kontrolle über den Anwendungscode?",
        cloudIn: "Cloud in",
        serverless: "Nutzung von Serverless Functions?",
        cloudVMs: "Nutzung von VMs in der Cloud (Hyperscaler)?",
        codeControlServer: "Besteht Kontrolle über Code?",
        configControlServer: "Besteht Kontrolle über Konfigurationsdateien?",
        centralConfig: "Sind Konfigurationsdateien zentral zugänglich?",
        javaWebserver: "Läuft die Anwendung auf einem Java-Webserver?",
        dataSources: "Nutzt die Anwendung DataSources?",
        dataSourcesPurpose: "Zweck der DataSources",
        secretTypes: "Welche Arten von Secrets werden genutzt?",
        secretStorage: "Wie werden Secrets aktuell gespeichert?",
        manualProcesses: "Werden Secrets auch für manuelle Prozesse genutzt?",
        rotationResponsibility: "Gibt es Secrets, deren Rotation in der Verantwortung der Deka liegt?",
        rotationLevel: "Gilt dies für:",
        currentRotation: "Wie erfolgt die bisherige Rotation?",
        targetTool: "Eingesetztes Secrets-Management-Tool",
        targetVariant: "Anbindungsvariante",
        targetRotationMech: "Rotationsmechanismus",
        targetTimeWindow: "Zeitfenster der Rotation",
        targetFrequency: "Häufigkeit der Rotation"
      };

      if (secOnbData.components && secOnbData.components.length > 0) {
          secOnbData.components.forEach((comp: any) => {
              if (!comp) return;
              Object.entries(comp).forEach(([k, v]) => {
                  if (k === 'name') return;
                  const row = wsSecComp.addRow({ 
                      comp: comp.name,
                      question: SECRETS_COMPONENT_LABELS[k] || k, 
                      answer: Array.isArray(v) ? v.join(', ') : (typeof v === 'boolean' ? (v ? 'Ja' : 'Nein') : v) 
                  });
                  row.eachCell(cell => { 
                      cell.border = borderStyle; 
                      cell.alignment = { vertical: 'top', wrapText: true }; 
                  });
              });
              // Add separator row
              wsSecComp.addRow([]);
          });
      } else {
          const row = wsSecComp.addRow({ comp: "Keine Komponenten definiert", question: "", answer: "" });
          row.getCell(1).font = { italic: true, color: { argb: 'FF94A3B8' } };
      }


      // --- 4. Secrets Infrastruktur ---
      const wsSecInfra = workbook.addWorksheet("SecMgmt Infrastruktur");
      
      addTableToSheet(wsSecInfra, "Serverregister", secOnbData.serverRegistry, [
          { key: 'hostname', label: 'Hostname' }, { key: 'ip', label: 'IP-Adresse' }, { key: 'os', label: 'OS' }, { key: 'segment', label: 'Segment' }, { key: 'component', label: 'Systemkomponente' }
      ], secMgmtHeaderFill);

      addTableToSheet(wsSecInfra, "Server Cluster", secOnbData.serverClusters, [
          { key: 'name', label: 'Cluster Name' }, { key: 'nodes', label: 'Server Nodes' }, { key: 'component', label: 'Systemkomponente' }
      ], secMgmtHeaderFill);

      addTableToSheet(wsSecInfra, "Container- / Cluster-Register", secOnbData.containerRegistry, [
          { key: 'name', label: 'Name / Kennung' }, { key: 'type', label: 'Typ' }, { key: 'namespace', label: 'Bereich / Namespace' },
          { key: 'apiUrl', label: 'API-URL / Host' }, { key: 'component', label: 'Systemkomponente' }
      ], secMgmtHeaderFill);

      addTableToSheet(wsSecInfra, "Datenbankregister", secOnbData.databaseRegistry, [
          { key: 'server', label: 'Server' }, { key: 'dbType', label: 'Typ' }, { key: 'component', label: 'Systemkomponente' },
          { key: 'instance', label: 'Instanz (MSSQL/DB2)' }, { key: 'port', label: 'Port' }, { key: 'authType', label: 'Auth-Typ (MSSQL)' },
          { key: 'version', label: 'Version (MySQL)' }, { key: 'dbName', label: 'Datenbankname (Postgres/DB2)' },
          { key: 'sid', label: 'SID / Service Name (Oracle)' }, { key: 'oracleHome', label: 'Oracle Home (Oracle)' }
      ], secMgmtHeaderFill);

      for(let i=1; i<=10; i++) wsSecInfra.getColumn(i).width = 25;


      // --- 5. Secrets Inventar ---
      const wsSecrets = workbook.addWorksheet("SecMgmt Inventar");
      
      addTableToSheet(wsSecrets, "1. Secret Inventory", secData.inventory, [
          { key: 'category', label: 'Kategorie' }, { key: 'name', label: 'Name / ID' }, { key: 'owner', label: 'Secret Owner' },
          { key: 'holder', label: 'Secret Holder' }, { key: 'layer', label: 'Layer' }, 
          { key: 'localOrAd', label: 'Lokal oder AD' },
          { key: 'dependency', label: 'Abhängigkeit', transform: (v, r) => {
              try {
                  const deps = JSON.parse(v || '[]');
                  if (Array.isArray(deps)) return deps.map((d: any) => `${d.Name} (${d.ICTO})`).join('; ');
                  return '';
              } catch { return v || ''; }
          }},
          { key: 'dependencyInfo', label: 'Info zur Abhängigkeit', transform: (v, r) => {
              try {
                  const deps = JSON.parse(r.dependency || '[]');
                  if (!Array.isArray(deps)) return '';
                  return deps.map((d: any) => `${d.Name}: ${d.component}`).join('; ');
              } catch { return ''; }
          }},
          { key: 'infrastructure', label: 'Infrastruktur Zuordnung' },
          { key: 'info', label: 'Info', transform: (v, r) => {
              if (!r.infrastructure) return '';
              const infras = r.infrastructure.split(';').map((s: string) => s.trim()).filter(Boolean);
              const infraDetails = r.infraDetails ? JSON.parse(r.infraDetails) : {};
              
              const richText: any[] = [];

              infras.forEach((infra: string, idx: number) => {
                  if (idx > 0) richText.push({ text: '\n\n' });

                  // Infra Name
                  richText.push({ text: `${infra}`, font: { bold: true, color: { argb: 'FF1E40AF' }, size: 11 } });
                  
                  // Basic Info
                  const basicInfo = resolveInfraInfo(infra);
                  if (basicInfo) {
                      richText.push({ text: `\n${basicInfo}`, font: { color: { argb: 'FF334155' } } });
                  }

                  // Secret Endpoints
                  const epJson = infraDetails[infra]?.['secretEndpoint'];
                  if (epJson) {
                      try {
                          const endpoints = JSON.parse(epJson);
                          if (Array.isArray(endpoints) && endpoints.length > 0) {
                              richText.push({ text: '\nEndpoints:', font: { bold: true, color: { argb: 'FF047857' } } });
                              endpoints.forEach((ep: any) => {
                                  richText.push({ text: `\n• ${ep.category} / ${ep.location_type}`, font: { color: { argb: 'FF059669' } } });
                                  if (ep.fields) {
                                      Object.entries(ep.fields).forEach(([k, val]) => {
                                          richText.push({ text: `\n  - ${k}: ${val}`, font: { italic: true, color: { argb: 'FF64748B' }, size: 9 } });
                                      });
                                  }
                              });
                          }
                      } catch {}
                  }
              });

              return { richText };
          }},
          { key: 'dialogUser', label: 'Dialognutzung', transform: (v, r) => resolvePerInfra(r, 'dialogUser') },
          { key: 'autoRotation', label: 'Auto Rotation', transform: (v, r) => resolvePerInfra(r, 'autoRotation') },
          { key: 'rotationMech', label: 'Rotationsmechanismus', transform: (v, r) => resolvePerInfra(r, 'rotationMech') }, 
          { key: 'frequency', label: 'Häufigkeit', transform: (v, r) => resolvePerInfra(r, 'frequency') }, 
          { key: 'timeWindow', label: 'Zeitfenster', transform: (v, r) => resolvePerInfra(r, 'timeWindow') }
      ], secMgmtHeaderFill);

      addTableToSheet(wsSecrets, "2. Safe- / Pfad-Struktur", secData.safes, [
          { key: 'userGroup', label: 'Nutzergruppe' }, { key: 'safeName', label: 'Safe Name / Pfad (fachlich)' }, { key: 'safeDesc', label: 'Safe / Pfad Beschreibung' },
          { key: 'techSafeName', label: 'Technischer Safe Name / Pfad-Prefix' }, { key: 'adGroup', label: 'AD-Gruppe' }, { key: 'adGroupDesc', label: 'Fachliche Beschreibung AD-Gruppe' },
          { key: 'approver', label: 'Zweitgenehmiger in Omada' }, { key: 'sod', label: 'SoD-Hinweis' }
      ], secMgmtHeaderFill);

      addTableToSheet(wsSecrets, "3. Mitglieder der Safes", secData.members, [
          { key: 'safeName', label: 'Safe Name' }, { key: 'adGroup', label: 'AD-Gruppe des Safes' }, { key: 'memberName', label: 'Name Mitglied' }, { key: 'identity', label: 'Primäre Identität' }
      ], secMgmtHeaderFill);

      addTableToSheet(wsSecrets, "4. Secrets zu Safe", secData.mapping, [
          { key: 'bizSecret', label: 'Fachlicher Secret Name' }, 
          { key: 'techSecret', label: 'Technischer Secret Name' },
          { key: 'safeName', label: 'Safe Name' }, { key: 'techSafe', label: 'Technischer Safe' }
      ], secMgmtHeaderFill);

      for(let i=1; i<=14; i++) wsSecrets.getColumn(i).width = 20;


      // --- Download ---
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Gesamtexport_${editingRow.ICTO}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);

    } catch (e) {
      console.error(e);
      alert("Fehler beim Erstellen des Excel-Exports.");
    }
};

export const exportListToExcel = (filteredData: any[]) => {
    // Prepare data for Excel using the currently filtered data
    const excelData = filteredData.map(row => {
      const entry: any = {};
      DEFAULT_HEADERS.forEach(h => {
        entry[h] = row[h] || '';
      });
      return entry;
    });

    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "PAM Governance");
    
    // Generate filename with current date
    const dateStr = new Date().toISOString().split('T')[0];
    XLSX.writeFile(workbook, `PAM_Governance_Export_${dateStr}.xlsx`);
};

// --- Secrets Inventory Helper ---

export const downloadSecretInventoryTemplate = async (columns: any[], governanceRow: any) => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Template');

    worksheet.columns = columns.map(c => ({
        header: c.label,
        key: c.key,
        width: c.width ? parseInt(c.width) / 7 : 25
    }));

    const headerRow = worksheet.getRow(1);
    headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4F46E5' } };
    headerRow.alignment = { vertical: 'middle', horizontal: 'center' };
    headerRow.height = 24;

    columns.forEach((col, index) => {
        if (col.options && col.options.length > 0) {
            const letter = worksheet.getColumn(index + 1).letter;
            for (let i = 2; i <= 1000; i++) {
                worksheet.getCell(`${letter}${i}`).dataValidation = {
                    type: 'list',
                    allowBlank: true,
                    formulae: [`"${col.options.join(',')}"`]
                };
            }
        }
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Secret_Inventory_Vorlage_${governanceRow.Name}_${governanceRow.ICTO}.xlsx`;
    a.click();
    URL.revokeObjectURL(url);
};

export const importSecretInventory = async (file: File, columns: any[]) => {
    const buffer = await file.arrayBuffer();
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(buffer);
    
    const worksheet = workbook.worksheets[0];
    if (!worksheet) throw new Error("Kein Arbeitsblatt gefunden");

    const jsonData: any[] = [];
    const headers: string[] = [];

    worksheet.getRow(1).eachCell({ includeEmpty: true }, (cell, colNumber) => {
        headers[colNumber] = cell.text ? cell.text.toString().trim() : '';
    });

    worksheet.eachRow((row, rowNumber) => {
        if (rowNumber === 1) return;
        const rowData: any = {};
        let hasData = false;
        row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
            const header = headers[colNumber];
            if (header) {
                const val = cell.text ? cell.text.toString().trim() : '';
                if (val) {
                    rowData[header] = val;
                    hasData = true;
                }
            }
        });
        if (hasData) jsonData.push(rowData);
    });

    const mappedData = jsonData.map((row: any) => {
        const newRow: any = {};
        columns.forEach(col => {
            let val = row[col.label];
            if (val === undefined) val = row[col.key];
            if (val === undefined) {
                const keyMatch = Object.keys(row).find(k => k.toLowerCase() === col.label.toLowerCase() || k.toLowerCase() === col.key.toLowerCase());
                if (keyMatch) val = row[keyMatch];
            }
            if (val !== undefined) newRow[col.key] = String(val);
        });
        return newRow;
    });
    
    return mappedData;
};

// --- Infrastructure Helper ---

export const downloadInfrastructureTemplate = async (governanceRow: any, componentOptions: string[], serverRegistryOptions: string[]) => {
      const workbook = new ExcelJS.Workbook();

      const addSheet = (name: string, columns: any[]) => {
          const worksheet = workbook.addWorksheet(name);
          worksheet.columns = columns.map(c => ({
              header: c.label,
              key: c.key,
              width: c.width ? parseInt(c.width) / 7 : 25
          }));
          
          const headerRow = worksheet.getRow(1);
          headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
          headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4F46E5' } };
          
          columns.forEach((col, index) => {
              let validationFormula = null;

              if (name === "Server Cluster" && col.key === "nodes") {
                  validationFormula = "'Serverregister'!$A$2:$A$1000";
              } else if (col.options && col.options.length > 0) {
                  validationFormula = `"${col.options.join(',')}"`;
              }

              if (validationFormula) {
                  const letter = worksheet.getColumn(index + 1).letter;
                  for (let i = 2; i <= 1000; i++) {
                      worksheet.getCell(`${letter}${i}`).dataValidation = {
                          type: 'list',
                          allowBlank: true,
                          formulae: [validationFormula],
                          showErrorMessage: false
                      };
                  }
              }

              if (col.type === 'multiselect') {
                  const cell = headerRow.getCell(index + 1);
                  cell.note = "Mehrfachauswahl möglich: Werte bitte mit Komma trennen (z.B. Server1, Server2).\nExcel unterstützt keine native Mehrfachauswahl im Dropdown.";
              }
          });
      };

      const serverRegistryColumns = [
          { key: 'hostname', label: 'Hostname', required: true },
          { key: 'ip', label: 'IP-Adresse' },
          { key: 'os', label: 'OS', type: 'select', options: ['Windows Server', 'RHEL Server'] },
          { key: 'segment', label: 'Segment', type: 'select', options: ['Produktion', 'Test', 'Entwicklung'] },
          { key: 'component', label: 'Systemkomponente', type: 'multiselect', options: componentOptions }
      ];

      const serverClusterColumns = [
          { key: 'name', label: 'Cluster Name', required: true },
          { key: 'nodes', label: 'Server Nodes', type: 'multiselect', options: serverRegistryOptions },
          { key: 'component', label: 'Systemkomponente', type: 'multiselect', options: componentOptions }
      ];

      const containerRegistryColumns = [
          { key: 'name', label: 'Name / Kennung', required: true },
          { key: 'type', label: 'Typ', type: 'select', options: ['Kubernetes', 'Docker', 'Podman', 'Azure Keyvault'] },
          { key: 'namespace', label: 'Bereich / Namespace' },
          { key: 'apiUrl', label: 'API-URL / Host' },
          { key: 'segment', label: 'Segment', type: 'select', options: ['Produktion', 'Test', 'Entwicklung'] },
          { key: 'component', label: 'Systemkomponente', type: 'multiselect', options: componentOptions }
      ];

      const databaseRegistryColumns = [
          { key: 'server', label: 'Server', type: 'select', options: [] }, 
          { key: 'dbType', label: 'Typ', type: 'select', options: ['MSSQL', 'MySQL', 'Postgres', 'Oracle', 'DB2'] },
          { key: 'component', label: 'Systemkomponente', type: 'multiselect', options: componentOptions },
          { key: 'instance', label: 'Instanz (MSSQL/DB2)' },
          { key: 'port', label: 'Port' },
          { key: 'authType', label: 'Auth-Typ (MSSQL)', type: 'select', options: ['Windows', 'SQL'] },
          { key: 'version', label: 'Version (MySQL)' },
          { key: 'dbName', label: 'Datenbankname (Postgres/DB2)' },
          { key: 'sid', label: 'SID / Service Name (Oracle)' },
          { key: 'oracleHome', label: 'Oracle Home (Oracle)' }
      ];

      addSheet("Serverregister", serverRegistryColumns);
      addSheet("Server Cluster", serverClusterColumns);
      addSheet("Container-Register", containerRegistryColumns);
      addSheet("Datenbankregister", databaseRegistryColumns);

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Infrastruktur_Vorlage_${governanceRow.Name}_${governanceRow.ICTO}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);
};

export const importInfrastructure = async (file: File) => {
    const buffer = await file.arrayBuffer();
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(buffer);

    const newData: any = {};
    let importCount = 0;

    const columnsMap: Record<string, {cols: any[], key: string}> = {
        "Serverregister": { key: 'serverRegistry', cols: [{ key: 'hostname', label: 'Hostname' }, { key: 'ip', label: 'IP-Adresse' }, { key: 'os', label: 'OS' }, { key: 'segment', label: 'Segment' }, { key: 'component', label: 'Systemkomponente', type: 'multiselect' }] },
        "Server Cluster": { key: 'serverClusters', cols: [{ key: 'name', label: 'Cluster Name' }, { key: 'nodes', label: 'Server Nodes', type: 'multiselect' }, { key: 'component', label: 'Systemkomponente', type: 'multiselect' }] },
        "Container-Register": { key: 'containerRegistry', cols: [{ key: 'name', label: 'Name / Kennung' }, { key: 'type', label: 'Typ' }, { key: 'namespace', label: 'Bereich / Namespace' }, { key: 'apiUrl', label: 'API-URL / Host' }, { key: 'segment', label: 'Segment' }, { key: 'component', label: 'Systemkomponente', type: 'multiselect' }] },
        "Datenbankregister": { key: 'databaseRegistry', cols: [{ key: 'server', label: 'Server' }, { key: 'dbType', label: 'Typ' }, { key: 'component', label: 'Systemkomponente', type: 'multiselect' }, { key: 'instance', label: 'Instanz (MSSQL/DB2)' }, { key: 'port', label: 'Port' }, { key: 'authType', label: 'Auth-Typ (MSSQL)' }, { key: 'version', label: 'Version (MySQL)' }, { key: 'dbName', label: 'Datenbankname (Postgres/DB2)' }, { key: 'sid', label: 'SID / Service Name (Oracle)' }, { key: 'oracleHome', label: 'Oracle Home (Oracle)' }] }
    };

    for (const [sheetName, config] of Object.entries(columnsMap)) {
        const worksheet = workbook.getWorksheet(sheetName);
        if (!worksheet) continue;

        const headers: string[] = [];
        worksheet.getRow(1).eachCell({ includeEmpty: true }, (cell, colNumber) => headers[colNumber] = cell.text ? cell.text.toString().trim() : '');

        const mappedData: any[] = [];
        worksheet.eachRow((row, rowNumber) => {
            if (rowNumber === 1) return;
            const newRow: any = {};
            let hasData = false;
            config.cols.forEach(col => {
                const colIndex = headers.findIndex(h => h === col.label || h === col.key);
                if (colIndex !== -1) {
                    const cell = row.getCell(colIndex);
                    let val = cell.text ? cell.text.toString().trim() : '';
                    if (val) {
                        if (col.type === 'multiselect') val = val.replace(/[\n,]+/g, ';').replace(/;+/g, ';');
                        newRow[col.key] = val;
                        hasData = true;
                    }
                }
            });
            if (hasData) mappedData.push(newRow);
        });

        if (mappedData.length > 0) {
            newData[config.key] = mappedData;
            importCount += mappedData.length;
            if (config.key === 'serverClusters') newData.showServerClusters = true;
            if (config.key === 'containerRegistry') newData.showContainerRegistry = true;
            if (config.key === 'databaseRegistry') newData.showDatabaseRegistry = true;
        }
    }

    return { data: newData, count: importCount };
};