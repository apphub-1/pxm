
import React, { useState, useEffect, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { 
  Plus, 
  Search, 
  Save, 
  X, 
  Database,
  RefreshCw,
  CheckCircle,
  Lock,
  AlertTriangle,
  Wifi,
  WifiOff,
  Settings,
  ChevronDown,
  Info,
  FileDown,
  LogIn,
  LogOut,
  History as HistoryIcon,
  Clock,
  ChevronRight,
  Download,
  Rocket,
  FileCog,
  Layers,
  KeyRound,
  ClipboardList,
  FileSpreadsheet,
  Moon,
  Sun,
  ShieldCheck
} from 'lucide-react';
import './index.css';
import '@fontsource/plus-jakarta-sans/400.css';
import '@fontsource/plus-jakarta-sans/500.css';
import '@fontsource/plus-jakarta-sans/600.css';
import '@fontsource/plus-jakarta-sans/700.css';
import '@fontsource/plus-jakarta-sans/800.css';
import '@fontsource/jetbrains-mono/400.css';

import { API_BASE_URL } from './config';
import { DEFAULT_HEADERS, SELECT_OPTIONS, FIELD_GROUPS, ONBOARDING_SECTIONS, TECHNICAL_SECTIONS, SECRETS_SECTIONS, SECRETS_ONBOARDING_SECTIONS } from './constants';
import { UserPicker } from './components/UserPicker';
import { MultiUserPicker } from './components/MultiUserPicker';
import { MultiSelectPicker } from './components/MultiSelectPicker';
import { PaginatedHistoryList } from './components/PaginatedHistoryList';
import { handleFullExcelExport, exportListToExcel } from './utils/excelExport';
import { OnboardingTab } from './tabs/OnboardingTab';
import { TechnicalTab } from './tabs/TechnicalTab';
import { SecretsTab } from './tabs/SecretsTab';
import { SecretsOnboardingTab } from './tabs/SecretsOnboardingTab';

type DataRow = Record<string, any>;

import { login, logout, getAccessToken, getUser, getRole } from './auth';

const UnifiedAppModal = ({ 
  isOpen, 
  onClose, 
  governanceRow, 
  user,
  initialTab = 'onboarding',
  mode = 'pam',
  readOnly = false
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  governanceRow: DataRow; 
  user: string | null;
  initialTab?: 'onboarding' | 'technical' | 'secrets' | 'secrets-onboarding';
  mode?: 'pam' | 'secrets';
  readOnly?: boolean;
}) => {
  const [activeTab, setActiveTab] = useState<'onboarding' | 'technical' | 'secrets' | 'secrets-onboarding'>(initialTab);

  // --- Onboarding State ---
  const [onboardingData, setOnboardingData] = useState<Record<string, any>>({});
  const [onboardingOpenSections, setOnboardingOpenSections] = useState<Record<string, boolean>>(
    ONBOARDING_SECTIONS.reduce((acc, s) => ({ ...acc, [s.id]: true }), {})
  );
  const [onboardingLoading, setOnboardingLoading] = useState(false);
  const [onboardingSaveStatus, setOnboardingSaveStatus] = useState<'idle' | 'saving' | 'success'>('idle');
  const [onboardingViewMode, setOnboardingViewMode] = useState<'form' | 'history'>('form');
  const [onboardingHistory, setOnboardingHistory] = useState<any[]>([]);
  const [onboardingLoaded, setOnboardingLoaded] = useState(false);

  // --- Technical State ---
  const [technicalData, setTechnicalData] = useState<Record<string, any[]>>({
    servers: [], databases: [], ports: [], safes: [], safeMembers: [], sharedAccounts: [], permissions: [], mapping: []
  });
  const [technicalOpenSections, setTechnicalOpenSections] = useState<Record<string, boolean>>(
    TECHNICAL_SECTIONS.reduce((acc, s) => ({ ...acc, [s.id]: true }), {})
  );
  const [technicalLoading, setTechnicalLoading] = useState(false);
  const [technicalSaveStatus, setTechnicalSaveStatus] = useState<'idle' | 'saving' | 'success'>('idle');
  const [technicalViewMode, setTechnicalViewMode] = useState<'form' | 'history'>('form');
  const [technicalHistory, setTechnicalHistory] = useState<any[]>([]);
  const [technicalLoaded, setTechnicalLoaded] = useState(false);

  // --- Secrets State ---
  const [secretsData, setSecretsData] = useState<Record<string, any[]>>({
    inventory: [], safes: [], members: [], mapping: []
  });
  const [secretsOpenSections, setSecretsOpenSections] = useState<Record<string, boolean>>(
    SECRETS_SECTIONS.reduce((acc, s) => ({ ...acc, [s.id]: true }), {})
  );
  const [secretsLoading, setSecretsLoading] = useState(false);
  const [secretsSaveStatus, setSecretsSaveStatus] = useState<'idle' | 'saving' | 'success'>('idle');
  const [secretsViewMode, setSecretsViewMode] = useState<'form' | 'history'>('form');
  const [secretsHistory, setSecretsHistory] = useState<any[]>([]);
  const [secretsLoaded, setSecretsLoaded] = useState(false);

  // --- Secrets Onboarding State ---
  const [secretsOnboardingData, setSecretsOnboardingData] = useState<Record<string, any>>({});
  const [secretsOnboardingOpenSections, setSecretsOnboardingOpenSections] = useState<Record<string, boolean>>(
    SECRETS_ONBOARDING_SECTIONS.reduce((acc, s) => ({ ...acc, [s.id]: true }), {})
  );
  const [secretsOnboardingLoading, setSecretsOnboardingLoading] = useState(false);
  const [secretsOnboardingSaveStatus, setSecretsOnboardingSaveStatus] = useState<'idle' | 'saving' | 'success'>('idle');
  const [secretsOnboardingViewMode, setSecretsOnboardingViewMode] = useState<'form' | 'history'>('form');
  const [secretsOnboardingHistory, setSecretsOnboardingHistory] = useState<any[]>([]);
  const [secretsOnboardingLoaded, setSecretsOnboardingLoaded] = useState(false);

  const [initialOnboardingData, setInitialOnboardingData] = useState<Record<string, any>>({});
  const [initialTechnicalData, setInitialTechnicalData] = useState<Record<string, any>>({});
  const [initialSecretsData, setInitialSecretsData] = useState<Record<string, any>>({});
  const [initialSecretsOnboardingData, setInitialSecretsOnboardingData] = useState<Record<string, any>>({});

  const [isUnsavedChangesDialogOpen, setIsUnsavedChangesDialogOpen] = useState(false);
  const saveLock = React.useRef(false);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  useEffect(() => {
    if (isOpen && governanceRow.id) {
        if (activeTab === 'onboarding' && !onboardingLoaded) {
            loadOnboardingData();
        } else if (activeTab === 'technical' && !technicalLoaded) {
            loadTechnicalData();
        } else if (activeTab === 'secrets') {
            if (!secretsLoaded) loadSecretsData();
            if (!secretsOnboardingLoaded) loadSecretsOnboardingData();
        } else if (activeTab === 'secrets-onboarding' && !secretsOnboardingLoaded) {
            loadSecretsOnboardingData();
        }
    }
  }, [activeTab, isOpen, governanceRow, onboardingLoaded, technicalLoaded, secretsLoaded, secretsOnboardingLoaded]);

  useEffect(() => {
    const { matrixLogin, matrixPwChange } = onboardingData;
    if (matrixLogin && matrixPwChange) {
      let variant = '';
      if (matrixLogin === 'Automatisch' && matrixPwChange === 'Automatisch') {
        variant = 'Anbindungsvariante 3';
      } else if (matrixLogin === 'Manuell' && matrixPwChange === 'Manuell') {
        variant = 'Anbindungsvariante 1';
      } else {
        variant = 'Anbindungsvariante 2';
      }
      
      if (onboardingData.selectedVariant !== variant) {
        setOnboardingData(prev => ({ ...prev, selectedVariant: variant }));
      }
    }
  }, [onboardingData.matrixLogin, onboardingData.matrixPwChange]);

  useEffect(() => {
    if (!technicalData.mapping) return;
    
    let hasChanges = false;
    const newMapping = technicalData.mapping.map(row => {
        const newRow = { ...row };
        let rowChanged = false;

        if (newRow.techAccount) {
            const account = technicalData.sharedAccounts?.find(a => a.techName === newRow.techAccount);
            if (account && newRow.bizAccount !== account.bizName) {
                newRow.bizAccount = account.bizName;
                rowChanged = true;
            }
        }

        if (newRow.techSafe) {
            const safe = technicalData.safes?.find(s => s.techSafeName === newRow.techSafe);
            if (safe && newRow.safeName !== safe.safeName) {
                newRow.safeName = safe.safeName;
                rowChanged = true;
            }
        }
        
        if (rowChanged) hasChanges = true;
        return newRow;
    });

    if (hasChanges) {
        setTechnicalData(prev => ({ ...prev, mapping: newMapping }));
    }
  }, [technicalData.mapping, technicalData.sharedAccounts, technicalData.safes]);

  const loadOnboardingData = async () => {
    setOnboardingLoading(true);
    try {
      const token = getAccessToken();
      const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
      const res = await fetch(`${API_BASE_URL}/onboarding/${governanceRow.id}`, { headers });
      if (res.ok) {
        const json = await res.json();
        // Pre-fill some data from governance row if empty
        let data = {};
        if (!json.data) {
            data = {};
        } else {
            data = JSON.parse(json.data) || {};
        }
        setOnboardingData(data);
        setInitialOnboardingData(data);
        setOnboardingLoaded(true);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setOnboardingLoading(false);
    }
  };

  const loadTechnicalData = async () => {
    setTechnicalLoading(true);
    try {
      const token = getAccessToken();
      const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
      const res = await fetch(`${API_BASE_URL}/technical/${governanceRow.id}`, { headers });
      if (res.ok) {
        const json = await res.json();
        let data = { servers: [], databases: [], ports: [], safes: [], safeMembers: [], sharedAccounts: [], permissions: [], mapping: [] };
        if (json.data) {
            data = JSON.parse(json.data) || data;
        }
        setTechnicalData(data);
        setInitialTechnicalData(data);
        setTechnicalLoaded(true);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setTechnicalLoading(false);
    }
  };

  const loadSecretsData = async () => {
    setSecretsLoading(true);
    try {
      const token = getAccessToken();
      const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
      const res = await fetch(`${API_BASE_URL}/secrets/${governanceRow.id}`, { headers });
      if (res.ok) {
        const json = await res.json();
        let data = { inventory: [], safes: [], members: [], mapping: [] };
        if (json.data) {
            data = JSON.parse(json.data) || data;
        }
        setSecretsData(data);
        setInitialSecretsData(data);
        setSecretsLoaded(true);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSecretsLoading(false);
    }
  };

  const loadSecretsOnboardingData = async () => {
    setSecretsOnboardingLoading(true);
    try {
      const token = getAccessToken();
      const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
      const res = await fetch(`${API_BASE_URL}/secrets-onboarding/${governanceRow.id}`, { headers });
      if (res.ok) {
        const json = await res.json();
        let data: any = {};
        if (json.data) {
            data = JSON.parse(json.data) || {};
            if (data.serverClusters?.length > 0) data.showServerClusters = true;
            if (data.containerRegistry?.length > 0) data.showContainerRegistry = true;
            if (data.databaseRegistry?.length > 0) data.showDatabaseRegistry = true;
        }
        setSecretsOnboardingData(data);
        setInitialSecretsOnboardingData(data);
        setSecretsOnboardingLoaded(true);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSecretsOnboardingLoading(false);
    }
  };

  const showNotification = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
      setNotification({ message, type });
      setTimeout(() => setNotification(null), 4000);
  };

  const handleOnboardingSave = async () => {
    if (saveLock.current) return;
    setOnboardingSaveStatus('saving');
    saveLock.current = true;
    try {
      const token = getAccessToken();
      const headers: HeadersInit = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;
      
      await fetch(`${API_BASE_URL}/onboarding/${governanceRow.id}`, {
        method: 'POST',
        headers,
        body: JSON.stringify(onboardingData)
      });
      setInitialOnboardingData(JSON.parse(JSON.stringify(onboardingData)));
      setOnboardingSaveStatus('success');
      setTimeout(() => setOnboardingSaveStatus('idle'), 2000);
    } catch (e) {
      alert("Fehler beim Speichern.");
      setOnboardingSaveStatus('idle');
    } finally {
      saveLock.current = false;
    }
  };

  const handleTechnicalSave = async () => {
    if (saveLock.current) return;
    setTechnicalSaveStatus('saving');
    saveLock.current = true;
    try {
      const token = getAccessToken();
      const headers: HeadersInit = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;
      
      await fetch(`${API_BASE_URL}/technical/${governanceRow.id}`, {
        method: 'POST',
        headers,
        body: JSON.stringify(technicalData)
      });
      setInitialTechnicalData(JSON.parse(JSON.stringify(technicalData)));
      setTechnicalSaveStatus('success');
      setTimeout(() => setTechnicalSaveStatus('idle'), 2000);
    } catch (e) {
      alert("Fehler beim Speichern.");
      setTechnicalSaveStatus('idle');
    } finally {
      saveLock.current = false;
    }
  };

  const handleSecretsSave = async () => {
    if (saveLock.current) return;
    setSecretsSaveStatus('saving');
    saveLock.current = true;
    try {
      const token = getAccessToken();
      const headers: HeadersInit = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;
      
      await fetch(`${API_BASE_URL}/secrets/${governanceRow.id}`, {
        method: 'POST',
        headers,
        body: JSON.stringify(secretsData)
      });
      setInitialSecretsData(JSON.parse(JSON.stringify(secretsData)));
      setSecretsSaveStatus('success');
      setTimeout(() => setSecretsSaveStatus('idle'), 2000);
    } catch (e) {
      alert("Fehler beim Speichern.");
      setSecretsSaveStatus('idle');
    } finally {
      saveLock.current = false;
    }
  };

  const handleSecretsOnboardingSave = async () => {
    if (saveLock.current) return;
    setSecretsOnboardingSaveStatus('saving');
    saveLock.current = true;
    try {
      const token = getAccessToken();
      const headers: HeadersInit = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;
      
      await fetch(`${API_BASE_URL}/secrets-onboarding/${governanceRow.id}`, {
        method: 'POST',
        headers,
        body: JSON.stringify(secretsOnboardingData)
      });
      setInitialSecretsOnboardingData(JSON.parse(JSON.stringify(secretsOnboardingData)));
      setSecretsOnboardingSaveStatus('success');
      setTimeout(() => setSecretsOnboardingSaveStatus('idle'), 2000);
    } catch (e) {
      alert("Fehler beim Speichern.");
      setSecretsOnboardingSaveStatus('idle');
    } finally {
      saveLock.current = false;
    }
  };

  const loadOnboardingHistory = async () => {
    try {
      const token = getAccessToken();
      const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
      const response = await fetch(`${API_BASE_URL}/history/${governanceRow.id}`, { headers });
      if (response.ok) {
        const allHistory = await response.json();
        setOnboardingHistory(allHistory.filter((h: any) => h.action.includes('ONBOARDING')));
      }
    } catch (e) {
      console.error("History load failed", e);
    }
  };

  const loadTechnicalHistory = async () => {
    try {
      const token = getAccessToken();
      const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
      const response = await fetch(`${API_BASE_URL}/history/${governanceRow.id}`, { headers });
      if (response.ok) {
        const allHistory = await response.json();
        setTechnicalHistory(allHistory.filter((h: any) => h.action.includes('TECHNICAL')));
      }
    } catch (e) {
      console.error("History load failed", e);
    }
  };

  const loadSecretsHistory = async () => {
    try {
      const token = getAccessToken();
      const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
      const response = await fetch(`${API_BASE_URL}/history/${governanceRow.id}`, { headers });
      if (response.ok) {
        const allHistory = await response.json();
        setSecretsHistory(allHistory.filter((h: any) => h.action.includes('SECRETS')));
      }
    } catch (e) {
      console.error("History load failed", e);
    }
  };

  const loadSecretsOnboardingHistory = async () => {
    try {
      const token = getAccessToken();
      const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
      const response = await fetch(`${API_BASE_URL}/history/${governanceRow.id}`, { headers });
      if (response.ok) {
        const allHistory = await response.json();
        setSecretsOnboardingHistory(allHistory.filter((h: any) => h.action.includes('SECRETS_ONB')));
      }
    } catch (e) {
      console.error("History load failed", e);
    }
  };

  const toggleOnboardingSection = (id: string) => {
    setOnboardingOpenSections(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleTechnicalSection = (id: string) => {
    setTechnicalOpenSections(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleSecretsSection = (id: string) => {
    setSecretsOpenSections(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleSecretsOnboardingSection = (id: string) => {
    setSecretsOnboardingOpenSections(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const exportJSON = () => {
      let dataToExport;
      let prefix;
      if (activeTab === 'onboarding') {
          dataToExport = onboardingData;
          prefix = 'Onboarding';
      } else if (activeTab === 'technical') {
          dataToExport = technicalData;
          prefix = 'Technical_Structure';
      } else if (activeTab === 'secrets') {
          dataToExport = secretsData;
          prefix = 'Secrets_Management';
      } else {
          dataToExport = secretsOnboardingData;
          prefix = 'Secrets_Onboarding';
      }

      const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${prefix}_${governanceRow.ICTO}.json`;
      a.click();
  };

  const handleClose = () => {
      const onboardingChanged = onboardingLoaded && JSON.stringify(onboardingData) !== JSON.stringify(initialOnboardingData);
      const technicalChanged = technicalLoaded && JSON.stringify(technicalData) !== JSON.stringify(initialTechnicalData);
      const secretsChanged = secretsLoaded && JSON.stringify(secretsData) !== JSON.stringify(initialSecretsData);
      const secretsOnboardingChanged = secretsOnboardingLoaded && JSON.stringify(secretsOnboardingData) !== JSON.stringify(initialSecretsOnboardingData);

      if (onboardingChanged || technicalChanged || secretsChanged || secretsOnboardingChanged) {
          setIsUnsavedChangesDialogOpen(true);
          return;
      }
      onClose();
  };

  const confirmClose = () => {
      setIsUnsavedChangesDialogOpen(false);
      onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 print:p-0 animate-in zoom-in-95 duration-200 dark:text-slate-200">
      {/* Notification Toast */}
      {notification && (
        <div className="absolute top-10 left-1/2 -translate-x-1/2 z-[100] animate-in slide-in-from-top-5 fade-in duration-300">
            <div className={`px-6 py-4 rounded-xl shadow-2xl border flex items-center gap-3 ${
                notification.type === 'error' ? 'bg-rose-50 border-rose-200 text-rose-700 dark:bg-rose-900/90 dark:border-rose-800 dark:text-rose-100' : 
                notification.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-900/90 dark:border-emerald-800 dark:text-emerald-100' : 
                'bg-slate-900 border-slate-800 text-white'
            }`}>
                {notification.type === 'error' ? <AlertTriangle className="w-5 h-5" /> : 
                 notification.type === 'success' ? <CheckCircle className="w-5 h-5" /> : 
                 <Info className="w-5 h-5" />}
                <span className="font-bold text-sm">{notification.message}</span>
                <button onClick={() => setNotification(null)} className="ml-2 opacity-70 hover:opacity-100"><X className="w-4 h-4" /></button>
            </div>
        </div>
      )}
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm print:hidden"></div>
      <div className={`relative bg-white dark:bg-slate-900 w-full h-[95vh] rounded-xl shadow-2xl flex flex-col overflow-hidden print:h-auto print:w-full print:max-w-none print:rounded-none print:shadow-none print:absolute print:inset-0 print:z-[100] ${activeTab === 'secrets' ? 'max-w-[98vw]' : 'max-w-[90rem]'}`}>
        
        {/* Header */}
        <div className="px-8 py-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-white dark:bg-slate-900 sticky top-0 z-10 print:hidden">
            <div>
                <h2 className="text-2xl font-black text-slate-900">
                   {activeTab === 'onboarding' ? 'PAM Onboarding' : activeTab === 'technical' ? 'Technische Struktur Produktion' : activeTab === 'secrets' ? 'Secrets Management Inventar' : 'Onboarding Secrets Management'}
                </h2>
                <p className="text-slate-500 font-mono text-sm mt-1">{governanceRow.Name} ({governanceRow.ICTO})</p>
            </div>
            
            {/* Tab Switcher */}
            <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg mx-4 print:hidden">
                {mode === 'pam' && (
                  <>
                    <button 
                      onClick={() => setActiveTab('onboarding')}
                      className={`px-6 py-2.5 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'onboarding' ? 'bg-white dark:bg-slate-700 text-rose-600 dark:text-rose-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
                    >
                      <Rocket className="w-4 h-4" /> Onboarding
                    </button>
                    <button 
                      onClick={() => setActiveTab('technical')}
                      className={`px-6 py-2.5 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'technical' ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
                    >
                      <Layers className="w-4 h-4" /> Technische Struktur
                    </button>
                  </>
                )}
                {mode === 'secrets' && (
                  <>
                    <button 
                      onClick={() => setActiveTab('secrets-onboarding')}
                      className={`px-6 py-2.5 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'secrets-onboarding' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
                    >
                      <ClipboardList className="w-4 h-4" /> Onboarding Secrets
                    </button>
                    <button 
                      onClick={() => setActiveTab('secrets')}
                      className={`px-6 py-2.5 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'secrets' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
                    >
                      <KeyRound className="w-4 h-4" /> Secrets Management Inventar
                    </button>
                  </>
                )}
            </div>

            <div className="flex items-center gap-3">
                <button 
                    onClick={() => {
                        if (activeTab === 'onboarding') {
                            if (onboardingViewMode === 'form') loadOnboardingHistory();
                            setOnboardingViewMode(v => v === 'form' ? 'history' : 'form');
                        } else if (activeTab === 'technical') {
                            if (technicalViewMode === 'form') loadTechnicalHistory();
                            setTechnicalViewMode(v => v === 'form' ? 'history' : 'form');
                        } else if (activeTab === 'secrets') {
                            if (secretsViewMode === 'form') loadSecretsHistory();
                            setSecretsViewMode(v => v === 'form' ? 'history' : 'form');
                        } else {
                            if (secretsOnboardingViewMode === 'form') loadSecretsOnboardingHistory();
                            setSecretsOnboardingViewMode(v => v === 'form' ? 'history' : 'form');
                        }
                    }}
                    className={`p-2 rounded-md transition-colors ${(activeTab === 'onboarding' ? onboardingViewMode : activeTab === 'technical' ? technicalViewMode : activeTab === 'secrets' ? secretsViewMode : secretsOnboardingViewMode) === 'history' ? 'bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400' : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400'}`}
                    title="Änderungshistorie"
                >
                    <HistoryIcon className="w-5 h-5" />
                </button>
                <button onClick={exportJSON} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md text-slate-500 dark:text-slate-400" title="JSON Export"><Download className="w-5 h-5" /></button>
                <button onClick={handleClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md text-slate-500 dark:text-slate-400"><X className="w-6 h-6" /></button>
            </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-8 bg-slate-50/50 dark:bg-slate-950/50 custom-scrollbar print:overflow-visible print:bg-white">
            {activeTab === 'onboarding' ? (
                onboardingLoading ? <div className="flex justify-center p-10"><RefreshCw className="animate-spin w-8 h-8 text-indigo-500" /></div> : (
                onboardingViewMode === 'history' ? (
                    <div className="max-w-4xl mx-auto">
                        <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-slate-800 dark:text-slate-200">
                          <Clock className="w-6 h-6 text-indigo-500" /> Änderungsprotokoll
                        </h3>
                        <PaginatedHistoryList history={onboardingHistory} />
                    </div>
                ) : (
                <OnboardingTab 
                    data={onboardingData} 
                    setData={setOnboardingData} 
                    openSections={onboardingOpenSections} 
                    toggleSection={toggleOnboardingSection} 
                    readOnly={readOnly} 
                    governanceRow={governanceRow}
                />
                )
            )) : activeTab === 'technical' ? (
                technicalLoading ? <div className="flex justify-center p-10"><RefreshCw className="animate-spin w-8 h-8 text-emerald-500" /></div> : (
                technicalViewMode === 'history' ? (
                    <div className="max-w-[85rem] mx-auto">
                        <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-slate-800 dark:text-slate-200">
                          <Clock className="w-6 h-6 text-indigo-500" /> Änderungsprotokoll
                        </h3>
                        <PaginatedHistoryList history={technicalHistory} />
                    </div>
                ) : (
                <TechnicalTab 
                    data={technicalData} 
                    setData={setTechnicalData} 
                    openSections={technicalOpenSections} 
                    toggleSection={toggleTechnicalSection} 
                    readOnly={readOnly} 
                />
                )
            )) : activeTab === 'secrets' ? (
                (secretsLoading || secretsOnboardingLoading) ? <div className="flex justify-center p-10"><RefreshCw className="animate-spin w-8 h-8 text-indigo-500" /></div> : (
                secretsViewMode === 'history' ? (
                    <div className="max-w-[85rem] mx-auto">
                        <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-slate-800">
                          <Clock className="w-6 h-6 text-indigo-500" /> Änderungsprotokoll
                        </h3>
                        <PaginatedHistoryList history={secretsHistory} />
                    </div>
                ) : (
                <SecretsTab 
                    data={secretsData} 
                    setData={setSecretsData} 
                    secretsOnboardingData={secretsOnboardingData} 
                    openSections={secretsOpenSections} 
                    toggleSection={toggleSecretsSection} 
                    readOnly={readOnly} 
                    governanceRow={governanceRow}
                />
                )
            )) : (
                secretsOnboardingLoading ? <div className="flex justify-center p-10"><RefreshCw className="animate-spin w-8 h-8 text-indigo-500" /></div> : (
                secretsOnboardingViewMode === 'history' ? (
                    <div className="max-w-[85rem] mx-auto">
                        <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-slate-800">
                          <Clock className="w-6 h-6 text-indigo-500" /> Änderungsprotokoll
                        </h3>
                        <PaginatedHistoryList history={secretsOnboardingHistory} />
                    </div>
                ) : (
                <SecretsOnboardingTab 
                    data={secretsOnboardingData} 
                    setData={setSecretsOnboardingData} 
                    openSections={secretsOnboardingOpenSections} 
                    toggleSection={toggleSecretsOnboardingSection} 
                    readOnly={readOnly} 
                    governanceRow={governanceRow}
                />
                )
            ))}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 flex justify-end gap-4 print:hidden">
            <button onClick={handleClose} className="px-6 py-3 font-bold text-slate-500 hover:bg-slate-50 rounded-lg transition-colors">Schließen</button>
            {!readOnly && (
            <button 
                onClick={activeTab === 'onboarding' ? handleOnboardingSave : activeTab === 'technical' ? handleTechnicalSave : activeTab === 'secrets' ? handleSecretsSave : handleSecretsOnboardingSave} 
                disabled={(activeTab === 'onboarding' ? onboardingSaveStatus : activeTab === 'technical' ? technicalSaveStatus : activeTab === 'secrets' ? secretsSaveStatus : secretsOnboardingSaveStatus) === 'saving'} 
                className={`px-8 py-3 font-bold rounded-lg shadow-lg transition-all active:scale-95 flex items-center gap-2 ${
                    (activeTab === 'onboarding' ? onboardingSaveStatus : activeTab === 'technical' ? technicalSaveStatus : activeTab === 'secrets' ? secretsSaveStatus : secretsOnboardingSaveStatus) === 'success' 
                    ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-200' 
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-200'
                }`}
            >
                {(activeTab === 'onboarding' ? onboardingSaveStatus : activeTab === 'technical' ? technicalSaveStatus : activeTab === 'secrets' ? secretsSaveStatus : secretsOnboardingSaveStatus) === 'saving' ? <RefreshCw className="animate-spin w-5 h-5" /> : 
                 (activeTab === 'onboarding' ? onboardingSaveStatus : activeTab === 'technical' ? technicalSaveStatus : activeTab === 'secrets' ? secretsSaveStatus : secretsOnboardingSaveStatus) === 'success' ? <CheckCircle className="w-5 h-5" /> : 
                 <Save className="w-5 h-5" />} 
                {(activeTab === 'onboarding' ? onboardingSaveStatus : activeTab === 'technical' ? technicalSaveStatus : activeTab === 'secrets' ? secretsSaveStatus : secretsOnboardingSaveStatus) === 'success' ? 'Gespeichert' : 'Speichern'}
            </button>
            )}
        </div>

        {isUnsavedChangesDialogOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-10">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"></div>
          <div className="relative bg-white dark:bg-slate-900 w-full max-w-md rounded-xl shadow-2xl p-6 border border-slate-100 dark:border-slate-800 animate-in zoom-in-95 duration-200">
            <div className="flex flex-col items-center text-center gap-4">
                <div className="p-4 bg-amber-50 dark:bg-amber-900/20 rounded-full">
                    <AlertTriangle className="w-10 h-10 text-amber-500" />
                </div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white">Ungespeicherte Änderungen</h3>
                <p className="text-slate-500 dark:text-slate-400 font-medium leading-relaxed text-sm">
                    Es gibt ungespeicherte Änderungen. Möchten Sie das Fenster wirklich schließen? Alle nicht gespeicherten Daten gehen verloren.
                </p>
                <div className="grid grid-cols-2 gap-4 w-full mt-4">
                    <button 
                        onClick={() => setIsUnsavedChangesDialogOpen(false)}
                        className="py-3 px-4 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 font-bold rounded-lg transition-colors"
                    >
                        Abbrechen
                    </button>
                    <button 
                        onClick={confirmClose}
                        className="py-3 px-4 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg shadow-lg shadow-rose-100 dark:shadow-none transition-all active:scale-[0.98]"
                    >
                        Schließen
                    </button>
                </div>
            </div>
          </div>
        </div>
      )}

      </div>

   
    </div>
  );
};

const App = () => {
  const [data, setData] = useState<DataRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [connectionState, setConnectionState] = useState<'online' | 'api_only' | 'offline'>('offline');
  const [lastError, setLastError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [editingRow, setEditingRow] = useState<DataRow | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success' | 'error'>('idle');
  const [user, setUser] = useState<string | null>(getUser());
  const [role, setRole] = useState<string | null>(getRole());
  const [loginCreds, setLoginCreds] = useState({ username: '', password: '' });
  const [history, setHistory] = useState<any[]>([]);
  const [viewMode, setViewMode] = useState<'form' | 'history'>('form');
  const [unifiedRow, setUnifiedRow] = useState<DataRow | null>(null);
  const [initialTab, setInitialTab] = useState<'onboarding' | 'technical' | 'secrets' | 'secrets-onboarding'>('onboarding');
  const [modalMode, setModalMode] = useState<'pam' | 'secrets'>('pam');
  const [onboardingVariant, setOnboardingVariant] = useState<string>('');
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [isAcceptanceConfirmOpen, setIsAcceptanceConfirmOpen] = useState(false);
  const [acceptanceType, setAcceptanceType] = useState<'pam' | 'secrets' | null>(null);
  const [isTableExpanded, setIsTableExpanded] = useState(false);
  const saveLock = React.useRef(false);
  const [openDomains, setOpenDomains] = useState<Record<string, boolean>>({ pam: false, secrets: false });
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showNotification = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
      setNotification({ message, type });
      setTimeout(() => setNotification(null), 4000);
  };

  const toggleDomain = (domain: string) => setOpenDomains(prev => ({ ...prev, [domain]: !prev[domain] }));
  // Initialisierung: Standard ist false (Light Mode), es sei denn 'true' steht im Storage
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
        return localStorage.getItem('pxm_dark_mode') === 'true';
    }
    return false;
  });

  const [secretsSummary, setSecretsSummary] = useState<any>(null);
  const [secretsSummaryLoading, setSecretsSummaryLoading] = useState(false);
  const isReadOnly = role === 'readonly';

  useEffect(() => { 
    checkConnectivity(); 
  }, []);

  useEffect(() => {
    if (isModalOpen && editingRow?.id) {
        const fetchVariant = async () => {
            try {
                const token = getAccessToken();
                const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
                const res = await fetch(`${API_BASE_URL}/onboarding/${editingRow.id}`, { headers });
                if (res.ok) {
                    const json = await res.json();
                    if (json.data) {
                        const d = JSON.parse(json.data);
                        setOnboardingVariant(d.selectedVariant || '');
                    } else {
                        setOnboardingVariant('');
                    }
                }
            } catch (e) {
                console.error(e);
                setOnboardingVariant('');
            }
        };
        fetchVariant();
    } else {
        setOnboardingVariant('');
    }
  }, [isModalOpen, editingRow?.id]);

  // Load secrets summary when section opens
  useEffect(() => {
      if (openDomains.secrets && editingRow?.id && !secretsSummary) {
          loadSecretsSummary();
      }
  }, [openDomains.secrets, editingRow]);

  const loadSecretsSummary = async () => {
      setSecretsSummaryLoading(true);
      try {
          const token = getAccessToken();
          const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
          const res = await fetch(`${API_BASE_URL}/secrets-onboarding/${editingRow?.id}`, { headers });
          if (res.ok) {
              const json = await res.json();
              if (json.data) {
                  setSecretsSummary(JSON.parse(json.data));
              } else {
                  setSecretsSummary({});
              }
          }
      } catch (e) {
          console.error(e);
      } finally {
          setSecretsSummaryLoading(false);
      }
  };

  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('pxm_dark_mode', String(darkMode));
  }, [darkMode]);

  const checkConnectivity = async () => {
    setLoading(true);
    setLastError(null);
    try {
      const token = getAccessToken();
      const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};

      const healthResp = await fetch(`${API_BASE_URL}/health`);
      if (!healthResp.ok) throw new Error("API unreachable");
      const health = await healthResp.json();
      
      if (health.database === 'connected') {
        setConnectionState('online');
        const dataResp = await fetch(`${API_BASE_URL}/data`, { headers });
        
        if (dataResp.status === 401 || dataResp.status === 403) {
           if (user) handleLogout(); // Token expired
           return;
        }

        const result = await dataResp.json();
        if (Array.isArray(result)) {
          setData(result);
        } else {
          setData([]);
        }
      } else {
        setConnectionState('api_only');
        setLastError(health.message || 'Datenbank-Verbindung fehlgeschlagen.');
      }
    } catch (err: any) {
      setConnectionState('offline');
      setLastError(err.message || 'Server.js nicht erreichbar.');
    } finally {
      setLoading(false);
    }
  };

  const visibleHeaders = useMemo(() => {
    if (isTableExpanded) return DEFAULT_HEADERS;
    const cutoffIndex = DEFAULT_HEADERS.indexOf("Kritikalität");
    return DEFAULT_HEADERS.slice(0, cutoffIndex + 1);
  }, [isTableExpanded]);

  const filteredData = useMemo(() => {
    return data.filter(row => {
      // Global search
      if (search && !JSON.stringify(row).toLowerCase().includes(search.toLowerCase())) {
        return false;
      }
      // Column filters
      for (const h of DEFAULT_HEADERS) {
        const filterVal = filters[h]?.toLowerCase();
        if (filterVal) {
          const cellVal = String(row[h] || '').toLowerCase();
          if (!cellVal.includes(filterVal)) return false;
        }
      }
      return true;
    });
  }, [data, search, filters]);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { user, role } = await login(loginCreds.username, loginCreds.password);
      setUser(user);
      setRole(role);
      checkConnectivity();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleLogout = () => {
    logout();
    setUser(null);
    setRole(null);
    setData([]);
    setConnectionState('api_only'); // Reset state visually
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (saveLock.current) return;
    if (!editingRow) return;
    saveLock.current = true;
    setSaveStatus('saving');
    try {
      const isUpdate = editingRow.id && !String(editingRow.id).startsWith('temp_');
      const method = isUpdate ? 'PUT' : 'POST';
      const url = isUpdate ? `${API_BASE_URL}/data/${editingRow.id}` : `${API_BASE_URL}/data`;
      
      const payload = { ...editingRow };
      if (!isUpdate) delete payload.id;

      const token = getAccessToken();
      const headers: HeadersInit = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const response = await fetch(url, {
        method,
        headers,
        body: JSON.stringify(payload),
      });
      
      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || 'Speichern fehlgeschlagen');
      }
      
      setSaveStatus('success');
      checkConnectivity();
      setTimeout(() => { 
        if (!isUpdate) {
            setIsModalOpen(false);
        }
        setSaveStatus('idle'); 
        saveLock.current = false;
      }, 2000);
    } catch (err: any) {
      setSaveStatus('error');
      setLastError(err.message);
      showNotification("Fehler beim Speichern: " + err.message, 'error');
      saveLock.current = false;
    }
  };

  const handleAcceptance = (type: 'pam' | 'secrets') => {
    if (!editingRow?.id) return;
    
    const statusField = type === 'pam' ? 'StatusPAMOnboarding' : 'StatusSecretsOnboarding';
    const status = editingRow?.[statusField];

    if (!status) {
        showNotification("Bitte wählen Sie zuerst einen Status aus.", 'error');
        return;
    }

    if (["Anbindung läuft", "Anbindung zurückgestellt", "Anbindung nicht erforderlich"].includes(status)) {
        showNotification(`Eine Abnahme ist im Status "${status}" nicht möglich.`, 'error');
        return;
    }

    setAcceptanceType(type);
    setIsAcceptanceConfirmOpen(true);
  };

  const confirmAcceptance = async () => {
    if (!acceptanceType) return;
    setIsAcceptanceConfirmOpen(false);
    const timestamp = new Date().toLocaleString('de-DE');
    const acceptanceString = `${user} am ${timestamp}`;
    
    const field = acceptanceType === 'pam' ? 'AbnahmePAMOnboarding' : 'AbnahmeSecretsOnboarding';
    const updatedRow = { ...editingRow, [field]: acceptanceString };
    
    setEditingRow(updatedRow);

    try {
        const token = getAccessToken();
        const headers: HeadersInit = { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = `Bearer ${token}`;
        
        const url = `${API_BASE_URL}/data/${updatedRow.id}`;
        const response = await fetch(url, {
            method: 'PUT',
            headers,
            body: JSON.stringify(updatedRow),
        });

        if (!response.ok) throw new Error("Speichern fehlgeschlagen");
        checkConnectivity();
    } catch (e: any) {
        showNotification("Fehler: " + e.message, 'error');
    }
  };

  const handleRevokeAcceptance = async (type: 'pam' | 'secrets') => {
    if (!editingRow?.id) return;
    if (!window.confirm("Soll die Abnahme wirklich zurückgezogen werden?")) return;

    const field = type === 'pam' ? 'AbnahmePAMOnboarding' : 'AbnahmeSecretsOnboarding';
    const updatedRow = { ...editingRow, [field]: '' };
    
    setEditingRow(updatedRow);

    try {
        const token = getAccessToken();
        const headers: HeadersInit = { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = `Bearer ${token}`;
        
        const url = `${API_BASE_URL}/data/${updatedRow.id}`;
        const response = await fetch(url, {
            method: 'PUT',
            headers,
            body: JSON.stringify(updatedRow),
        });

        if (!response.ok) throw new Error("Speichern fehlgeschlagen");
        checkConnectivity();
    } catch (e: any) {
        showNotification("Fehler: " + e.message, 'error');
    }
  };

  const handleFetchHistory = async (id: any) => {
    if (!id) return;
    try {
      const token = getAccessToken();
      const headers: HeadersInit = token ? { 'Authorization': `Bearer ${token}` } : {};
      const response = await fetch(`${API_BASE_URL}/history/${id}`, { headers });
      if (response.ok) {
        const histData = await response.json();
        setHistory(histData);
        setViewMode('history');
      }
    } catch (err) {
      showNotification("Fehler beim Laden der Historie", 'error');
    }
  };

  const renderField = (fieldName: string) => {
    const options = SELECT_OPTIONS[fieldName];
    const isTechnical = ["ICTO", "id", "tAV"].includes(fieldName);

    // AD User Picker für Personenfelder verwenden
    if (["tAV", "Stellvertreter tAV", "fAV", "Betriebsverantwortlicher"].includes(fieldName)) {
      return (
        <UserPicker 
          key={fieldName}
          label={fieldName}
          value={editingRow?.[fieldName] || ''}
          onChange={(val: string) => setEditingRow({...editingRow, [fieldName]: val})}
          readOnly={isReadOnly}
          className="space-y-1.5"
        />
      );
    }

    if (fieldName === "Objektpflege") {
        return (
            <MultiUserPicker
                key={fieldName}
                label={fieldName}
                value={editingRow?.[fieldName] || ''}
                onChange={(val: string) => setEditingRow({...editingRow, [fieldName]: val})}
                readOnly={isReadOnly}
                className="space-y-1.5"
            />
        );
    }
    
    // Special handling for Anbindungsvariante
    if (fieldName === "Anbindungsvariante") {
        return (
            <div key={fieldName} className="space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">
                  {fieldName}
                </label>
                <div className="relative">
                    <input 
                        type="text" 
                        className="w-full p-3.5 bg-slate-100 border border-slate-200 rounded-xl text-slate-500 font-semibold text-sm outline-none cursor-not-allowed"
                        value={onboardingVariant || 'Nicht definiert'}
                        disabled
                        readOnly
                    />
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
                        <Lock className="w-4 h-4" />
                    </div>
                </div>
                <p className="text-[10px] text-slate-400 ml-1 flex items-center gap-1">
                    <Info className="w-3 h-3" />
                    Wird aus PAM Onboarding ermittelt
                </p>
            </div>
        );
    }

    if (fieldName === "KommentarPAM") {
        return (
            <div key={fieldName} className="space-y-1.5 col-span-1 md:col-span-2">
                <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">
                    Kommentar
                </label>
                <textarea 
                    rows={3}
                    className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all outline-none font-semibold text-sm resize-none dark:text-slate-200"
                    value={editingRow?.[fieldName] || ''}
                    onChange={(e) => setEditingRow({...editingRow, [fieldName]: e.target.value})}
                    disabled={isReadOnly}
                    placeholder="Optionale Anmerkungen..."
                />
            </div>
        );
    }

    return (
      <div key={fieldName} className="space-y-1.5">
        <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">
          {fieldName}
        </label>
        {options ? (
          <div className="relative group">
            <select 
              className={`w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all outline-none font-semibold text-sm appearance-none cursor-pointer dark:text-slate-200 ${isTechnical ? 'font-mono' : ''}`}
              value={editingRow?.[fieldName] || ''}
              onChange={(e) => setEditingRow({...editingRow, [fieldName]: e.target.value})}
              disabled={isReadOnly}
            >
              <option value="">Wählen...</option>
              {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
            <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          </div>
        ) : (
          <textarea 
            rows={1}
            className={`w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all outline-none font-semibold text-sm resize-none dark:text-slate-200 ${isTechnical ? 'font-mono' : ''}`}
            value={editingRow?.[fieldName] || ''}
            onChange={(e) => setEditingRow({...editingRow, [fieldName]: e.target.value})}
            disabled={isReadOnly}
            onInput={(e: any) => {
              e.target.style.height = 'auto';
              e.target.style.height = e.target.scrollHeight + 'px';
            }}
            maxLength={500}
          />
        )}
      </div>
    );
  };

  if (!user) {
    return (
        <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4">
          <div className="bg-slate-50 dark:bg-slate-900 w-full max-w-md rounded-xl shadow-2xl p-10 animate-in zoom-in-95 duration-300 border border-slate-200 dark:border-slate-800">
            <div className="flex justify-center mb-8">
                <div className="bg-indigo-600 p-5 rounded-lg shadow-xl shadow-indigo-200">
                    <Database className="w-10 h-10 text-white" />
                </div>
            </div>
            <h2 className="text-3xl font-black mb-2 text-slate-900 text-center tracking-tight">PXM Manager</h2>
            <p className="text-slate-400 text-center mb-10 font-medium">Bitte melden Sie sich an, um fortzufahren.</p>
            <form onSubmit={handleLoginSubmit} className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 ml-1">Benutzername</label>
                <input 
                  autoFocus
                  className="w-full p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 outline-none font-bold text-slate-700 dark:text-slate-200 transition-all"
                  value={loginCreds.username}
                  onChange={e => setLoginCreds({...loginCreds, username: e.target.value})}
                  placeholder="Benutzername"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 ml-1">Passwort</label>
                <input 
                  type="password"
                  className="w-full p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 outline-none font-bold text-slate-700 dark:text-slate-200 transition-all"
                  value={loginCreds.password}
                  onChange={e => setLoginCreds({...loginCreds, password: e.target.value})}
                  placeholder="••••••••"
                />
              </div>
              <button type="submit" className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold shadow-xl shadow-indigo-200 transition-all mt-6 active:scale-[0.98] flex justify-center items-center gap-2">
                <LogIn className="w-5 h-5" /> Anmelden
              </button>
            </form>
          </div>
        </div>
    );
  }

  return (
    <div className="h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 selection:bg-indigo-100 selection:text-indigo-900 flex flex-col overflow-hidden">
      <header className="bg-slate-50/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-8 py-5 flex justify-between items-center shadow-sm shrink-0 z-40">
        <div className="flex items-center gap-5">
          <div className={`p-2.5 rounded-lg text-white transition-all duration-700 shadow-lg ${
            connectionState === 'online' ? 'bg-indigo-600 shadow-indigo-200' : 
            connectionState === 'api_only' ? 'bg-amber-500 shadow-amber-200' : 'bg-rose-500 shadow-rose-200'
          }`}>
            <Database className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-[-0.03em] leading-none mb-1 text-slate-900 dark:text-white">PXM Manager</h1>
            <div className="flex items-center gap-2">
               <span className="text-[10px] font-extrabold uppercase tracking-[0.15em] flex items-center gap-1.5">
                 {connectionState === 'online' ? (
                   <span className="text-emerald-500 flex items-center gap-1"><Wifi className="w-3.5 h-3.5" /> SQL ONLINE</span>
                 ) : connectionState === 'api_only' ? (
                   <span className="text-amber-500 flex items-center gap-1"><AlertTriangle className="w-3.5 h-3.5" /> DB KONFIG</span>
                 ) : (
                   <span className="text-rose-500 flex items-center gap-1"><WifiOff className="w-3.5 h-3.5" /> OFFLINE</span>
                 )}
               </span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <button onClick={() => setDarkMode(!darkMode)} className="p-3 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all active:scale-95 group" title={darkMode ? "Light Mode" : "Dark Mode"}>
              {darkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-slate-400 group-hover:text-slate-600" />}
          </button>

          <button onClick={handleLogout} className="px-5 py-2 rounded-lg font-bold flex items-center gap-3 bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:bg-rose-50 dark:hover:bg-rose-900/30 hover:text-rose-600 dark:hover:text-rose-400 hover:border-rose-100 dark:hover:border-rose-800 transition-all">
            <div className="flex flex-col items-end">
                <span className="text-[10px] font-black uppercase tracking-wider text-indigo-500">{role === 'admin' ? 'Admin' : role === 'maintenance' ? 'Pflege' : 'Read Only'}</span>
                <span className="text-sm leading-none">{user}</span>
            </div>
            <div className="h-8 w-px bg-slate-200 mx-1"></div>
            <LogOut className="w-4 h-4" />
          </button>

          <button onClick={checkConnectivity} className="p-3 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all active:scale-95 group" title="Aktualisieren">
            <RefreshCw className={`w-5 h-5 text-slate-400 group-hover:text-slate-600 ${loading ? 'animate-spin' : ''}`} />
          </button>
          
          <button 
            onClick={() => exportListToExcel(filteredData)}
            disabled={data.length === 0}
            className="px-5 py-3 rounded-lg font-extrabold flex items-center gap-2.5 border-2 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
          >
            <FileDown className="w-5 h-5" /> Export
          </button>

          {!isReadOnly && role === 'admin' && (
          <button 
            disabled={connectionState !== 'online'}
            onClick={() => { setEditingRow({}); setIsModalOpen(true); setViewMode('form'); }}
            className={`px-6 py-3 rounded-lg font-extrabold flex items-center gap-2.5 shadow-xl transition-all active:scale-[0.98] ${
              connectionState === 'online' 
                ? 'bg-slate-900 hover:bg-black text-white' 
                : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 cursor-not-allowed shadow-none'
            }`}
          >
            <Plus className="w-5 h-5 stroke-[3px]" /> Neu
          </button>
          )}
        </div>
      </header>

      <main className="p-10 flex-1 overflow-hidden flex flex-col">
        {connectionState === 'api_only' && (
          <div className="mb-10 bg-amber-50 border border-amber-100 p-6 rounded-xl flex gap-5 items-start max-w-4xl mx-auto shadow-sm">
            <div className="bg-amber-500 p-2.5 rounded-lg text-white shrink-0 shadow-lg shadow-amber-100"><Settings className="w-5 h-5" /></div>
            <div>
              <h3 className="font-extrabold text-amber-900 mb-1 tracking-tight">SQL Server Verbindung unvollständig</h3>
              <p className="text-sm text-amber-800/80 mb-2 leading-relaxed font-medium">{lastError}</p>
            </div>
          </div>
        )}

        {connectionState === 'offline' ? (
          <div className="bg-slate-50 p-16 rounded-xl shadow-2xl border border-slate-200 text-center max-w-2xl mx-auto mt-20">
            <div className="bg-rose-50 w-24 h-24 rounded-xl flex items-center justify-center mx-auto mb-8 text-rose-500 shadow-inner">
              <WifiOff className="w-12 h-12" />
            </div>
            <h2 className="text-3xl font-black mb-4 tracking-tight">Backend nicht erreichbar</h2>
            <p className="text-slate-500 font-medium mb-10">Der Node.js Server wurde unter Port 3001 nicht gefunden.</p>
            <button onClick={checkConnectivity} className="bg-indigo-600 text-white px-10 py-4 rounded-lg font-black hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 active:scale-95">Verbindung prüfen</button>
          </div>
        ) : (
          <div className="flex flex-col h-full gap-8">
            <div className="relative max-w-lg group shrink-0">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 w-5 h-5 group-focus-within:text-indigo-500 transition-colors stroke-[2.5px]" />
              <input 
                type="text" 
                placeholder="Katalog durchsuchen..." 
                className="w-full pl-14 pr-6 py-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-[6px] focus:ring-indigo-50 focus:border-indigo-500 outline-none transition-all shadow-sm font-semibold placeholder:text-slate-300 dark:placeholder:text-slate-500 dark:text-slate-200"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <div className="bg-slate-50 dark:bg-slate-900 rounded-xl shadow-2xl shadow-slate-200/50 dark:shadow-none border border-slate-200 dark:border-slate-800 overflow-hidden flex-1 flex flex-col">
              <div className="overflow-auto custom-scrollbar flex-1">
                <table className={`w-full border-collapse ${isTableExpanded ? 'min-w-[2200px]' : 'min-w-full'}`}>
                  <thead>
                    <tr className="bg-slate-50/40 dark:bg-slate-800/40 border-b border-slate-100 dark:border-slate-800">
                      <th className="sticky left-0 top-0 bg-slate-50 dark:bg-slate-900 z-30 px-4 py-4 text-center w-[80px] min-w-[80px] text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] shadow-[0_1px_0_#f1f5f9] dark:shadow-[0_1px_0_#1e293b] align-top">
                        <div className="mb-3">Status</div>
                      </th>
                      <th className="sticky left-[80px] top-0 bg-slate-50 dark:bg-slate-900 z-30 px-4 py-4 text-center w-[140px] min-w-[140px] text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] shadow-[0_1px_0_#f1f5f9] dark:shadow-[0_1px_0_#1e293b] align-top">
                        <div className="mb-3">PAM Onboarding</div>
                      </th>
                      {visibleHeaders.map(h => {
                        let stickyClass = "sticky top-0 bg-slate-50 dark:bg-slate-900 z-20";
                        if (h === "ICTO") stickyClass = "sticky left-[218px] top-0 bg-slate-50 dark:bg-slate-900 z-30 w-[120px] min-w-[120px] border-l border-slate-200 dark:border-slate-800";
                        if (h === "Name") stickyClass = "sticky left-[337px] top-0 bg-slate-50 dark:bg-slate-900 z-30 w-[250px] min-w-[250px] border-r border-slate-200 dark:border-slate-800 shadow-[6px_0_12px_-6px_rgba(0,0,0,0.04),0_1px_0_#f1f5f9] dark:shadow-[6px_0_12px_-6px_rgba(0,0,0,0.04),0_1px_0_#1e293b]";
                        
                        return (
                        <th key={h} className={`${stickyClass} text-left px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] whitespace-nowrap shadow-[0_1px_0_#f1f5f9] dark:shadow-[0_1px_0_#1e293b] align-top`}>
                          <div className="mb-3 block">{h}</div>
                          <input 
                            type="text" 
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md text-xs font-medium text-slate-600 dark:text-slate-300 focus:ring-2 focus:ring-indigo-500 outline-none normal-case tracking-normal placeholder:text-slate-300 dark:placeholder:text-slate-500"
                            placeholder={`Filter ${h}...`}
                            value={filters[h] || ''}
                            onChange={e => setFilters(prev => ({...prev, [h]: e.target.value}))}
                          />
                        </th>
                      )})}
                      <th className="sticky top-0 bg-slate-50 dark:bg-slate-900 z-20 px-2 py-4 text-center shadow-[0_1px_0_#f1f5f9] dark:shadow-[0_1px_0_#1e293b] align-top w-12">
                        <button 
                            onClick={() => setIsTableExpanded(!isTableExpanded)}
                            className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-indigo-600 transition-colors mt-1"
                            title={isTableExpanded ? "Spalten einklappen" : "Spalten ausklappen"}
                        >
                            <ChevronRight className={`w-5 h-5 transition-transform ${isTableExpanded ? 'rotate-180' : ''}`} />
                        </button>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {filteredData.length === 0 ? (
                      <tr>
                        <td colSpan={visibleHeaders.length + 3} className="py-24 text-center">
                          <div className="flex flex-col items-center gap-3">
                            {loading ? (
                              <RefreshCw className="w-10 h-10 text-indigo-200 animate-spin" />
                            ) : (
                              <Database className="w-12 h-12 text-slate-100" />
                            )}
                            <p className="text-slate-400 font-extrabold tracking-tight">
                              {loading ? 'DATEN WERDEN GELADEN...' : (data.length === 0 ? 'KEINE DATEN VORHANDEN' : 'KEINE TREFFER FÜR DIESEN FILTER')}
                            </p>
                          </div>
                        </td>
                      </tr>
                    ) : filteredData.map((row, i) => (
                      <tr key={row.id || i} className="hover:bg-indigo-50/30 dark:hover:bg-indigo-900/20 transition-colors group">
                        <td className="sticky left-0 bg-slate-50 dark:bg-slate-900 group-hover:bg-indigo-50/50 dark:group-hover:bg-indigo-900/50 z-10 px-4 py-4 text-center w-[80px] min-w-[80px] whitespace-nowrap">
                          <button 
                            onClick={() => { setEditingRow(row); setIsModalOpen(true); setViewMode('form'); }} 
                            className="p-2.5 text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-md transition-all shadow-sm hover:shadow-md active:scale-90"
                            title="Schnittstelleninformationen"
                          >
                            <FileCog className="w-5 h-5" />
                          </button>
                        </td>
                        <td className="sticky left-[80px] bg-slate-50 dark:bg-slate-900 group-hover:bg-indigo-50/50 dark:group-hover:bg-indigo-900/50 z-10 px-4 py-4 text-center w-[140px] min-w-[140px] whitespace-nowrap">
                          <button 
                            onClick={() => { setUnifiedRow(row); setInitialTab('onboarding'); setModalMode('pam'); }} 
                            className="p-2.5 text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-md transition-all shadow-sm hover:shadow-md active:scale-90"
                            title="Status Onboarding"
                          >
                            <Rocket className="w-5 h-5" />
                          </button>
                          <button 
                            onClick={() => { setUnifiedRow(row); setInitialTab('secrets-onboarding'); setModalMode('secrets'); }} 
                            className="p-2.5 ml-2 text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-md transition-all shadow-sm hover:shadow-md active:scale-90"
                            title="Secrets Management"
                          >
                            <KeyRound className="w-5 h-5" />
                          </button>
                        </td>
                        {visibleHeaders.map(h => {
                          const isTech = ["ICTO", "tAV"].includes(h);
                          let stickyClass = "";
                          if (h === "ICTO") stickyClass = "sticky left-[218px] bg-slate-50 dark:bg-slate-900 group-hover:bg-indigo-50/50 dark:group-hover:bg-indigo-900/50 z-10 w-[120px] min-w-[120px] border-l border-slate-200 dark:border-slate-800";
                          if (h === "Name") stickyClass = "sticky left-[337px] bg-slate-50 dark:bg-slate-900 group-hover:bg-indigo-50/50 dark:group-hover:bg-indigo-900/50 z-10 w-[250px] min-w-[250px] border-r border-slate-200 dark:border-slate-800 shadow-[6px_0_12px_-6px_rgba(0,0,0,0.04)]";

                          return (
                            <td key={h} className={`px-8 py-5 text-sm font-bold text-slate-600 dark:text-slate-300 whitespace-nowrap max-w-md overflow-hidden text-ellipsis ${isTech ? 'font-mono text-indigo-500/80 dark:text-indigo-400' : ''} ${stickyClass}`}>
                              {row[h] || <span className="text-slate-200">/</span>}
                            </td>
                          );
                        })}
                        <td className="px-2 py-5 whitespace-nowrap"></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-10">
          {/* Notification Toast */}
          {notification && (
            <div className="absolute top-10 left-1/2 -translate-x-1/2 z-[1000] animate-in slide-in-from-top-5 fade-in duration-300">
                <div className={`px-6 py-4 rounded-xl shadow-2xl border flex items-center gap-3 ${
                    notification.type === 'error' ? 'bg-rose-50 border-rose-200 text-rose-700 dark:bg-rose-900/90 dark:border-rose-800 dark:text-rose-100' : 
                    notification.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-900/90 dark:border-emerald-800 dark:text-emerald-100' : 
                    'bg-slate-900 border-slate-800 text-white'
                }`}>
                    {notification.type === 'error' ? <AlertTriangle className="w-5 h-5" /> : 
                     notification.type === 'success' ? <CheckCircle className="w-5 h-5" /> : 
                     <Info className="w-5 h-5" />}
                    <span className="font-bold text-sm">{notification.message}</span>
                    <button onClick={() => setNotification(null)} className="ml-2 opacity-70 hover:opacity-100"><X className="w-4 h-4" /></button>
                </div>
            </div>
          )}
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xl transition-opacity"></div>
          <div className="relative bg-slate-50 dark:bg-slate-900 w-full max-w-5xl rounded-xl shadow-[0_32px_64px_-16px_rgba(0,0,0,0.2)] flex flex-col max-h-[94vh] border border-slate-200 dark:border-slate-800 overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-10 py-8 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-900 sticky top-0 z-10">
              <div>
                <h2 className="text-3xl font-black tracking-tighter text-slate-900 dark:text-white">
                  {editingRow?.id ? 'Status Onboarding' : 'Neue Erfassung'}
                </h2>
                <div className="flex items-center gap-2 mt-1.5">
                   <div className="w-2 h-2 rounded-full bg-indigo-500"></div>
                   <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">PAM Governance Framework</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {editingRow?.id && (
                  <>
                  <button 
                    onClick={() => handleFullExcelExport(editingRow)}
                    className="p-3 hover:bg-emerald-50 rounded-lg transition-all group text-emerald-600"
                    title="Gesamtexport Excel"
                  >
                    <FileSpreadsheet className="w-6 h-6" />
                  </button>
                  <button 
                    onClick={() => viewMode === 'history' ? setViewMode('form') : handleFetchHistory(editingRow.id)}
                    className={`p-3 rounded-lg transition-all group ${viewMode === 'history' ? 'bg-indigo-50 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400' : 'hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-300 hover:text-slate-600'}`}
                    title="Änderungshistorie"
                  >
                    <HistoryIcon className="w-6 h-6" />
                  </button>
                  </>
                )}
              <button onClick={() => setIsModalOpen(false)} className="p-3 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-all group">
                <X className="w-7 h-7 text-slate-300 group-hover:text-slate-600" />
              </button>
              </div>
            </div>
            
            {viewMode === 'history' ? (
              <div className="flex-1 overflow-y-auto p-10 custom-scrollbar bg-slate-100 dark:bg-slate-950/50">
                <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-slate-800 dark:text-slate-200">
                  <Clock className="w-6 h-6 text-indigo-500" /> Änderungsprotokoll
                </h3>
                <PaginatedHistoryList history={history} cardClassName="bg-white dark:bg-slate-800 p-5 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-indigo-100 transition-colors" />
              </div>
            ) : (
              <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-10 space-y-8 custom-scrollbar bg-slate-100 dark:bg-slate-950/50">
                {/* Stammdaten (Always Visible) */}
                {FIELD_GROUPS.slice(0, 1).map((group, idx) => (
                  <div key={idx} className="space-y-8">
                    <div className="flex items-center gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
                      <div className="p-2.5 bg-white dark:bg-slate-800 rounded-lg shadow-inner">{group.icon}</div>
                      <h3 className="text-xs font-black uppercase tracking-[0.25em] text-slate-500">{group.title}</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-8 px-2">
                      {group.fields.map(fieldName => renderField(fieldName))}
                    </div>
                  </div>
                ))}

                {/* PAM Domain */}
                <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
                    <button type="button" onClick={() => toggleDomain('pam')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                        <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200">
                            <ShieldCheck className="w-5 h-5 text-indigo-500" />
                            Privileged Access Management (PAM)
                        </div>
                        <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openDomains.pam ? 'rotate-90' : ''}`} />
                    </button>
                    {openDomains.pam && (
                        <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-16 animate-in slide-in-from-top-2 duration-200">
                            {/* PAM Status Section */}
                            <div className="space-y-6 border-b border-slate-100 dark:border-slate-800 pb-8">
                                <div className="space-y-1.5">
                                    <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">
                                        Status PAM Onboarding
                                    </label>
                                    <div className="relative group">
                                        <select 
                                            className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all outline-none font-semibold text-sm appearance-none cursor-pointer dark:text-slate-200"
                                            value={editingRow?.["StatusPAMOnboarding"] || ''}
                                            onChange={(e) => setEditingRow({...editingRow, "StatusPAMOnboarding": e.target.value})}
                                            disabled={isReadOnly}
                                        >
                                            <option value="">Status wählen...</option>
                                            <option value="Anbindung abgeschlossen">Anbindung abgeschlossen</option>
                                            <option value="Anbindung läuft">Anbindung läuft</option>
                                            <option value="Anbindung zurückgestellt">Anbindung zurückgestellt</option>
                                            <option value="Anbindung wird nicht weiter verfolgt">Anbindung wird nicht weiter verfolgt</option>
                                            <option value="Anbindung nicht erforderlich">Anbindung nicht erforderlich</option>
                                        </select>
                                        <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                                    </div>
                                </div>
                                {editingRow?.["StatusPAMOnboarding"] === 'Anbindung zurückgestellt' && (
                                    <div className="space-y-1.5 animate-in fade-in slide-in-from-top-1 duration-200">
                                        <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">
                                            Voraussichtlicher Start der Anbindung
                                        </label>
                                        <input type="date" className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all outline-none font-semibold text-sm dark:text-slate-200" value={editingRow?.["StartdatumPAMOnboarding"] || ''} onChange={(e) => setEditingRow({...editingRow, "StartdatumPAMOnboarding": e.target.value})} disabled={isReadOnly} />
                                    </div>
                                )}
                                {editingRow?.["StatusPAMOnboarding"] === 'Anbindung nicht erforderlich' && (
                                    <div className="space-y-6 animate-in fade-in slide-in-from-top-1 duration-200">
                                        <div className="space-y-1.5">
                                            <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">
                                                Grund für Nichtanbindung
                                            </label>
                                            <div className="relative group">
                                                <select 
                                                    className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all outline-none font-semibold text-sm appearance-none cursor-pointer dark:text-slate-200"
                                                    value={editingRow?.["GrundNichtanbindungPAM"] || ''}
                                                    onChange={(e) => setEditingRow({...editingRow, "GrundNichtanbindungPAM": e.target.value})}
                                                    disabled={isReadOnly}
                                                >
                                                    <option value="">Grund wählen...</option>
                                                    <option value="Keine privilegierten Rechte">Keine privilegierten Rechte</option>
                                                    <option value="PAM Prozess vertraglich an Dienstleister ausgelagert">PAM Prozess vertraglich an Dienstleister ausgelagert</option>
                                                </select>
                                                <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                                            </div>
                                        </div>
                                        {editingRow?.["GrundNichtanbindungPAM"] === 'PAM Prozess vertraglich an Dienstleister ausgelagert' && (
                                            <div className="space-y-1.5 animate-in fade-in slide-in-from-top-1 duration-200">
                                                <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">Name des Dienstleisters</label>
                                                <input type="text" className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all outline-none font-semibold text-sm dark:text-slate-200" value={editingRow?.["DienstleisterPAM"] || ''} onChange={(e) => setEditingRow({...editingRow, "DienstleisterPAM": e.target.value})} disabled={isReadOnly} placeholder="Dienstleister Name" />
                                            </div>
                                        )}
                                    </div>
                                )}
                                {editingRow?.["StatusPAMOnboarding"] === 'Anbindung wird nicht weiter verfolgt' && (
                                    <div className="space-y-1.5 animate-in fade-in slide-in-from-top-1 duration-200">
                                        <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">
                                            Gründe
                                        </label>
                                        <MultiSelectPicker 
                                            value={editingRow?.["GruendeNichtWeiterVerfolgtPAM"] || ''}
                                            onChange={(val: string) => setEditingRow({...editingRow, "GruendeNichtWeiterVerfolgtPAM": val})}
                                            options={["Risikoübernahme zur Nichtanbindung liegt vor", "System wird innerhalb der kommenden 12 Monate abgelöst"]}
                                            readOnly={isReadOnly}
                                        />
                                    </div>
                                )}
                            </div>

                            {FIELD_GROUPS.slice(1).map((group, idx) => (
                                <div key={idx} className="space-y-8">
                                    <div className="flex items-center gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
                                        <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg shadow-inner">{group.icon}</div>
                                        <h3 className="text-xs font-black uppercase tracking-[0.25em] text-slate-500">{group.title}</h3>
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-8 px-2">
                                        {group.fields.map(fieldName => renderField(fieldName))}
                                    </div>
                                </div>
                            ))}

                            {/* Abnahme Bereich (Moved inside PAM) */}
                            <div className="space-y-8 border-t border-slate-100 dark:border-slate-800 pt-8">
                                <div className="flex items-center gap-4">
                                    <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg shadow-inner"><CheckCircle className="w-5 h-5 text-emerald-500" /></div>
                                    <h3 className="text-xs font-black uppercase tracking-[0.25em] text-slate-500">Abnahme PAM Onboarding</h3>
                                </div>
                                
                                {editingRow?.AbnahmePAMOnboarding ? (
                                    <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-800 rounded-xl p-6 flex items-center justify-between gap-4">
                                        <div className="flex items-center gap-4">
                                            <div className="bg-emerald-100 p-3 rounded-full">
                                                <CheckCircle className="w-8 h-8 text-emerald-600" />
                                            </div>
                                            <div>
                                                <h4 className="font-bold text-emerald-900 text-lg">Abnahme erteilt</h4>
                                                <p className="text-emerald-700 font-medium">
                                                    Durch {editingRow.AbnahmePAMOnboarding}
                                                </p>
                                            </div>
                                        </div>
                                        {role === 'admin' && (
                                            <button type="button" onClick={() => handleRevokeAcceptance('pam')} className="px-4 py-2 bg-white border border-emerald-200 text-emerald-700 hover:bg-emerald-100 hover:text-emerald-800 rounded-lg text-sm font-bold transition-colors shadow-sm">
                                                Zurückziehen
                                            </button>
                                        )}
                                    </div>
                                ) : (
                                    (role === 'maintenance') ? (
                                        <div className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-6">
                                            <p className="text-slate-500 dark:text-slate-400 mb-4 text-sm">Bitte bestätigen Sie die korrekte Umsetzung der CyberArk Anbindung nach erfolgreichem Test.</p>
                                            <button type="button" onClick={() => handleAcceptance('pam')} className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-lg shadow-emerald-100 transition-all active:scale-[0.98] flex justify-center items-center gap-2"><CheckCircle className="w-5 h-5" /> Abnahme erteilen</button>
                                        </div>
                                    ) : <div className="p-4 text-center text-slate-400 italic bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">Abnahme noch ausstehend.</div>
                                )}
                            </div>
                        </div>
                    )}
                </div>

                {/* Secrets Management Domain */}
                <div className="bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
                    <button type="button" onClick={() => toggleDomain('secrets')} className="w-full px-6 py-4 flex items-center justify-between bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                        <div className="flex items-center gap-3 font-bold text-slate-700 dark:text-slate-200">
                            <KeyRound className="w-5 h-5 text-emerald-500" />
                            Secrets Management
                        </div>
                        <ChevronRight className={`w-5 h-5 text-slate-400 transition-transform ${openDomains.secrets ? 'rotate-90' : ''}`} />
                    </button>
                    {openDomains.secrets && (
                        <div className="p-6 border-t border-slate-100 dark:border-slate-700 space-y-16 animate-in slide-in-from-top-2 duration-200">
                            {/* Secrets Status Section */}
                            <div className="space-y-6 border-b border-slate-100 dark:border-slate-800 pb-8">
                                <div className="space-y-1.5">
                                    <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">
                                        Status Secrets Onboarding
                                    </label>
                                    <div className="relative group">
                                        <select 
                                            className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all outline-none font-semibold text-sm appearance-none cursor-pointer dark:text-slate-200"
                                            value={editingRow?.["StatusSecretsOnboarding"] || ''}
                                            onChange={(e) => setEditingRow({...editingRow, "StatusSecretsOnboarding": e.target.value})}
                                            disabled={isReadOnly}
                                        >
                                            <option value="">Status wählen...</option>
                                            <option value="Anbindung abgeschlossen">Anbindung abgeschlossen</option>
                                            <option value="Anbindung läuft">Anbindung läuft</option>
                                            <option value="Anbindung zurückgestellt">Anbindung zurückgestellt</option>
                                            <option value="Anbindung wird nicht weiter verfolgt">Anbindung wird nicht weiter verfolgt</option>
                                            <option value="Anbindung nicht erforderlich">Anbindung nicht erforderlich</option>
                                        </select>
                                        <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                                    </div>
                                </div>
                                {editingRow?.["StatusSecretsOnboarding"] === 'Anbindung zurückgestellt' && (
                                    <div className="space-y-1.5 animate-in fade-in slide-in-from-top-1 duration-200">
                                        <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">
                                            Voraussichtlicher Start der Anbindung
                                        </label>
                                        <input type="date" className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all outline-none font-semibold text-sm dark:text-slate-200" value={editingRow?.["StartdatumSecretsOnboarding"] || ''} onChange={(e) => setEditingRow({...editingRow, "StartdatumSecretsOnboarding": e.target.value})} disabled={isReadOnly} />
                                    </div>
                                )}
                                {editingRow?.["StatusSecretsOnboarding"] === 'Anbindung nicht erforderlich' && (
                                    <div className="space-y-6 animate-in fade-in slide-in-from-top-1 duration-200">
                                        <div className="space-y-1.5">
                                            <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">
                                                Grund für Nichtanbindung
                                            </label>
                                            <div className="relative group">
                                                <select 
                                                    className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all outline-none font-semibold text-sm appearance-none cursor-pointer dark:text-slate-200"
                                                    value={editingRow?.["GrundNichtanbindungSecrets"] || ''}
                                                    onChange={(e) => setEditingRow({...editingRow, "GrundNichtanbindungSecrets": e.target.value})}
                                                    disabled={isReadOnly}
                                                >
                                                    <option value="">Grund wählen...</option>
                                                    <option value="System nutzt keinerlei Secrets">System nutzt keinerlei Secrets</option>
                                                    <option value="Prozess zur Secret Verwaltung vertraglich an Dienstleister ausgelagert">Prozess zur Secret Verwaltung vertraglich an Dienstleister ausgelagert</option>
                                                </select>
                                                <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                                            </div>
                                        </div>
                                        {editingRow?.["GrundNichtanbindungSecrets"] === 'Prozess zur Secret Verwaltung vertraglich an Dienstleister ausgelagert' && (
                                            <div className="space-y-1.5 animate-in fade-in slide-in-from-top-1 duration-200">
                                                <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">Name des Dienstleisters</label>
                                                <input type="text" className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all outline-none font-semibold text-sm dark:text-slate-200" value={editingRow?.["DienstleisterSecrets"] || ''} onChange={(e) => setEditingRow({...editingRow, "DienstleisterSecrets": e.target.value})} disabled={isReadOnly} placeholder="Dienstleister Name" />
                                            </div>
                                        )}
                                    </div>
                                )}
                                {editingRow?.["StatusSecretsOnboarding"] === 'Anbindung wird nicht weiter verfolgt' && (
                                    <div className="space-y-1.5 animate-in fade-in slide-in-from-top-1 duration-200">
                                        <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">
                                            Gründe
                                        </label>
                                        <MultiSelectPicker 
                                            value={editingRow?.["GruendeNichtWeiterVerfolgtSecrets"] || ''}
                                            onChange={(val: string) => setEditingRow({...editingRow, "GruendeNichtWeiterVerfolgtSecrets": val})}
                                            options={["Risikoübernahme zur Nichtanbindung liegt vor", "System wird innerhalb der kommenden 12 Monate abgelöst"]}
                                            readOnly={isReadOnly}
                                        />
                                    </div>
                                )}
                            </div>

                            {secretsSummaryLoading ? (
                                <div className="flex justify-center p-4"><RefreshCw className="animate-spin w-5 h-5 text-indigo-500" /></div>
                            ) : (
                                <div className="space-y-6">
                                    {(!secretsSummary || Object.keys(secretsSummary).length === 0) ? (
                                        <div className="p-4 text-center text-slate-400 italic">Keine Daten im Secrets Onboarding vorhanden.</div>
                                    ) : (
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-50 dark:bg-slate-800/50 p-6 rounded-xl border border-slate-100 dark:border-slate-800">
                                            <div>
                                                <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Komponenten</span>
                                                <div className="font-medium text-slate-700 dark:text-slate-200">
                                                    {(secretsSummary.components || []).map((c: any) => c.name).join(', ') || '-'}
                                                </div>
                                            </div>
                                            <div>
                                                <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Secrets Tool</span>
                                                <div className="font-medium text-slate-700 dark:text-slate-200">{secretsSummary.targetTool || '-'}</div>
                                            </div>
                                            <div>
                                                <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Anbindungsvariante</span>
                                                <div className="font-medium text-slate-700 dark:text-slate-200">{secretsSummary.targetVariant || '-'}</div>
                                            </div>
                                            <div>
                                                <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Secret Typen</span>
                                                <div className="font-medium text-slate-700 dark:text-slate-200">{(secretsSummary.secretTypes || []).join(', ') || '-'}</div>
                                            </div>
                                            <div>
                                                <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Betriebsmodell</span>
                                                <div className="font-medium text-slate-700 dark:text-slate-200">{secretsSummary.operatingModel || '-'}</div>
                                            </div>
                                        </div>
                                    )}
                                    
                                    <div className="space-y-6 border-t border-slate-100 dark:border-slate-800 pt-8">
                                        <div className="space-y-1.5">
                                            <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.1em] ml-1">
                                                Kommentar
                                            </label>
                                            <textarea 
                                                rows={3}
                                                className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all outline-none font-semibold text-sm resize-none dark:text-slate-200"
                                                value={editingRow?.["KommentarSecretsManagement"] || ''}
                                                onChange={(e) => setEditingRow({...editingRow, "KommentarSecretsManagement": e.target.value})}
                                                disabled={isReadOnly}
                                                placeholder="Optionale Anmerkungen..."
                                            />
                                        </div>
                                    </div>

                                    <div className="space-y-8 border-t border-slate-100 dark:border-slate-800 pt-8">
                                        <div className="flex items-center gap-4">
                                            <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg shadow-inner"><CheckCircle className="w-5 h-5 text-emerald-500" /></div>
                                            <h3 className="text-xs font-black uppercase tracking-[0.25em] text-slate-500">Abnahme Secrets Management</h3>
                                        </div>
                                        
                                        {editingRow?.AbnahmeSecretsOnboarding ? (
                                            <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-800 rounded-xl p-6 flex items-center justify-between gap-4">
                                                <div className="flex items-center gap-4">
                                                    <div className="bg-emerald-100 p-3 rounded-full"><CheckCircle className="w-8 h-8 text-emerald-600" /></div>
                                                    <div>
                                                        <h4 className="font-bold text-emerald-900 text-lg">Abnahme erteilt</h4>
                                                        <p className="text-emerald-700 font-medium">Durch {editingRow.AbnahmeSecretsOnboarding}</p>
                                                    </div>
                                                </div>
                                                {role === 'admin' && <button type="button" onClick={() => handleRevokeAcceptance('secrets')} className="px-4 py-2 bg-white border border-emerald-200 text-emerald-700 hover:bg-emerald-100 hover:text-emerald-800 rounded-lg text-sm font-bold transition-colors shadow-sm">Zurückziehen</button>}
                                            </div>
                                        ) : (
                                            (role === 'maintenance') ? (
                                                <div className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-6">
                                                    <p className="text-slate-500 dark:text-slate-400 mb-4 text-sm">Bitte bestätigen Sie die korrekte Umsetzung der Secrets Management Anbindung.</p>
                                                    <button type="button" onClick={() => handleAcceptance('secrets')} className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-lg shadow-emerald-100 transition-all active:scale-[0.98] flex justify-center items-center gap-2"><CheckCircle className="w-5 h-5" /> Abnahme erteilen</button>
                                                </div>
                                            ) : <div className="p-4 text-center text-slate-400 italic bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">Abnahme noch ausstehend.</div>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                <div className="pb-10"></div>
              </form>
            )}

            <div className="p-10 bg-slate-50/80 dark:bg-slate-900/80 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 flex justify-end gap-5 sticky bottom-0 z-10">
              <button type="button" onClick={() => setIsModalOpen(false)} className="px-8 py-4 font-extrabold text-slate-400 hover:text-slate-600 transition-colors">Schließen</button>
              {viewMode === 'form' && (
              !isReadOnly && (
              <button 
                type="submit" 
                onClick={handleSave}
                disabled={saveStatus === 'saving'}
                className={`px-8 py-3 font-bold rounded-lg shadow-lg transition-all active:scale-95 flex items-center gap-2 ${
                    saveStatus === 'success' 
                    ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-200' 
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-200'
                }`}
              >
                {saveStatus === 'saving' ? <RefreshCw className="animate-spin w-5 h-5" /> : 
                 saveStatus === 'success' ? <CheckCircle className="w-5 h-5" /> : 
                 <Save className="w-5 h-5" />} 
                {saveStatus === 'success' ? 'Gespeichert' : 'Speichern'}
              </button>
              )
              )}
            </div>
          </div>
        </div>
      )}

      {unifiedRow && (
        <UnifiedAppModal 
            isOpen={!!unifiedRow} 
            onClose={() => setUnifiedRow(null)} 
            governanceRow={unifiedRow} 
            user={user} 
            initialTab={initialTab}
            mode={modalMode}
            readOnly={isReadOnly}
        />
      )}

      {isAcceptanceConfirmOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-10">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"></div>
          <div className="relative bg-white w-full max-w-lg rounded-xl shadow-2xl p-8 animate-in zoom-in-95 duration-200 border border-slate-100">
            <div className="flex flex-col items-center text-center gap-4">
                <div className="p-4 bg-emerald-50 rounded-full">
                    <CheckCircle className="w-10 h-10 text-emerald-500" />
                </div>
                <h3 className="text-xl font-black text-slate-900">Abnahme bestätigen</h3>
                <p className="text-slate-500 font-medium leading-relaxed">
                    {(() => {
                        const statusField = acceptanceType === 'pam' ? 'StatusPAMOnboarding' : 'StatusSecretsOnboarding';
                        const status = editingRow?.[statusField];
                        const domain = acceptanceType === 'pam' ? 'PAM' : 'Secrets Management';

                        if (status === 'Anbindung abgeschlossen') {
                            return `Ich bestätige die technische Korrektheit und die korrekte Einführung des organisatorischen ${domain}-Prozesses.`;
                        } else if (status === 'Anbindung wird nicht weiter verfolgt') {
                            return `Ich bestätige, dass die Entscheidung, die ${domain}-Anbindung nicht weiter zu verfolgen, organisatorisch und fachlich abgestimmt wurde.`;
                        }
                        return `Abnahme für ${domain} bestätigen?`;
                    })()}
                </p>
                <div className="grid grid-cols-2 gap-4 w-full mt-4">
                    <button 
                        onClick={() => setIsAcceptanceConfirmOpen(false)}
                        className="py-3 px-4 bg-slate-50 hover:bg-slate-100 text-slate-600 font-bold rounded-lg transition-colors"
                    >
                        Abbrechen
                    </button>
                    <button 
                        onClick={confirmAcceptance}
                        className="py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-lg shadow-emerald-100 transition-all active:scale-[0.98]"
                    >
                        Bestätigen
                    </button>
                </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = createRoot(rootElement);
  root.render(<App />);
}
